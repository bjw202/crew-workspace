# 작업 9 노트

## 가설·계획
회차 2 반영. ① chronicle 회차 2 줄 다섯(작업 4·5·6·7·8)을 위키·index 에 세운다
② ch-3b 위키의 근거를 void 인 작업 2 판에서 현재 판(작업 8)으로 옮긴다
③ yield-data 20행 "자료 자체에 흠은 없다"를 확인한 넷으로 좁힌다
④ 이번 회차 산출물을 포함 규칙대로 index 에 넣고 void 줄에 대체 경로를 단다 ⑤ 원본·남의 산출물 무손상.

## 지금까지 확인한 것
- 판 계보 확인(머리말 직접 읽음): task-2 status void / task-5 status void, supersedes task-2 /
  task-8 status valid, supersedes task-5. 현재 판은 analyst/task-8-chamber-yield-drop.md(204행).
  세 판의 수치·결론은 글자 그대로 같다(analyst/task-8-report.md, reporter 보고서 머리).
- 회차 2 에서 확정된 둘을 "아직 모르는 것"에서 "아는 것"으로 옮겼다:
  상관 -0.900 은 07-29 앞뒤 두 무리가 섞인 값(구간 안 -0.249 / -0.009, 파티클 비율 0.1324~0.2571 대 0.5207~0.5739),
  -3sd 첫날은 범위에 따라 다름(07-25 이후로 보면 07-29, 전 기간이면 07-08 91.78% 하루짜리).
  근거 행: task-8#행 118-132 · #행 75, analyst/task-5-evidence.log#행 15-27.
- task-8 절 행 범위를 sed 로 직접 확인해 인용에 썼다: 17-19 결론 · 34-46 무결성 · 47-63 챔버표 ·
  64-79 일별 · 81-97 불량 분해 · 99-108 대조군 · 110-116 전제 판정 · 118-132 상관.
- chronicle 은 10행(머리 2 + 작업 8줄). 회차 2 줄 다섯은 6~10행.
- index: 9줄 추가(analyst task-8 넷 · reporter 셋 · 내 것 둘) → 표 41행. task-5 줄을 void + 대체 경로로,
  task-2 줄에도 현재 판을 함께 적었다. 머리에 "판이 겹칠 때" 규칙 한 줄을 더했다.
- yield-data: 20행을 "확인한 넷에서는 흠이 나오지 않았다"로 좁히고 무결성 인용을 현재 판으로 옮겼다.

## 읽은 파일
- orchestrator/chronicle.md, analyst/task-8-chamber-yield-drop.md(머리말·75·131행·절 범위), analyst/task-8-report.md
- analyst/task-2·task-5 머리말, reporter/task-6-yield-drop-report.md(머리말·머리글·결론 세 줄)
- archivist/wiki 두 쪽, archivist/index.md

## 다음 한 걸음
- 서브에이전트 검토(등급 1) → 지적 반영 → 커밋 → task-9-report.md → 전송.
