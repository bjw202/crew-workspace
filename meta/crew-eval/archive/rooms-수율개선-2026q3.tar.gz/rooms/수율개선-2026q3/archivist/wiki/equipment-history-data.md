---
room: 수율개선-2026q3
task: 21
kind: wiki
title: 이 방의 자료 — 설비 이력 CSV 와 그 한계
created: 2026-09-09
updated: 2026-09-09
aliases: 설비이력자료, 설비이력, equipment-history, equipment-history-data, 챔버이력, 정비이력, maintenance-log, 두번째원본, 이력자료, 설비이력부록, equipment-history-addendum
tags: 자료, 원본, csv, 설비, 챔버, 이력, 정비, PM, PART, 세정, CLEAN, 알람, ALARM, 계측교정, CAL, 레시피, RECIPE, 무결성, 회차3, 회차5, 부록, addendum
sources: archivist/inbox/2026-09-08-equipment-history/423efc74-8819-445a-bb81-90ca388034fd-equipment_history.csv.md, archivist/inbox/2026-09-09-equipment-history-addendum/0712fc84-e908-4582-992b-63aebebca36d-equipment_history_addendum.csv.md, archivist/task-10-evidence.log, analyst/task-11-equipment-history-vs-yield.md#행 51-59, analyst/task-11-equipment-history-vs-yield.md#행 232-254, researcher/task-12-cross-review.md#행 210-219, reporter/task-13-equipment-history-report.md#행 218-234
status: valid
supersedes: none
---

## 지금까지 아는 것

- **이 방의 두 번째 원본이다.** 2026-09-09 에 의뢰인이 올렸고 archivist/inbox/2026-09-08-equipment-history/ 에 그대로 들어 있다(권한 444). 사람이 올린 이름은 equipment_history.csv 이고 파일 이름 앞 UUID 는 채팅 서버가 붙인 것이다. SHA-256 은 664b06bffa85… 로 업로드 경로의 파일과 사본이 같다.
- **앞 원본의 열은 6개, 데이터는 48행(머리글 포함 49줄)이다.** date · chamber · event_type · detail · duration_min(분) · worker. 기간은 2026-07-01~08-20(51일)이고, 서로 다른 날짜는 33일이다.
- **챔버는 여섯이고 행 수가 고르지 않다.** CH-1A 8 · CH-1B 8 · CH-2A 9 · CH-2B 7 · CH-3A 7 · CH-3B 9 (합 48).
- **사건 종류는 여섯이다.** CLEAN 25 · CAL 6 · PM 6 · ALARM 5 · PART 4 · RECIPE 2 (합 48). 담당자는 박세정 25 · 김정비 10 · 이공정 6 · 최계측 6 이고 한 행이 빈칸이다.
- **형식에서 눈에 띈 것이 셋 있다.** 줄 끝이 모두 CRLF 이고, 데이터 34행째의 날짜만 구분자가 `2026/08/03` 이며, 데이터 48행째의 worker 가 비어 있다. 모든 줄의 필드 수는 6으로 같고 따옴표로 묶인 필드는 없다.
- **회차 5 에 이 CSV 의 부록이 들어왔다.** archivist/inbox/2026-09-09-equipment-history-addendum/ 에 그대로 있고(권한 444), 사람이 올린 이름은 equipment_history_addendum.csv, SHA-256 은 4b4c1e5eb3c5… 다. 열 이름 여섯 개와 차례가 앞 원본과 같고, 데이터는 10행(머리글 포함 11줄), 기간은 2026-08-26~09-02 다. 챔버는 CH-3B 3 · CH-1A 2 · CH-2A 2 · CH-1B 1 · CH-2B 1 · CH-3A 1 이고, 사건 종류는 CLEAN 6 · ALARM 2 · PART 1 · RECIPE 1 이다(합 10). 앞 원본에 있던 CAL 과 PM 은 부록에 0행이다.
- **부록의 형식 흠은 하나다.** 데이터 10행의 worker 가 비어 있다. 앞 원본의 마지막 행도 worker 가 빈 ALARM 행이었다. 날짜 형식이 어긋난 행은 0행이고, 모든 줄의 필드 수가 6으로 같다.
- **부록에서 부품 낱개 번호가 처음 나온다.** 데이터 2행의 detail 에 `샤워헤드(SH-2200) 교체 — SH2200-B-0412 탈거 · SH2200-B-0413 장착` 이 적혀 있다. 낱개 번호를 담는 열은 여전히 따로 없고, 자유 문장 안에 들어 있다.
- **이력과 수율은 두 파일씩이 되었어도 기간이 그대로 맞지는 않는다.** 이력은 07-01~08-20 과 08-26~09-02 이고 수율은 07-01~08-25 와 08-26~09-03 이다. 08-21~08-25 닷새는 이력이 없는 채로 남고, 09-03 하루는 수율만 있다.
- **날짜만 있고 시각이 없다.** 그래서 같은 날 있었던 두 작업의 앞뒤를 가를 수 없고, 로트가 작업 전에 들어갔는지 뒤에 들어갔는지도 알 수 없다. 회차 3 이 정기 정비와 샤워헤드 교체를 가르지 못한 까닭이 이것이다.
- **이 자료로 실제 대조를 낸 것은 48건 중 44건이다.** 2026-07-01~07-04 의 세정 4건은 앞 창이 자료 시작 전이라 견줄 구간이 없어 빠졌다. 넷 다 CH-3B 가 아닌 다른 챔버다.
- **원본은 손대지 않았다.** 들일 때와 회차 3 이 끝날 때 모두 SHA-256 이 같고 권한도 444 그대로다. analyst 와 researcher 는 이 파일을 읽기만 했다.

## 근거

| 아는 것 | 작업 | 경로 |
|---|---|---|
| 열·행 수·기간·종류별 개수·SHA-256·형식 셋 | 작업 10 | archivist/inbox/2026-09-08-equipment-history/423efc74-8819-445a-bb81-90ca388034fd-equipment_history.csv.md · archivist/task-10-evidence.log |
| 원본을 읽을 때 걸린 것 셋(CRLF·날짜 구분자·빈칸) | 작업 11 | analyst/task-11-equipment-history-vs-yield.md#행 51-59 |
| 시각이 없어 가르지 못하는 것, 완전성을 확인할 수 없는 것 | 작업 11 | analyst/task-11-equipment-history-vs-yield.md#행 232-254 |
| 창부족 4건과 44건이라는 수 | 작업 13 | reporter/task-13-equipment-history-report.md#행 218-234 |
| 원본 CSV 둘을 다시 읽어 낸 독립 재계산 | 작업 12 | researcher/task-12-cross-review.md#행 15-32 |
| 부록 들이기·해시·열과 기간·종류별 개수·형식 흠 하나 | 작업 21 | archivist/inbox/2026-09-09-equipment-history-addendum/0712fc84-e908-4582-992b-63aebebca36d-equipment_history_addendum.csv.md · archivist/task-21-evidence.log |

## 아직 모르는 것

- **이력에 빠진 작업이 없는지 확인할 수 없다.** 이 파일 안에서 완전성을 볼 방법이 없다. 말할 수 있는 것은 "기록된 것 중에는 없다"까지다. 작업 지시·완료 원장과 챔버 개방(vent) 기록을 받아야 한다.
- **이 이력이 현장 사실과 맞는지는 이 방에서 검증할 수 없다.** 수율 CSV 와 같은 한계다.
- **2026년 상반기 이력이 없다.** 51일치뿐이라 CH-3B 의 분기 정기 정비가 이 기간에 한 번뿐이고, "이 챔버는 정비 뒤에 늘 이런가"를 자기 이력으로 볼 수 없다.
- **08-21~08-25 닷새의 이력이 없다.** 부록이 08-26 에서 시작하므로 이 닷새는 두 파일 어디에도 행이 없고, 그 구간의 수율은 대조 없이 남는다.
- **부록 10행은 아직 아무도 수율과 맞대지 않았다.** 내가 센 것은 열·행 수·기간·종류별 개수와 형식 흠 하나까지다. 해석은 작업 22 의 몫이다.
- **07-05 CH-3A 는 계측 교정과 정기 세정이 같은 날이라 두 사건이 섞인 값이다.** 갈라내는 정보가 이 자료에 없다.

## 이력

- 2026-09-09 (작업 10): 원본을 inbox 에 들이고 사이드카에 열·행 수·기간·종류별 개수·SHA-256·형식 주의 셋을 적었다. 그때는 "이 파일의 내용이 무엇을 뜻하는지는 아직 아무도 분석하지 않았다"고 적어 두었다.
- 2026-09-09 (작업 14, 회차 3 반영): 이 페이지를 새로 세웠다. 작업 11·12·13 이 이 자료를 실제로 쓰면서 드러난 한계(시각 없음, 기간이 수율보다 닷새 짧음, 44건만 잴 수 있음, 완전성 확인 불가)를 사이드카의 세어 본 값과 함께 한자리에 모은 것이다. 사이드카의 수치는 하나도 바뀌지 않았다.
- 2026-09-09 (작업 21): "08-21 이후 이력이 없다"가 뒤집혔다. 회차 5 에 08-26~09-02 를 담은 부록이 들어왔으므로, 이력이 없는 구간은 08-21~08-25 닷새로 좁아졌다. 같은 이유로 "수율의 마지막 닷새는 맞댈 이력이 없다"도 다시 적었다 — 이제 맞댈 것이 없는 날은 그 닷새와 09-03 하루다. 앞 원본의 수치는 하나도 바뀌지 않았고, 문장이 어느 파일을 가리키는지 드러나도록 "앞 원본의"를 붙였다.
