---
room: 수율개선-2026q3
task: 21
kind: wiki
title: 이 방의 자료 — 로트별 수율 CSV 와 그 무결성
created: 2026-09-08
updated: 2026-09-09
aliases: 자료, 원본자료, 수율데이터, yield-data, 로트별수율, lot-yield-data, 데이터무결성, data-integrity, 첫번째원본, 수율부록, yield-addendum
tags: 자료, 원본, csv, 수율, 로트, 챔버, 무결성, 색인, 사전지식, 설비이력, 회차1, 회차3, 회차4, 회차5, 입고검사, 부록, addendum
sources: archivist/inbox/2026-09-08-yield-by-lot/44cdd855-be6e-4b66-a014-e7eb3a056769-yield_by_lot.csv.md, archivist/inbox/2026-09-09-yield-by-lot-addendum/fee7dd34-07cb-47a1-ab27-cb68fd3b59b5-yield_by_lot_addendum.csv.md, analyst/task-2-evidence.log#행 1-27, analyst/task-8-chamber-yield-drop.md#행 34-46, researcher/task-3-review-task2.md#행 22, archivist/00-prior-knowledge.md, archivist/wiki/equipment-history-data.md, archivist/wiki/part-inspection-data.md
status: valid
supersedes: none
---

## 지금까지 아는 것

- **이 방의 원본은 여섯이고 그중 첫째가 로트별 수율 CSV 다.** 둘째는 회차 3 에 받은 설비 이력 CSV(archivist/wiki/equipment-history-data.md), 셋째는 회차 4 에 받은 부품 입고 검사 성적서 CSV(archivist/wiki/part-inspection-data.md) 이고, 회차 5 에 셋이 더 들어왔다 — 로트별 수율 부록(이 페이지 아래), 설비 이력 부록(equipment-history-data.md), 부품 재측정(part-inspection-data.md) 이다. 수율 CSV 는 archivist/inbox/2026-09-08-yield-by-lot/ 에 의뢰인이 올린 그대로 들어 있고(권한 444), 사람이 올린 이름은 yield_by_lot.csv, 파일 이름 앞 UUID 는 채팅 서버가 붙인 것이다. SHA-256 은 580945bc463a… 다.
- **열은 7개, 데이터는 672행(머리글 포함 673행)이다.** lot_id · date · line · chamber · yield_pct(%) · defect_count(개) · particle_defects(개). 기간은 2026-07-01~08-25(56일), line 1·2·3 각 224행, 챔버 CH-1A·1B·2A·2B·3A·3B 각 112행, 하루에 챔버당 2로트다.
- **particle_defects 는 defect_count 의 부분집합이다.** 672행 전수 검사에서 위반 0행이고, researcher 가 스크립트를 쓰지 않고 원본 CSV 에서 따로 계산해도 같았다.
- **앞 원본 672행에서 확인한 넷에서는 흠이 나오지 않았다.** 빈칸 0, lot_id 중복 0건, defect_count 가 0인 행 0행(파티클 비율에 0나눗셈이 없다), yield_pct 범위 88.47~96.42%. 이 넷 말고 다른 흠을 찾아본 것은 아니고, 아래 부록 109행은 이 검사를 받지 않았다.
- **회차 5 에 이 CSV 의 부록이 들어왔다.** archivist/inbox/2026-09-09-yield-by-lot-addendum/ 에 그대로 있고(권한 444), 사람이 올린 이름은 yield_by_lot_addendum.csv, SHA-256 은 f1980d15e6fd… 다. 열 이름 일곱 개와 차례가 앞 원본과 같고, 데이터는 109행(머리글 포함 110줄), 기간은 2026-08-26~09-03(9일)이다. 앞 원본은 L1672 · 08-25 에서 끝나므로 두 파일에 함께 나오는 lot_id 는 0개다.
- **부록에는 앞 원본에 없던 형식 흠이 넷 있다.** 데이터 47행과 48행이 열 일곱 개 모두 같고(L1719), 데이터 32행의 particle_defects 가 비어 있고, 데이터 58행의 date 가 `2026/08/30` 이고, 데이터 84행의 chamber 가 소문자 `ch-3b` 다. 넷을 세어 본 것까지가 지금 아는 것이고, 어느 것도 아직 고치거나 뺀 사람이 없다 — 원본은 손대지 않는다.
- **재현이 확인된 것은 한 번이다.** researcher 가 같은 seed 로 `cd rooms/수율개선-2026q3/analyst && python3 task-2-analysis.py` 를 한 번 돌려, 표준출력 314행이 analyst/task-2-evidence.log 와 diff 0행이었다(researcher/task-3-review-task2.md#행 45-53). 스크립트는 외부 패키지 없이 표준 라이브러리만 쓰고 순열검정 난수를 seed=20260908 로 코드 안에 고정한다(analyst/task-2-analysis.py#행 8·15·110). 확인된 범위는 여기까지다 — 다른 seed 로 돌린 실행도, researcher 말고 다른 사람이 돌린 실행도 아직 없다(아래 "아직 모르는 것").
- **이 과제 이전에 회사가 아는 것은 없다.** 루트/knowledge/domain 이 비어 있고 열어 볼 옛 방도 없어, 이 방의 결론은 모두 의뢰인이 준 원본에서 나온다. 원본은 회차 4 에 셋, 회차 5 에 여섯이 되었고, 회차 4 까지의 결론은 앞의 셋에서 나온 것이다.

## 근거

| 아는 것 | 작업 | 경로 |
|---|---|---|
| 원본 들이기·사이드카·열과 기간·행 수 | 작업 1 | archivist/inbox/2026-09-08-yield-by-lot/44cdd855-be6e-4b66-a014-e7eb3a056769-yield_by_lot.csv.md · archivist/index.md |
| 사전 지식 없음 | 작업 1 | archivist/00-prior-knowledge.md · 루트/knowledge/index.md |
| 무결성 검사(위반 0·빈칸 0·중복 0·범위) | 작업 2·8 | analyst/task-2-evidence.log#행 1-27 · analyst/task-8-chamber-yield-drop.md#행 34-46 |
| 재현 diff 0행, 원본 CSV 독립 재계산 | 작업 3 | researcher/task-3-review-task2.md#행 22 · #행 45-53 |
| 회차 1 통과 기록 | 작업 1·2·3 | orchestrator/chronicle.md#행 3-5 |
| 부록 들이기·해시·열과 기간·행 수·형식 흠 넷 | 작업 21 | archivist/inbox/2026-09-09-yield-by-lot-addendum/fee7dd34-07cb-47a1-ab27-cb68fd3b59b5-yield_by_lot_addendum.csv.md · archivist/task-21-evidence.log |

## 아직 모르는 것

- **이 CSV 가 설비에서 나온 실제 값인지는 이 방에서 검증할 수 없다.** 확인된 것은 파일 안에서 앞뒤가 맞는다는 것까지다.
- **이 CSV 만으로는 원인을 말할 수 없다.** 설비 이력은 회차 3 에(archivist/wiki/equipment-history-data.md), 부품 입고 검사 성적서는 회차 4 에 따로 받았다(archivist/wiki/part-inspection-data.md). 셋을 맞대어 원인 후보가 2026-07-28 하루로 좁혀졌고, 회차 4 에 정비 쪽이 물리쳐지고 샤워헤드 쪽이 판정 불가로 남았다(archivist/wiki/ch-3b-yield-drop.md). 레시피 상세·계측 원자료·부품 제조 로트는 여전히 이 방에 없다.
- **부록 109행은 아직 무결성 검사도 분석도 받지 않았다.** 앞 원본이 받은 검사(particle_defects 가 defect_count 의 부분집합인지, defect_count 0행이 있는지)를 부록에서는 아무도 돌리지 않았다. 내가 센 것은 열·행 수·기간·값 범위와 형식 흠 넷까지다. 해석은 작업 22 의 몫이다.
- **파티클 비율이 정상 수준인지 판단할 사내 기준값이 이 방에 없다.**
- **재현은 researcher 가 같은 seed 로 한 번 돌려 본 것이 전부다.** 다른 seed 로 돌려 본 실행도, 그 밖의 사람이 다시 돌려 본 실행도 아직 없다. "누가 돌려도 같은 값"은 코드가 그렇게 짜여 있다는 것이지 여러 번 확인된 사실이 아니다.

## 이력

- 2026-09-08 (작업 1): 사이드카에 particle_defects 를 "defect_count 의 부분집합으로 보이나 미확인"으로 적었다.
- 2026-09-08 (작업 4, 회차 1 반영): 위 문장을 "defect_count 의 부분집합 (672행 전수 검사 위반 0행)"으로 확정했다. 근거는 작업 2 의 전수 검사와 작업 3 의 독립 재계산이다. 원본 CSV 는 손대지 않았다(SHA-256 이 작업 3 이 적은 값과 같다).
- 2026-09-08 (작업 7): "계산은 누가 돌려도 같은 값이 나온다"를 확인된 범위(researcher 1회·같은 seed)로 좁혔다. 같은 페이지의 "다른 seed 로 돌려 본 사람은 없다"와 어긋나던 것을 맞춘 것이고, 수치가 바뀐 것은 없다.
- 2026-09-08 (작업 9, 회차 2 반영): "자료 자체에 흠은 없다"를 "확인한 넷에서는 흠이 나오지 않았다"로 좁혔다 — 제목 문장이 뒤에 붙은 넷(빈칸·중복·0나눗셈·범위)보다 넓었다. 무결성 인용은 폐기된 작업 2 판 대신 현재 판 analyst/task-8-chamber-yield-drop.md#행 34-46 을 가리키게 했다(세 판의 수치는 같다).
- 2026-09-09 (작업 14, 회차 3 반영): "이 방의 원본은 로트별 수율 CSV 한 개뿐이다"를 고쳤다. 회차 3 에 설비 이력 CSV 가 들어와 원본이 둘이 됐으므로 뒤집힌 문장이고, 새 자료는 archivist/wiki/equipment-history-data.md 에 따로 세웠다. 같은 이유로 "설비 이력이 없다"고 적어 둔 줄도 지금 있는 것과 아직 없는 것으로 갈라 다시 적었다. 이 CSV 자체의 수치와 무결성 결론은 하나도 바뀌지 않았다.
- 2026-09-09 (작업 15): "이 방의 원본은 둘이고"를 셋으로 고쳤다. 회차 4 에 부품 입고 검사 성적서 CSV 가 들어와 뒤집힌 문장이고, 새 자료는 archivist/wiki/part-inspection-data.md 에 따로 세웠다. 같은 이유로 "결론은 원본 둘에서 나온다"와 "자재 로트가 없다"는 줄도 다시 적었다 — 성적서에 serial 은 있으나 제조 로트 열은 없다. 이 CSV 자체의 수치와 무결성 결론은 하나도 바뀌지 않았다.
- 2026-09-09 (작업 19, 정정): "회차 4 에 부품 입고 검사 성적서가 들어왔으나 아직 아무도 분석하지 않았다"가 뒤집혔다. 작업 16 이 그 성적서를 이 CSV·설비 이력과 맞대어 07-28 두 후보를 갈랐고 작업 17 이 교차 검토해 통과시켰다. 이 CSV 자체의 수치와 무결성 결론은 하나도 바뀌지 않았다.
- 2026-09-09 (작업 21): "이 방의 원본은 셋이고"를 여섯으로 고쳤다. 회차 5 에 로트별 수율 부록·설비 이력 부록·부품 재측정 셋이 들어와 뒤집힌 문장이다. 같은 이유로 "원본은 회차 4 에 셋이 되었고"도 다시 적었다. 무결성 문장의 범위도 "앞 원본 672행"으로 좁혔다 — 부록 109행은 그 검사를 받지 않았는데 문장이 어느 파일인지 가리지 않고 있었다. 앞 원본의 수치와 무결성 결론은 하나도 바뀌지 않았다.
