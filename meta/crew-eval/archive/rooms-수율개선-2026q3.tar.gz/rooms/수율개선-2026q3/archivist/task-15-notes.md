# 작업 15 노트

## 가설·계획
① 셋째 원본(부품 입고 검사 성적서)을 archivist/inbox/2026-09-09-part-incoming-inspection/ 에 이름 그대로, 444 로 들인다.
② 사이드카에 세어 본 값과 형태만 적는다 — 뜻풀이·원인 해석은 analyst 몫이라 쓰지 않는다.
③ 위키: 새 쪽 part-inspection-data.md 를 세우고, 원본이 둘이라고 적힌 yield-data.md 와 ch-3b-yield-drop.md 를 고친다.
④ index.md 에 새 줄을 더하고 전수 대조를 다시 돌린다.

## 지금까지 확인한 것
- 들이기 전 index.md 는 grep -c '^|' 로 70줄(머리글 1 + 구분선 1 + 자료 68)이다.
- 원본을 복사하고 444 로 바꿨다. SHA-256 03a7831edee7… 이 업로드 경로의 파일과 같다.
- 세어 본 값: 데이터 34행 · 열 10개 · 모든 행의 필드 수 10 · 줄 끝 LF(CR 0줄) · recv_date 2026-07-03~08-21, 서로 다른 날 11.
  part_no 는 SH-2200 9, 나머지 다섯이 각 5. supplier 는 BSTech 17·AlphaParts 16·빈칸 1. unit 은 um 12·mm 2·나머지 넷이 각 5.
  install_date 와 chamber 가 함께 찬 행은 5(한쪽만 찬 행 0). 항목마다 spec_max 는 한 값으로 고정이다.
- 형태에서 눈에 띈 것 넷: 데이터 18행의 recv_date 가 `2026/08/01`. 데이터 7행과 10행이 완전히 같다(SH2200-B-0412).
  hole_dia_sd 9행 중 2행만 단위가 mm 여서 measured 를 spec_max 와 그대로 견주면 안 된다. 데이터 6행의 supplier 가 빈칸이다.
- 챔버에 달린 5행 중 하나가 이 방이 좁혀 둔 07-28 CH-3B 다(샤워헤드 SH2200-B-0412). 이 사실만 적고 해석은 하지 않았다 —
  이 성적서를 읽은 산출물이 아직 0개임을 grep 으로 확인했다(orchestrator/state.md 한 곳만 걸렸고 그것은 배분을 적어 둔 자리다).
- 사이드카 1 · 새 위키 part-inspection-data.md 1 을 만들고, yield-data.md 와 ch-3b-yield-drop.md 를 고쳤다.
  · yield-data.md: "이 방의 원본은 둘이고"가 뒤집혀 셋으로 고쳤다. "결론은 원본 둘에서 나온다"와 "자재 로트가 없다"도 다시 적었다.
  · ch-3b-yield-drop.md: "지금까지 아는 것"은 한 줄도 바꾸지 않았다. "아직 모르는 것"의 샤워헤드 시공 항목에만 새 자료가 어디까지 닿는지 한 문장을 더했다.
- index: 5줄을 더해 70 → 75. 전수 대조는 표 자료 73 · 부분집합 검사 25줄 · 제외 47 · kind 어긋남 0 · status 어긋남 0 · 표에만 있는 낱말 0.
  보고 파일을 쓰기 전이라 "파일 없음 1"이 남아 있고, 이는 archivist/task-15-report.md 다.
- 검사기 첫 판이 `sort -u` 로 한국어 낱말을 뭉개 거짓 경보 12건을 냈다. sort 를 빼니 0 이 됐다(근거 로그 [10]).

## 읽은 파일
- archivist/inbox/2026-09-08-equipment-history/…-equipment_history.csv.md (사이드카 서식 본으로)
- archivist/index.md · archivist/wiki/yield-data.md · archivist/wiki/ch-3b-yield-drop.md · archivist/wiki/equipment-history-data.md(원본 언급 줄만)

## 다음 한 걸음
- 커밋 → 보고 작성·커밋 → 보고 전송. push 는 이 방 저장소에 원격이 없어 못 한다.
