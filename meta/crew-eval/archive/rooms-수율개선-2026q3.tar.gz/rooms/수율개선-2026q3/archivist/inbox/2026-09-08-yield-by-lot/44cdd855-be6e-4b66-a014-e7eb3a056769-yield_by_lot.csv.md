---
room: 수율개선-2026q3
task: 1
kind: data
title: 로트별 수율 원본 (1~3라인, 2026-07-01~08-25)
created: 2026-09-08
updated: 2026-09-08
aliases: 수율원본, 로트별수율, yield-by-lot, yieldbylot, 로트수율csv, lot-yield-raw, 수율raw
tags: 수율, 로트, 설비, 챔버, 불량, 파티클, 원본, csv, 3라인
sources: analyst/task-2-evidence.log#행 11-14, analyst/task-2-chamber-yield-drop.md#행 29-40, researcher/task-3-review-task2.md#행 22
status: valid
supersedes: none
---
열 7개 · 데이터 672행(머리글 1행 포함 673행) · 2026-07-01~2026-08-25(56일) · 빈칸 0.

| 열 | 뜻 | 단위·값 |
|---|---|---|
| lot_id | 로트 번호 | L1001~L1672 |
| date | 투입일 | YYYY-MM-DD |
| line | 라인 번호 | 1·2·3 (각 224행) |
| chamber | 설비(챔버) | CH-1A·CH-1B·CH-2A·CH-2B·CH-3A·CH-3B (각 112행) |
| yield_pct | 수율 | 퍼센트(%) |
| defect_count | 불량 수 | 개 |
| particle_defects | 파티클 불량 수 | 개 · defect_count 의 부분집합 (672행 전수 검사 위반 0행) |

파일 이름의 앞 UUID 는 채팅 서버가 붙인 것이고, 사람이 올린 이름은 yield_by_lot.csv 다.

particle_defects 가 defect_count 의 부분집합이라는 것은 작업 2 가 672행 전수 검사로 확인했고(위반 0행, analyst/task-2-evidence.log#행 11-14), 작업 3 이 스크립트를 쓰지 않고 원본 CSV 에서 따로 재계산해 같은 값을 얻었다(researcher/task-3-review-task2.md#행 22).
작업 4 에서 이 문장을 반영했다. 원본 CSV 는 손대지 않았다 — SHA-256 580945bc463a…(작업 3 이 적은 값과 같다).
