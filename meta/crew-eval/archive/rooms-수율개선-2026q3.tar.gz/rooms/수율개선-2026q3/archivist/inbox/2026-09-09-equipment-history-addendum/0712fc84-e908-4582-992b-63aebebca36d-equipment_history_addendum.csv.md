---
room: 수율개선-2026q3
task: 21
kind: data
title: 설비 이력 원본 부록 (챔버 6개, 2026-08-26~09-02)
created: 2026-09-09
updated: 2026-09-09
aliases: 설비이력부록, equipment-history-addendum, equipmenthistoryaddendum, 설비이력추가분, 챔버이력부록, 정비이력부록, maintenance-log-addendum, 다섯번째원본, 8월말설비이력
tags: 설비, 챔버, 이력, 정비, 세정, 알람, 부품교체, 원본, csv, chamber, equipment, 부록, addendum, 회차5
sources: archivist/inbox/2026-09-09-equipment-history-addendum/0712fc84-e908-4582-992b-63aebebca36d-equipment_history_addendum.csv
status: valid
supersedes: none
---
열 6개 · 데이터 10행(머리글 1행을 더해 파일 11줄) · date 2026-08-26~2026-09-02(8일) · 빈칸 1개(데이터 10행의 worker).

| 열 | 뜻 | 단위·값 |
|---|---|---|
| date | 사건이 일어난 날 | YYYY-MM-DD · 어긋난 형식은 없다 |
| chamber | 설비(챔버) | CH-1A·CH-1B·CH-2A·CH-2B·CH-3A·CH-3B |
| event_type | 사건 종류 | ALARM·CLEAN·PART·RECIPE |
| detail | 사건 내용 | 한국어 자유 문장 · 한 행에 부품 낱개 번호가 들어 있다 |
| duration_min | 걸린 시간 | 분 · 정수 15~100 |
| worker | 담당자 | 한국어 이름 · 한 행이 빈칸 |

## 챔버별 행 수 (합 10)
CH-3B 3 · CH-1A 2 · CH-2A 2 · CH-1B 1 · CH-2B 1 · CH-3A 1

## event_type 별 행 수 (합 10)
CLEAN 6 · ALARM 2 · PART 1 · RECIPE 1
앞 원본에 있던 CAL 과 PM 은 이 부록에 0행이다.

## worker 별 행 수 (합 10)
박세정 6 · 이공정 2 · 김정비 1 · 빈칸 1

## 날짜별 행 수 (합 10 · 서로 다른 날 7)
08-26 1 · 08-27 3 · 08-28 1 · 08-29 2 · 08-30 1 · 09-01 1 · 09-02 1
기간 안의 여드레 가운데 08-31 만 0행이다.

## 형식에서 눈에 띈 것 (내용 해석이 아니라 형태만 적는다)
- 줄 끝이 CRLF(\r\n)다. 11줄 모두 그렇다. 마지막 줄에도 줄바꿈이 있다.
- 모든 줄의 필드 수가 6으로 같고, 따옴표로 묶인 필드는 없다. detail 안에 쉼표가 든 행은 0행이다.
- 데이터 10행의 worker 가 비어 있다 (`2026-09-02,CH-3B,ALARM,파티클 모니터 경고,20,`). 앞 원본의 마지막 행도 worker 가 빈 ALARM 행이었다.
- 데이터 2행의 detail 에만 부품 낱개 번호가 적혀 있다 (`샤워헤드(SH-2200) 교체 — SH2200-B-0412 탈거 · SH2200-B-0413 장착`). 낱개 번호를 담는 열은 따로 없다.
- 열 이름 여섯 개와 차례가 앞 원본과 같다.

## 앞 원본과의 관계 (센 값만 적는다)
- 앞 원본 archivist/inbox/2026-09-08-equipment-history/423efc74-8819-445a-bb81-90ca388034fd-equipment_history.csv 는 2026-07-01~08-20 이다.
- 이 부록은 2026-08-26 에서 시작하므로 08-21~08-25 닷새는 두 파일 어디에도 행이 없다.
- 두 파일의 기간이 겹치지 않으므로 같은 사건이 두 번 적힌 행도 없다.

## 원본과 같은지
SHA-256 4b4c1e5eb3c5ea75144aefb6ed08bf2ab36f97f0aa7abd79d8eac28cb07ba181 — 채팅 서버의 업로드 경로에 있는 파일과 이 폴더의 사본이 같은 값이다.
사본은 읽기 전용(444)으로 두었다. 파일 이름의 앞 UUID 는 채팅 서버가 붙인 것이고, 사람이 올린 이름은 equipment_history_addendum.csv 다.

이 파일의 내용이 무엇을 뜻하는지는 아직 아무도 분석하지 않았다. 여기 적은 것은 세어 본 값과 형태뿐이다.
