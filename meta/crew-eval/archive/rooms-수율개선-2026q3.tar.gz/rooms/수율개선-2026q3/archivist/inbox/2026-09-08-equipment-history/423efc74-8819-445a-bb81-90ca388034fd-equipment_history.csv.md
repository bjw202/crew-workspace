---
room: 수율개선-2026q3
task: 10
kind: data
title: 설비 이력 원본 (챔버 6개, 2026-07-01~08-20)
created: 2026-09-09
updated: 2026-09-09
aliases: 설비이력, 설비이력원본, equipment-history, equipmenthistory, 챔버이력, 정비이력, maintenance-log, 설비이력csv
tags: 설비, 챔버, 이력, 정비, 세정, 알람, 원본, csv, chamber, equipment
sources: archivist/inbox/2026-09-08-equipment-history/423efc74-8819-445a-bb81-90ca388034fd-equipment_history.csv
status: valid
supersedes: none
---
열 6개 · 데이터 48행(머리글 1행을 더해 파일 49줄) · 2026-07-01~2026-08-20(51일) · 빈칸 1개(48행째 worker).

| 열 | 뜻 | 단위·값 |
|---|---|---|
| date | 사건이 일어난 날 | YYYY-MM-DD (한 행만 YYYY/MM/DD — 아래 "형식" 참고) |
| chamber | 설비(챔버) | CH-1A·CH-1B·CH-2A·CH-2B·CH-3A·CH-3B |
| event_type | 사건 종류 | ALARM·CAL·CLEAN·PART·PM·RECIPE |
| detail | 사건 내용 | 한국어 자유 문장 |
| duration_min | 걸린 시간 | 분 · 정수 10~240 |
| worker | 담당자 | 한국어 이름 · 한 행이 빈칸 |

## 챔버별 행 수 (합 48)
CH-1A 8 · CH-1B 8 · CH-2A 9 · CH-2B 7 · CH-3A 7 · CH-3B 9

## event_type 별 행 수 (합 48)
CLEAN 25 · CAL 6 · PM 6 · ALARM 5 · PART 4 · RECIPE 2

## worker 별 행 수 (합 48)
박세정 25 · 김정비 10 · 이공정 6 · 최계측 6 · 빈칸 1

## 형식에서 눈에 띈 것 (내용 해석이 아니라 형태만 적는다)
- 줄 끝이 CRLF(\r\n)다. 49줄 모두 그렇다. 마지막 줄에도 줄바꿈이 있다.
- 데이터 34행째의 date 가 `2026/08/03` 으로 다른 행과 구분자가 다르다 (`2026/08/03,CH-1A,ALARM,가스 유량 알람,10,이공정`).
- 데이터 48행째의 worker 가 비어 있다 (`2026-08-20,CH-3B,ALARM,파티클 모니터 경고,35,`).
- 모든 줄의 필드 수가 6으로 같고, 따옴표로 묶인 필드는 없다.
- 서로 다른 날짜는 33일이고, 그중 여러 행인 날이 여덟이다: 07-05 는 7행, 07-28 과 08-12 는 각 3행, 07-14·07-15·07-19·07-21·08-03 은 각 2행이다(여덟 날 합쳐 23행). 나머지 25일은 한 행씩이다. 08-03 은 `2026/08/03` 을 `-` 로 통일해 센 값이다.

## 원본과 같은지
SHA-256 664b06bffa85d19edcf7ac71b3c1ff1ba854dcf394dc5a4a8e0e4135edb8a04e — 채팅 서버의 업로드 경로에 있는 파일과 이 폴더의 사본이 같은 값이다.
사본은 읽기 전용(444)으로 두었다. 파일 이름의 앞 UUID 는 채팅 서버가 붙인 것이고, 사람이 올린 이름은 equipment_history.csv 다.

이 파일의 내용이 무엇을 뜻하는지는 아직 아무도 분석하지 않았다. 여기 적은 것은 세어 본 값과 형태뿐이다.
