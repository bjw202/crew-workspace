---
room: 수율개선-2026q3
task: 15
kind: data
title: 부품 입고 검사 성적서 원본 (부품 6종, 2026-07-03~08-21)
created: 2026-09-09
updated: 2026-09-09
aliases: 입고검사, 입고검사성적서, part-incoming-inspection, partincominginspection, 부품검사, 성적서, incoming-inspection, 수입검사, 부품입고, 검사성적서, 세번째원본
tags: 부품, 입고, 검사, 성적서, 규격, spec, 공급사, supplier, 샤워헤드, SH-2200, 원본, csv, 세번째원본, 회차4
sources: archivist/inbox/2026-09-09-part-incoming-inspection/28d181e9-647f-4b69-8fe7-554982ecd8de-part_incoming_inspection.csv
status: valid
supersedes: none
---
열 10개 · 데이터 34행(머리글 1행을 더해 파일 35줄) · recv_date 2026-07-03~2026-08-21 · 서로 다른 입고일 11 · 빈칸이 있는 열 셋(supplier 1행 · install_date 29행 · chamber 29행).

| 열 | 뜻 | 단위·값 |
|---|---|---|
| recv_date | 부품을 받은 날 | YYYY-MM-DD (한 행만 YYYY/MM/DD — 아래 "형식" 참고) |
| part_no | 부품 번호 | FR-300 · GV-80 · HC-40 · OR-15 · SH-2200 · TC-12 |
| serial | 부품 낱개 번호 | 영문·숫자 · 서로 다른 값 33개 (한 값이 두 행) |
| supplier | 공급사 | AlphaParts · BSTech · 한 행이 빈칸 |
| spec_item | 검사 항목 | flatness · hardness_dev · hole_dia_sd · leak_rate · resistance_dev · temp_dev |
| spec_max | 그 항목의 규격 상한 | 항목마다 한 값으로 고정 (아래 표) |
| measured | 잰 값 | 소수 · 단위는 unit 열에 있다 |
| unit | measured 의 단위 | degC · mm · pct · sccm · shoreA · um |
| install_date | 챔버에 단 날 | YYYY-MM-DD · 5행만 채워졌고 29행은 빈칸 |
| chamber | 단 설비(챔버) | CH-1A · CH-1B · CH-2B · CH-3B · 5행만 채워졌고 29행은 빈칸 |

## part_no 별 행 수 (합 34)
SH-2200 9 · FR-300 5 · GV-80 5 · HC-40 5 · OR-15 5 · TC-12 5

## spec_item 별 행 수와 규격 상한 (합 34)
hole_dia_sd 9행(spec_max 3.0) · flatness 5행(15.0) · hardness_dev 5행(3.0) · leak_rate 5행(1.0) · resistance_dev 5행(5.0) · temp_dev 5행(2.0)

## supplier 별 행 수 (합 34)
BSTech 17 · AlphaParts 16 · 빈칸 1

## unit 별 행 수 (합 34)
um 12 · degC 5 · pct 5 · sccm 5 · shoreA 5 · mm 2

## 입고일별 행 수 (합 34 · 서로 다른 날 11)
07-03 3 · 07-10 3 · 07-18 6 · 07-24 3 · 07-31 2 · 08-01 4 · 08-07 3 · 08-12 4 · 08-14 2 · 08-19 2 · 08-21 2

## 챔버에 달린 5행 (install_date 와 chamber 가 함께 채워진 행)
| 데이터 행 | recv_date | part_no | serial | spec_item | measured unit | install_date | chamber |
|---|---|---|---|---|---|---|---|
| 4 | 2026-07-10 | HC-40 | HC40-A-0771 | resistance_dev | 6.1 pct | 2026-07-15 | CH-1A |
| 7 | 2026-07-18 | SH-2200 | SH2200-B-0412 | hole_dia_sd | 4.8 um | 2026-07-28 | CH-3B |
| 10 | 2026-07-18 | SH-2200 | SH2200-B-0412 | hole_dia_sd | 4.8 um | 2026-07-28 | CH-3B |
| 18 | 2026/08/01 | SH-2200 | SH2200-A-1187 | hole_dia_sd | 2.1 um | 2026-08-06 | CH-2B |
| 25 | 2026-08-12 | OR-15 | OR15-B-3301 | hardness_dev | 2.4 shoreA | 2026-08-18 | CH-1B |

데이터 7행과 10행은 서로 완전히 같은 행이므로, 여기 적힌 5행이 가리키는 부품 낱개는 넷이다.

## 형식에서 눈에 띈 것 (내용 해석이 아니라 형태만 적는다)
- 줄 끝이 LF 다. CR 이 든 줄은 0줄이다. 앞선 두 원본과 다르다 — 설비 이력 CSV 는 CRLF 였다.
- 모든 줄의 필드 수가 10 으로 같고, 따옴표로 묶인 필드는 없다. 마지막 줄에도 줄바꿈이 있다.
- 데이터 18행의 recv_date 가 `2026/08/01` 로 다른 행과 구분자가 다르다.
- **데이터 7행과 10행이 열 열 개 모두 같다** (`2026-07-18,SH-2200,SH2200-B-0412,BSTech,hole_dia_sd,3.0,4.8,um,2026-07-28,CH-3B`). 완전히 같은 행은 이 한 쌍뿐이고, serial 이 겹치는 값도 SH2200-B-0412 하나뿐이다.
- **같은 검사 항목 안에서 단위가 섞인 자리가 하나 있다.** hole_dia_sd 9행 중 7행은 um, 2행(데이터 19·21행)은 mm 다. spec_max 는 9행 모두 3.0 이다. measured 를 spec_max 와 그대로 견주면 이 두 행에서 잘못된 값이 나온다 — 단위를 맞춰 읽어야 한다.
- 데이터 6행의 supplier 가 비어 있다 (`2026-07-10,HC-40,HC40-A-0773,,resistance_dev,5.0,3.4,pct,,`).
- install_date 와 chamber 는 함께 차거나 함께 빈다. 한쪽만 찬 행은 0행이다.

## 원본과 같은지
SHA-256 03a7831edee72ff9493c6741a91bb70262be0d1a655c352f8e0f41bf6a21116c — 채팅 서버의 업로드 경로에 있는 파일과 이 폴더의 사본이 같은 값이다.
사본은 읽기 전용(444)으로 두었다. 파일 이름의 앞 UUID 는 채팅 서버가 붙인 것이고, 사람이 올린 이름은 part_incoming_inspection.csv 다.

이 파일의 내용이 무엇을 뜻하는지는 아직 아무도 분석하지 않았다. 여기 적은 것은 세어 본 값과 형태뿐이다.
