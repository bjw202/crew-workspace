---
room: 수율개선-2026q3
task: 21
kind: data
title: 부품 재측정 원본 (샤워헤드 2낱개, 2026-08-27~08-28)
created: 2026-09-09
updated: 2026-09-09
aliases: 재측정, 부품재측정, part-remeasure, partremeasure, 재측정성적서, 샤워헤드재측정, remeasure, 여섯번째원본, 탈거후재측정
tags: 부품, 재측정, 검사, 규격, spec, 공급사, supplier, 샤워헤드, SH-2200, 원본, csv, 부록, 회차5, 여섯번째원본
sources: archivist/inbox/2026-09-09-part-remeasure/521f2858-a080-4f86-b6a2-e5baf2b00d33-part_remeasure.csv
status: valid
supersedes: none
---
열 11개 · 데이터 2행(머리글 1행을 더해 파일 3줄) · remeasure_date 2026-08-27~2026-08-28 · 빈칸 0개.

| 열 | 뜻 | 단위·값 |
|---|---|---|
| serial | 부품 낱개 번호 | SH2200-B-0412 · SH2200-B-0413 |
| part_no | 부품 번호 | SH-2200 (2행 모두) |
| supplier | 공급사 | BSTech (2행 모두) |
| spec_item | 검사 항목 | hole_dia_sd (2행 모두) |
| spec_max | 그 항목의 규격 상한 | 3.0 (2행 모두) |
| incoming_date | 부품을 받은 날 | 2026-07-18 (2행 모두) |
| incoming_value | 받을 때 잰 값 | 소수 · 단위는 unit 열에 있다 |
| remeasure_date | 다시 잰 날 | 2026-08-27 · 2026-08-28 |
| remeasure_value | 다시 잰 값 | 소수 · 단위는 unit 열에 있다 |
| unit | incoming_value·remeasure_value 의 단위 | um (2행 모두) |
| note | 비고 | 한국어 자유 문장 |

## 두 행 전체 (데이터가 2행뿐이라 그대로 옮긴다)
| 데이터 행 | serial | incoming_date | incoming_value | remeasure_date | remeasure_value | unit | note |
|---|---|---|---|---|---|---|---|
| 1 | SH2200-B-0412 | 2026-07-18 | 4.8 | 2026-08-28 | 5.1 | um | 탈거 후 재측정 (품질팀) |
| 2 | SH2200-B-0413 | 2026-07-18 | 2.7 | 2026-08-27 | 2.7 | um | 장착 직전 재확인 |

## 형식에서 눈에 띈 것 (내용 해석이 아니라 형태만 적는다)
- 줄 끝이 CRLF(\r\n)다. 3줄 모두 그렇다. 마지막 줄에도 줄바꿈이 있다.
- 모든 줄의 필드 수가 11로 같고, 따옴표로 묶인 필드는 없다. note 안에 쉼표가 든 행은 0행이다.
- 빈칸이 하나도 없다. 날짜 형식이 어긋난 행도 없다.
- 열 이름 열한 개 가운데 여섯(serial·part_no·supplier·spec_item·spec_max·unit)은 앞선 입고 검사 원본과 이름이 같고, 넷(incoming_date·incoming_value·remeasure_date·remeasure_value)은 이 파일에서 처음 나온다. 입고 검사 원본의 recv_date·measured 에 해당하는 이름이 incoming_date·incoming_value 로 바뀌어 있다.

## 앞 원본과의 관계 (센 값만 적는다)
- 앞 원본 archivist/inbox/2026-09-09-part-incoming-inspection/28d181e9-647f-4b69-8fe7-554982ecd8de-part_incoming_inspection.csv 에 두 낱개가 모두 있다.
  SH2200-B-0412 는 데이터 7행과 10행(서로 완전히 같은 두 행)에, SH2200-B-0413 은 데이터 8행에 있다.
- 두 낱개의 recv_date(2026-07-18) 와 measured(4.8 · 2.7 um) 가 이 파일의 incoming_date·incoming_value 와 값이 같다. 어긋난 자리는 0곳이다.
- 이 파일의 remeasure_date·remeasure_value 는 앞 원본에 없던 값이다.

## 원본과 같은지
SHA-256 d78e35fb4d5309e9c0d89186bff711c0955e5f864ae0b3393910aec9af490a00 — 채팅 서버의 업로드 경로에 있는 파일과 이 폴더의 사본이 같은 값이다.
사본은 읽기 전용(444)으로 두었다. 파일 이름의 앞 UUID 는 채팅 서버가 붙인 것이고, 사람이 올린 이름은 part_remeasure.csv 다.

이 파일의 내용이 무엇을 뜻하는지는 아직 아무도 분석하지 않았다. 여기 적은 것은 세어 본 값과 형태뿐이다.
