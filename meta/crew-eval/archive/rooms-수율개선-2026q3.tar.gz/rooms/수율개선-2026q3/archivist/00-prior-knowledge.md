---
room: 수율개선-2026q3
task: 1
kind: wiki
title: 이 과제 이전에 회사가 아는 것
created: 2026-09-08
updated: 2026-09-08
aliases: 사전지식, prior-knowledge, 선행지식, 기존지식
tags: 사전조사, knowledge, 색인
sources: 루트/knowledge/projects/수율개선-2026q3.md
status: valid
supersedes: none
---
없음.

## 무엇을 어떻게 찾았나
- 루트/knowledge/domain/ 이 비어 있고, 루트/knowledge/index.md 파일 자체가 없었다(이번 작업에서 새로 만듦).
- 루트/rooms/ 에는 이 방(수율개선-2026q3) 하나뿐이라 열어 볼 옛 방이 없다.
- 낱말 13개(수율·yield·로트·lot·설비·chamber·챔버·불량·defect·라인·line·particle·파티클)로 knowledge 안 .md 를 훑었으나,
  걸린 파일은 orchestrator 가 이번 과제로 만든 루트/knowledge/projects/수율개선-2026q3.md 하나뿐이었다.
- 그 파일은 이번 과제의 목표를 적은 것이지 앞선 앎이 아니므로, 사전 지식은 "없음"이다.

## 이 과제와 닿는 점
- 앞선 앎이 없으므로 이 방의 결론은 모두 이번 첨부 데이터에서 나와야 한다.
- 이 방에서 만든 페이지 중 다음 과제에도 쓰일 것은 승격 후보로 따로 적어 둔다.
