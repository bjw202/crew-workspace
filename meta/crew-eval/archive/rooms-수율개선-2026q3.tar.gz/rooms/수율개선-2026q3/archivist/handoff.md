task: 21
dispatch: 297
stage: reported
next: 다음 배분 대기 — 부록의 무결성 검사와 해석은 작업 22 몫이다
notes: archivist/task-21-notes.md
report: archivist/task-21-report.md
