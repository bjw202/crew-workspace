# 작업 7 노트

## 가설·계획
① yield-data.md 의 "계산은 누가 돌려도 같은 값이 나온다"를 확인된 범위로 좁힌다(같은 파일 39행과 어긋남).
② index.md 머리에 포함 규칙 한 줄을 적고 그 규칙대로 목록을 맞춘다. ③ 원본·남의 산출물은 손대지 않는다.

## 지금까지 확인한 것
- 어긋남 확인: 21행은 "누가 돌려도", 39행은 "다른 seed 로 돌려 본 사람은 아직 없다". 실제 확인된 것은
  researcher 가 같은 seed 로 1회 재현해 diff 0행(researcher/task-3-review-task2.md#행 45-53)뿐.
  seed 고정은 코드에서 직접 확인했다 — analysis.py 8행 import, 15행 SEED=20260908, 110행 random.Random(seed).
  → 21행을 "재현이 확인된 것은 한 번이다"로 바꾸고, 39행은 "코드가 그렇게 짜여 있다는 것이지 여러 번 확인된 사실이 아니다"로 맞췄다. 이력 줄 추가.
- 포함 규칙(내가 정함): 방 폴더 아래 파일을 다 넣는다(남의 폴더·handoff·notes·index 자신 포함). 빼는 것은
  .gitkeep 과 inbox 사이드카 둘뿐. 사이드카는 원본 줄의 비고에 적으므로 따로 세지 않는다.
  머리말 없는 파일의 kind 는 무엇인지 적는다(code·log·notes·report·handoff·state·chronicle·decisions·index).
- 수 맞춤: find 로 센 파일 28 = 표의 파일 행 28. 중복 0, 표에만 있는 경로 0, 표에 빠진 파일 0(파이썬 집합 대조).
- 회차 2 가 진행 중이라 새 파일이 늘어 있었다: analyst/task-5-* 다섯. 작업 5 판이 작업 2 판을 대체하고
  analyst/task-2-chamber-yield-drop.md 머리말이 status: void 로 바뀌어 있어, index 줄도 void + 대체 경로로 고쳤다
  (머리말과 어긋나면 머리말이 맞다는 규칙).
- 손대지 않은 것: 원본 CSV, 사이드카, analyst·researcher·orchestrator 파일.

## 읽은 파일
- archivist/wiki/yield-data.md, archivist/index.md, analyst/task-2-analysis.py(8·15·110행)
- researcher/task-3-review-task2.md#행 45-53, analyst/task-5-chamber-yield-drop.md 머리말, analyst/task-5-report.md,
  analyst/task-2-chamber-yield-drop.md 머리말, orchestrator/chronicle.md 꼬리

## 다음 한 걸음
- 서브에이전트 검토(등급 1) → 지적 반영 → 커밋 → task-7-report.md → 전송.

## 작업 7 통과 뒤 (message_id 148)
- orchestrator 가 통과 판정. 두 가지는 지금 하지 말고 회차 2 반영 배분 때 함께 하라고 했다. 지금은 대기.
  ① wiki/ch-3b-yield-drop.md 의 근거가 void 인 작업 2 판을 가리킨다 → analyst 최신 판으로 옮긴다.
     analyst 가 작업 8 로 한 판 더 내는 중이라 그것까지 끝난 뒤에 옮겨야 두 번 일하지 않는다.
  ② wiki/yield-data.md 20행 "자료 자체에 흠은 없다"가 뒤에 붙은 넷(빈칸·중복·0나눗셈·범위)보다 넓다
     → 확인한 그 넷으로 좁힌다. (작업 7 의 21행 손질과 같은 성격의 과장이다.)
- 두 가지 모두 orchestrator 의 state.md 에도 적혀 있다. 내 쪽 기록은 이 노트와 handoff 의 next 줄이다.
- (message_id 153) orchestrator 가 바로잡았다: 새 파일이 생길 때마다 index 를 미리 맞추지 마라 —
  그것도 일이고 일을 만드는 것은 orchestrator다. 미리 맞추면 검토받지 않은 변경이 쌓인다.
  index 맞추기는 회차 2 반영 배분 안에서 위 ①②와 함께 한 번에 한다. 확인 답장도 보내지 말라고 해서 보내지 않았다.

