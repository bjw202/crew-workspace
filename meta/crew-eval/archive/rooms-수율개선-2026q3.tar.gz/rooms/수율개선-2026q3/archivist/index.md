---
room: 수율개선-2026q3
task: 21
kind: wiki
title: 수율개선-2026q3 방의 파일 목록 (원본+산출물)
created: 2026-09-08
updated: 2026-09-09
aliases: 색인, index, 파일목록, room-index, 자료목록, 방색인
tags: 색인, 원본, 산출물
sources: none
status: valid
supersedes: none
---
포함 규칙: 이 방 폴더 아래의 파일을 빠짐없이 한 줄씩 적는다 — 남의 폴더 것도, handoff·notes 같은 진행 파일도, 이 index.md 자신도 넣는다. 빼는 것은 둘뿐이다: 빈 폴더 자리표시 .gitkeep 과 inbox 사이드카(원본 옆 <파일명>.md — 원본 줄의 비고에 적으므로 따로 세지 않는다).
세는 법: `find . -type f -not -path './.git/*' -not -name '.gitkeep' -not -path './archivist/inbox/*/*.md' | wc -l` 의 값이 `grep -c '^| ' index.md` 에서 머리글 1 을 뺀 값과 같아야 한다.
kind 는 머리말의 kind 를 그대로 옮긴다. 머리말이 없는 파일은 무엇인지 적는다(code·log·notes·report·handoff·state·chronicle·decisions).
status void 는 비고에 대체 경로를 적는다. 머리말과 어긋나면 머리말이 맞다 — 이 표를 고친다.
aliases·tags 열은 머리말의 **부분집합**이다. 자리가 좁아 골라 적을 수는 있으나, 머리말에 없는 낱말을 이 표에만 적지 않는다. 새 낱말이 필요하면 머리말에 먼저 넣는다.
**예외: 머리말이 없는 파일은 이 규칙에서 제외한다.** 코드·로그·노트·6줄 보고·handoff·state·chronicle·decisions·회고가 여기 해당한다. inbox 의 원본 파일은 제외가 아니다 — 원본에는 머리말을 붙일 수 없으나 옆의 사이드카가 그 머리말이므로, 원본 줄은 사이드카의 aliases·tags 를 견준다. 견줄 머리말이 없으므로 이 표의 낱말이 그 파일의 유일한 색인이고, 그래서 이 열을 자유롭게 적는다. 부분집합 검사는 머리말이 있는 파일에만 돌린다.
판이 겹칠 때: void 줄의 비고에 바로 다음 판과 함께 **현재 판**을 적고, 살아 있는 줄의 비고에 "현재 판"이라고 쓴다. 어느 것을 읽어야 하는지 한 줄만 보고 알게 하려는 것이다.

| 경로 | kind | 제목 | created | 누가 | aliases·tags | status | 비고 |
|---|---|---|---|---|---|---|---|
| archivist/inbox/2026-09-08-yield-by-lot/44cdd855-be6e-4b66-a014-e7eb3a056769-yield_by_lot.csv | data | 로트별 수율 원본 (1~3라인, 2026-07-01~08-25) | 2026-09-08 | 의뢰인(첨부) | 수율원본·로트별수율·yield-by-lot / 수율·로트·설비·챔버·불량·파티클·원본·csv | valid | 열 7개(lot_id·date·line·chamber·yield_pct[%]·defect_count[개]·particle_defects[개]) · 2026-07-01~08-25 · 672행 |
| analyst/task-2-chamber-yield-drop.md | analysis | 수율 하락은 CH-3B 한 챔버의 2026-07-29 계단 변화다 — 늘어난 불량은 전부 파티클 | 2026-09-08 | analyst | 수율하락원인·CH-3B·챔버별수율변화점·파티클급증·0729사건 / 수율·챔버·설비·변화점·changepoint·파티클·불량·3라인·분석·순열검정 | void | 대체: analyst/task-5-chamber-yield-drop.md (작업 5) → **현재 판 analyst/task-8-chamber-yield-drop.md (작업 8)** · 회차 1 주 산출물 · 152행 · 작업 3 교차 검토 통과 · 검토가 짚은 넷은 작업 5·8 에서 고쳐졌다 · 세 판 사이에 결론은 같고 앞 판 분석 값이 바뀌거나 사라진 것은 0 이며, 판 5 가 근거 수치를 새로 더했다(archivist/task-10-evidence.log#행 72-99) |
| analyst/task-2-evidence.log | log | 작업 2 근거 로그 (task-2-analysis.py 의 표준출력) | 2026-09-08 | analyst | 작업2근거·evidence-log·수율근거로그 / 근거, 로그, 재현, 수율, 챔버, 파티클 | valid | 314행 · 머리말 없음(로그) · 전수 검사는 행 11-14 · 작업 3 재현에서 diff 0행 |
| analyst/task-2-analysis.py | code | 작업 2 분석 스크립트 (변화점·순열검정·파티클 비율) | 2026-09-08 | analyst | 작업2스크립트·analysis-py·변화점코드 / 코드, 스크립트, 재현, 순열검정, 변화점, python | valid | 382행 · 머리말 없음(코드) · 표준 라이브러리만, seed=20260908 · 재현: cd analyst && python3 task-2-analysis.py |
| analyst/task-2-report.md | report | 작업 2 보고 — CH-3B 한 챔버, 07-29 계단 하락 | 2026-09-08 | analyst | 작업2보고·task-2-report / 보고, 수율, CH-3B, 분석 | valid | 6줄 보고 서식 · 머리말 없음 |
| researcher/task-3-review-task2.md | research | 작업 2 교차 검토 — 통과. 재현 314행 완전 일치, 핵심 수치 전부 근거 줄에 닿음, 고칠 문장 2개 | 2026-09-08 | researcher | 작업2검토·교차검토·review-task2·재현확인·CH-3B검증 / 검토, 교차검토, 재현, 검증, CH-3B, 수율, 파티클, 변화점, 판정 | valid | 110행 · 판정 통과 · 고칠 것(결론 불변)을 회차 2 로 넘김 — 상관 -0.900 해석, -3sd 처음 내려간 날, 인용 행 어긋남, 파티클 비율 두 정의 |
| researcher/task-3-report.md | report | 작업 3 보고 — 작업 2 검토 통과, 고칠 문장 셋 | 2026-09-08 | researcher | 작업3보고·task-3-report / 보고, 검토, 재현, 판정 | valid | 6줄 보고 서식 · 머리말 없음 · 결과물에 방 밖 파일(crew/proposals/003-researcher.md) 포함 |
| archivist/wiki/ch-3b-yield-drop.md | wiki | CH-3B 수율 하락 (2026-07-29 계단 변화, 파티클) — 후보는 07-28 하루이고, 정비 쪽은 물리쳐졌으며 샤워헤드 쪽은 판정 불가다 | 2026-09-08 | archivist | CH-3B·수율하락·수율저하·yield-drop·0729사건·0728후보·판정불가·대조군무효·비대칭판정 / 수율, 챔버, 설비, CH-3B, 변화점, 파티클, 불량, 설비이력, 대조군, 규격초과, 판정불가, 정정, 회차1, 회차2, 회차3, 회차4 | valid | 이 방의 주 위키 페이지 · 작업 4 에서 세우고 작업 9(회차 2 반영)에서 근거를 현재 판(작업 8)으로 옮김 · 작업 10 에서 판 셋을 견준 문장을 확인된 범위로 좁힘 · 작업 14(회차 3 반영)에서 원인 후보 절을 더함 · 작업 19(정정)에서 CH-2B 대조군이 자격을 잃은 것을 반영하고 옛 표 줄을 취소선으로 남김 · 작업 20(회차 4 반영)에서 보고서를 셋으로 고치고 이월 둘(판 2·5·8 못 박기, 뒤집힌 결론 하나+딸린 셋)을 고침 · 승격 후보 |
| archivist/wiki/yield-data.md | wiki | 이 방의 자료 — 로트별 수율 CSV 와 그 무결성 | 2026-09-08 | archivist | 자료·원본자료·수율데이터·yield-data·데이터무결성 / 자료, 원본, csv, 수율, 로트, 챔버, 무결성, 회차1 | valid | 원본 CSV 의 열·기간·무결성과 재현 방법 · 작업 4 에서 세우고 작업 7·9 에서 두 문장을 확인된 범위로 좁힘 · 작업 10 에서 이 줄의 tags 에만 있던 "회차2" 를 뗐다(머리말에 없다 — 회차 2 반영 사실은 그 페이지 이력 절에 있다) · 작업 14 에서 "이 방의 원본은 한 개뿐"이 뒤집혀 고쳤다(원본이 둘이 됐다) · 작업 15 에서 다시 "둘"이 뒤집혀 셋으로 고쳤다 · 작업 19 에서 "새 자료를 아직 아무도 분석하지 않았다"가 뒤집혀 고쳤다 · 작업 21 에서 "셋"이 다시 뒤집혀 여섯으로 고치고, 무결성 문장의 범위를 앞 원본 672행으로 좁힌 뒤 부록 109행을 더했다 |
| archivist/00-prior-knowledge.md | wiki | 이 과제 이전에 회사가 아는 것 | 2026-09-08 | archivist | 사전지식·prior-knowledge·선행지식·기존지식 / 사전조사, knowledge, 색인 | valid | 결론 "없음" — knowledge/domain 이 비어 있고 옛 방이 없다 |
| archivist/task-1-report.md | report | 작업 1 보고 — 원본 들이기·색인·사전 지식 | 2026-09-08 | archivist | 작업1보고·task-1-report·원본들이기보고 / 보고, 색인, 원본, 사전지식 | valid | 6줄 보고 서식 |
| archivist/task-4-report.md | report | 작업 4 보고 — 회차 1 반영(위키·색인·사이드카) | 2026-09-08 | archivist | 작업4보고·task-4-report·회차1반영보고 / 보고, 회차반영, 위키, 색인, 사이드카 | valid | 6줄 보고 서식 |
| analyst/task-2-notes.md | notes | 작업 2 노트 | 2026-09-08 | analyst | 작업2노트·task-2-notes / 노트, 진행, 분석 | valid | 진행 파일(머리말 없음) · chronicle 이 작업 2 결과물로 적지 않았으나 방에 있는 파일이라 색인함 |
| researcher/task-3-notes.md | notes | 작업 3 노트 | 2026-09-08 | researcher | 작업3노트·task-3-notes / 노트, 진행, 검토 | valid | 진행 파일(머리말 없음) · chronicle 5행이 작업 3 결과물로 적은 파일 |
| archivist/task-1-notes.md | notes | 작업 1 노트 | 2026-09-08 | archivist | 작업1노트·task-1-notes / 노트, 진행, 색인 | valid | 진행 파일(머리말 없음) |
| archivist/task-4-notes.md | notes | 작업 4 노트 | 2026-09-08 | archivist | 작업4노트·task-4-notes / 노트, 진행, 회차반영 | valid | 진행 파일(머리말 없음) |
| analyst/task-5-chamber-yield-drop.md | analysis | 수율 하락은 CH-3B 한 챔버의 2026-07-29 계단 변화다 — 늘어난 불량은 전부 파티클 (검토 반영 2판) | 2026-09-08 | analyst | 수율하락원인·CH-3B·2판·개정판·revised·0729사건 / 수율·챔버·변화점·파티클·불량·CH-3B·분석·개정·검토반영 | void | 대체: **현재 판 analyst/task-8-chamber-yield-drop.md (작업 8)** · 202행 · supersedes analyst/task-2-chamber-yield-drop.md · 검토 지적 넷을 고쳤다 · 결론은 옛 판과 같고 옛 판 수치가 바뀐 것은 0 이며, 이 판에서 근거 수치가 새로 더해졌다(analyst/task-5-report.md · archivist/task-10-evidence.log#행 72-99) |
| analyst/task-5-evidence.log | log | 작업 5 근거 로그 (task-5-analysis.py 의 표준출력) | 2026-09-08 | analyst | 작업5근거·evidence-log5·정정근거로그 / 근거, 로그, 재현, 상관, 기준선 | valid | 109행 · 머리말 없음 · 구간별 상관·-3sd 첫날·파티클 비율 두 정의를 새로 계산 |
| analyst/task-5-analysis.py | code | 작업 5 재계산 스크립트 | 2026-09-08 | analyst | 작업5스크립트·analysis5-py·정정계산코드 / 코드, 스크립트, 재현, python | valid | 165행 · 머리말 없음 · 작업 2 근거 파일을 고치지 않고 따로 다시 계산 |
| analyst/task-5-report.md | report | 작업 5 보고 — 검토 지적 넷 반영, 수치 불변 | 2026-09-08 | analyst | 작업5보고·task-5-report·정정보고 / 보고, 정정, 검토반영 | valid | 6줄 보고 서식 · 머리말 없음 |
| analyst/task-5-notes.md | notes | 작업 5 노트 | 2026-09-08 | analyst | 작업5노트·task-5-notes / 노트, 진행, 정정 | valid | 진행 파일(머리말 없음) |
| orchestrator/chronicle.md | chronicle | 통과한 작업 한 줄씩 (추가만) | 2026-09-08 | orchestrator | 연대기·chronicle·통과기록·작업이력 / 이력, 회차, 작업, 추가만 | valid | 불변(추가만) · 무슨 일이 있었나를 여기서 잘라 읽는다 |
| orchestrator/decisions.md | decisions | 결정 원장 — 사람의 결재·판정과 봇이 정한 것 (추가만) | 2026-09-08 | orchestrator | 결정원장·decisions·결재기록·판정 / 결정, 결재, 판정, 추가만 | valid | 불변(추가만) · 왜 그렇게 정했나를 작업 번호로 찾는다 |
| orchestrator/state.md | state | 회차·커서·대기 목록·작업표 | 2026-09-08 | orchestrator | 상태파일·state·작업표·회차상태 / 상태, 회차, 작업표, 진행 | valid | 진행 파일 · orchestrator 가 갱신한다 |
| analyst/handoff.md | handoff | analyst 의 지금 작업과 단계 (6줄) | 2026-09-08 | analyst | analyst핸드오프·handoff-analyst / 진행, 상태, handoff | valid | 진행 파일(머리말 없음) |
| archivist/handoff.md | handoff | archivist 의 지금 작업과 단계 (6줄) | 2026-09-08 | archivist | archivist핸드오프·handoff-archivist / 진행, 상태, handoff | valid | 진행 파일(머리말 없음) |
| researcher/handoff.md | handoff | researcher 의 지금 작업과 단계 (6줄) | 2026-09-08 | researcher | researcher핸드오프·handoff-researcher / 진행, 상태, handoff | valid | 진행 파일(머리말 없음) |
| archivist/index.md | wiki | 수율개선-2026q3 방의 파일 목록 (원본+산출물) | 2026-09-08 | archivist | 색인·index·파일목록·room-index·자료목록 / 색인, 원본, 산출물 | valid | 이 표 자신 · kind 는 머리말 그대로 wiki 다 · 포함 규칙은 위 머리에 있다 |
| archivist/task-7-notes.md | notes | 작업 7 노트 | 2026-09-08 | archivist | 작업7노트·task-7-notes / 노트, 진행, 색인규칙 | valid | 진행 파일(머리말 없음) |
| archivist/task-7-report.md | report | 작업 7 보고 — 재현 주장 범위 좁힘·색인 포함 규칙 | 2026-09-08 | archivist | 작업7보고·task-7-report·색인규칙보고 / 보고, 색인, 규칙, 위키 | valid | 6줄 보고 서식 |
| reporter/handoff.md | handoff | reporter 의 지금 작업과 단계 (6줄) | 2026-09-08 | reporter | reporter핸드오프·handoff-reporter / 진행, 상태, handoff | valid | 진행 파일(머리말 없음) |
| reporter/task-6-notes.md | notes | 작업 6 노트 | 2026-09-08 | reporter | 작업6노트·task-6-notes / 노트, 진행, 보고서 | valid | 진행 파일(머리말 없음) · 작업 6 진행 중 |
| analyst/task-8-chamber-yield-drop.md | analysis | 수율 하락은 CH-3B 한 챔버의 2026-07-29 계단 변화다 — 늘어난 불량은 전부 파티클 (검토 반영 3판) | 2026-09-08 | analyst | 수율하락원인·CH-3B·3판·개정판·0729사건·chamber-yield-drop / 수율·챔버·변화점·파티클·불량·CH-3B·분석·개정 | valid | **현재 판** · 204행 · supersedes analyst/task-5-chamber-yield-drop.md · 결론은 작업 2 판과 같고 앞 판 수치가 바뀐 것은 0 이다 · analyst/task-8-report.md 의 "글자 그대로 같다"는 판 5→8 사이에서 맞고, 판 2→5 에는 새 근거 수치가 더해졌다(archivist/task-10-evidence.log#행 72-99) |
| analyst/task-8-evidence.log | log | 작업 8 근거 로그 (판 사이 diff 와 계수 확인) | 2026-09-08 | analyst | 작업8근거·evidence-log8·정정근거로그3판 / 근거, 로그, diff, 정정 | valid | 102행 · 머리말 없음 |
| analyst/task-8-report.md | report | 작업 8 보고 — 자기 서술 숫자 정정, 수치 불변 | 2026-09-08 | analyst | 작업8보고·task-8-report / 보고, 정정, 3판 | valid | 6줄 보고 서식 · 머리말 없음 |
| analyst/task-8-notes.md | notes | 작업 8 노트 | 2026-09-08 | analyst | 작업8노트·task-8-notes / 노트, 진행, 정정 | valid | 진행 파일(머리말 없음) |
| reporter/task-6-yield-drop-report.md | report | 3라인 수율 하락 보고 — CH-3B 한 챔버가 2026-07-29 하루 만에 3.61%p 떨어졌고 늘어난 불량은 전부 파티클이다 | 2026-09-08 | reporter | 수율하락보고서·CH-3B보고·의뢰인보고·yield-drop-report·0729보고 / 보고서, 수율, 챔버, CH-3B, 파티클, 변화점 | valid | 의뢰인이 읽는 문서 · 142행 · 반영 범위 작업 8 까지 · 1차 반려 뒤 두 문장 고쳐 통과 |
| reporter/task-6-report.md | report | 작업 6 보고 — 의뢰인용 CH-3B 수율 하락 보고서 완료 | 2026-09-08 | reporter | 작업6보고·task-6-report·reporter보고 / 보고, 보고서 | void | 대체: reporter/task-6-report-2.md (작업 6 재보고) · 6줄 보고 서식 · 20행 · 검토 1차 불통과 |
| reporter/task-6-report-2.md | report | 작업 6 재보고 — 반려 사유 둘(t 값 풀이·인과 단정)을 고쳐 다시 냄 | 2026-09-08 | reporter | 작업6재보고·task-6-report-2·재보고 / 보고, 재보고, 작업6 | valid | **현재 보고** · supersedes reporter/task-6-report.md · 6줄 보고 서식 · 20행 |
| archivist/task-9-notes.md | notes | 작업 9 노트 | 2026-09-08 | archivist | 작업9노트·task-9-notes / 노트, 진행, 회차반영 | valid | 진행 파일(머리말 없음) |
| archivist/task-9-report.md | report | 작업 9 보고 — 회차 2 반영(위키 두 쪽·판 계보·색인) | 2026-09-08 | archivist | 작업9보고·task-9-report·회차2반영보고 / 보고, 회차반영, 위키, 색인, 판계보 | valid | 6줄 보고 서식 |
| orchestrator/retro-2.md | retro | 회차 2 회고 — 숫자·걸린 것·고칠 것 | 2026-09-08 | orchestrator | 회차2회고·retro-2·회고 / 회고, 회차, 개선, 제안 | valid | 머리말 없음(회고) · 회차 2 가 닫힐 때 orchestrator 가 남겼다 |
| archivist/inbox/2026-09-08-equipment-history/423efc74-8819-445a-bb81-90ca388034fd-equipment_history.csv | data | 설비 이력 원본 (챔버 6개, 2026-07-01~08-20) | 2026-09-09 | 의뢰인(첨부) | 설비이력·설비이력원본·equipment-history·챔버이력·정비이력 / 설비, 챔버, 이력, 정비, 세정, 알람, 원본, csv | valid | 열 6개(date·chamber·event_type·detail·duration_min[분]·worker) · 2026-07-01~08-20(51일) · 48행 · CLEAN 25·CAL 6·PM 6·ALARM 5·PART 4·RECIPE 2 · 사이드카에 SHA-256 과 형식 주의 셋 |
| archivist/task-10-evidence.log | log | 작업 10 근거 로그 (설비 이력 CSV 세기·판 셋 숫자 토큰 대조) | 2026-09-09 | archivist | 작업10근거·evidence-log10·설비이력근거·판대조로그 / 근거, 로그, 색인, 설비이력, 판대조 | valid | 머리말 없음(로그) · 판 셋 대조는 6절 |
| archivist/task-10-notes.md | notes | 작업 10 노트 | 2026-09-09 | archivist | 작업10노트·task-10-notes / 노트, 진행, 색인, 원본들이기 | valid | 진행 파일(머리말 없음) |
| archivist/task-10-report.md | report | 작업 10 보고 — 설비 이력 원본 들이기·색인·정정 둘 | 2026-09-09 | archivist | 작업10보고·task-10-report·설비이력들이기보고 / 보고, 색인, 원본, 정정 | valid | 6줄 보고 서식 |
| analyst/task-11-equipment-history-vs-yield.md | analysis | 설비 이력은 07-29 하락의 원인을 하나로 정하지 못한다 — 후보는 07-28 CH-3B 의 정비와 샤워헤드 교체가 겹친 하루로 좁혀지고, 정비 일반·부품 교체 일반·계측 교정은 대조군이 무너뜨린다 | 2026-09-09 | analyst | 설비이력대조·equipment-history-vs-yield·0728정비·샤워헤드교체·SH-2200·대조군분석 / 설비이력, 정비, PM, PART, 샤워헤드, 대조군, 수율, CH-3B, 창길이, 검토반영 | valid | 회차 3 주 산출물 · 281행 · supersedes none — 작업 8 판을 대체하지 않고 그 판이 비워 둔 자리를 메운다 · 작업 12 교차 검토 통과 · 검토가 낸 필수 정정 둘을 같은 작업 안에서 고쳤다 · **작업 16 이 이 문서의 결론 하나를 뒤집었다** — 샤워헤드 쪽을 물리치던 CH-2B 대조군이 자격을 잃었다 · 대체가 아니므로 머리말 status 는 valid 그대로이고 수치도 바뀌지 않았다 · 작업 16 이 이월 정정 3건을 이 파일 안에서 고쳤다(행 번호는 밀지 않았다) · **8절 둘째 [추정](그날의 시공 상태)의 근거가 반쪽이 됐다** — 근거 둘 가운데 "같은 부품 교체(CH-2B)가 아무 일도 만들지 않았다" 쪽이 무너졌고 남은 것은 "같은 정비(CH-3A)" 하나다 |
| analyst/task-11-evidence.log | log | 작업 11 근거 로그 (설비 이력과 로트 수율의 대조, task-11-analysis.py 의 표준출력) | 2026-09-09 | analyst | 작업11근거·evidence-log11·설비이력대조로그 / 근거, 로그, 재현, 설비이력, 대조군, 창길이 | valid | 555행 · 머리말 없음(로그) · 표준편차 규약은 3행, 창 길이 민감도는 [10]절(427~551행) |
| analyst/task-11-analysis.py | code | 작업 11 분석 스크립트 (이벤트 전후 창·Welch t·변화점·창 길이 민감도) | 2026-09-09 | analyst | 작업11스크립트·analysis11-py·설비이력분석코드 / 코드, 스크립트, 재현, python, 설비이력 | valid | 1121행 · 머리말 없음(코드) · 표준 라이브러리만, seed=20260909 · 재현: cd analyst && python3 task-11-analysis.py > task-11-evidence.log |
| analyst/task-11-citation-check.py | code | 작업 11 인용 전수 대조 스크립트 | 2026-09-09 | analyst | 작업11인용대조코드·citation-check-py / 코드, 스크립트, 인용대조, python | valid | 113행 · 머리말 없음(코드) · 재현: python3 task-11-citation-check.py > task-11-citation-check.log |
| analyst/task-11-citation-check.log | log | 작업 11 인용 전수 대조 결과 (110곳, 어긋남 0곳) | 2026-09-09 | analyst | 작업11인용대조·citation-check-log·인용대조결과 / 근거, 로그, 인용대조, 전수검사 | valid | 181행 · 머리말 없음(로그) · 인용 110곳의 내역은 log11 53곳·eq 52곳·task-8 판 5곳이다 |
| analyst/task-11-notes.md | notes | 작업 11 노트 | 2026-09-09 | analyst | 작업11노트·task-11-notes / 노트, 진행, 분석, 설비이력 | valid | 47행 · 진행 파일(머리말 없음) |
| analyst/task-11-report.md | report | 작업 11 보고 — 반려 반영, 07-20 정기 세정을 후보에서 내림 | 2026-09-09 | analyst | 작업11보고·task-11-report / 보고, 분석, 설비이력, 반려반영 | valid | 6줄 보고 서식 · 머리말 없음 · 반려를 반영해 다시 낸 보고다 |
| researcher/task-12-cross-review.md | research | 작업 11 교차 검토 — 수치는 전부 재현되고 결론은 세 손잡이 모두에 견고하다, 다만 "후보 범위 안에 두 건뿐"이라는 문장 하나가 사실과 다르다 | 2026-09-09 | researcher | 작업11교차검토·task-11-cross-review·설비이력검토·재계산검증 / 교차검토, 검증, 재현, 재계산, 민감도, 판정, CH-3B | valid | 250행 · 판정 통과 · 필수 정정 둘과 권고 셋을 냈고 analyst 가 같은 작업 안에서 모두 반영했다 |
| researcher/task-12-evidence.log | log | 작업 12 근거 로그 (task-12-verify.js 의 표준출력) | 2026-09-09 | researcher | 작업12근거·evidence-log12·교차검토근거로그 / 근거, 로그, 재계산, 검증, 교차검토 | valid | 331행 · 머리말 없음(로그) · 어긋난 행 0 |
| researcher/task-12-verify.js | code | 작업 12 재계산 코드 (원본 CSV 둘에서 JavaScript 로 새로 구현) | 2026-09-09 | researcher | 작업12코드·verify-js·재구현검증코드 / 코드, 스크립트, 재계산, javascript, 교차검토 | valid | 424행 · 머리말 없음(코드) · 실행: node task-12-verify.js > task-12-evidence.log |
| researcher/task-12-subreview.md | research | 교차 검토 문서(task-12-cross-review.md) 자체 검토 — 핵심 주장 정정 1 은 맞고 재계산도 그대로 재현되나, 플라시보 절과 정정 2 에 과장 셋이 있다 | 2026-09-09 | researcher | 교차검토재검토·subreview-12·task-12-subreview·검토의검토 / 재검토, 검증, 인용대조, 재현, 과장, 교차검토 | valid | 147행 · 검토 등급 1 의 서브에이전트 검토 결과 · 잡은 잘못 셋을 researcher 가 코드로 다시 확인해 고쳤다 |
| researcher/task-12-notes.md | notes | 작업 12 노트 | 2026-09-09 | researcher | 작업12노트·task-12-notes / 노트, 진행, 교차검토 | valid | 127행 · 진행 파일(머리말 없음) |
| researcher/task-12-report.md | report | 작업 12 보고 — 작업 11 교차 검토 통과, 필수 정정 둘 | 2026-09-09 | researcher | 작업12보고·task-12-report / 보고, 교차검토, 판정 | valid | 6줄 보고 서식 · 머리말 없음 · 그 세션의 PATH 고장으로 커밋하지 못했다고 적혀 있다 |
| reporter/task-13-equipment-history-report.md | report | CH-3B 수율 하락의 원인 후보는 2026-07-28 하루로 좁혀진다 — 그날 겹친 정기 정비와 샤워헤드 교체는 이 자료로 가를 수 없다 | 2026-09-09 | reporter | 설비이력보고서·equipment-history-report·0728보고·CH-3B원인후보·공정엔지니어보고서 / 보고서, 설비이력, 정비, 샤워헤드, 대조군, 수율, CH-3B, 0728 | valid | 공정 엔지니어가 읽는 문서 · 263행 · 반영 범위 작업 12 까지 · 반려 1회로 일곱 자리를 고쳤고 수치와 결론은 바뀌지 않았다 · **CH-2B 대목(32·119-130·212·227행)은 작업 16 이 뒤집은 자리이고 작업 18 보고서가 그 자리를 갱신했다** — 지금 상태는 reporter/task-18-part-inspection-report.md 를 읽는다 · 이 문서에서 CH-2B 가 나오는 줄은 모두 11 곳이다(10·32·119·126·128·130·138·197·212·227·261) · 뒤집힌 자리는 위에 적은 32·119-130·212·227 이고, 나머지 넷(10 tags · 138 표 머리글 · 197 작업자 · 261 재계산)은 뒤집힌 자리가 아니다 |
| reporter/task-13-review.log | log | 작업 13 초고 검토 로그 (검토 서브에이전트) | 2026-09-09 | reporter | 작업13검토로그·task-13-review-log / 근거, 로그, 검토, 인용대조 | valid | 292행 · 머리말 없음(로그) · 초고는 고치지 않고 이 파일만 새로 썼다 |
| reporter/task-13-notes.md | notes | 작업 13 노트 | 2026-09-09 | reporter | 작업13노트·task-13-notes / 노트, 진행, 보고서 | valid | 59행 · 진행 파일(머리말 없음) · 반려로 고친 자리 목록이 여기 있다 |
| reporter/task-13-report.md | report | 작업 13 보고 — 반려가 짚은 일곱 자리 반영, 수치 불변 | 2026-09-09 | reporter | 작업13보고·task-13-report / 보고, 보고서, 반려반영 | valid | 6줄 보고 서식 · 머리말 없음 |
| archivist/wiki/equipment-history-data.md | wiki | 이 방의 자료 — 설비 이력 CSV 와 그 한계 | 2026-09-09 | archivist | 설비이력자료·equipment-history-data·챔버이력·두번째원본·설비이력부록 / 자료, 원본, csv, 설비, 이력, 정비, 회차3, 회차5, 부록 | valid | 작업 14 에서 새로 세운 위키 · 둘째 원본의 세어 본 값과 회차 3 이 쓰면서 드러난 한계를 한자리에 모았다 · 작업 21 에서 "08-21 이후 이력이 없다"가 뒤집혀 08-21~08-25 닷새로 좁히고 부록 10행을 더했다 |
| archivist/task-14-notes.md | notes | 작업 14 노트 | 2026-09-09 | archivist | 작업14노트·task-14-notes / 노트, 진행, 회차반영 | valid | 진행 파일(머리말 없음) |
| archivist/task-14-evidence.log | log | 작업 14 근거 로그 (색인 전수 대조·부분집합 검사) | 2026-09-09 | archivist | 작업14근거·evidence-log14·색인전수검사 / 근거, 로그, 색인, 전수검사 | valid | 머리말 없음(로그) |
| archivist/task-14-report.md | report | 작업 14 보고 — 회차 3 반영(위키 세 쪽·색인·규칙 예외) | 2026-09-09 | archivist | 작업14보고·task-14-report·회차3반영보고 / 보고, 회차반영, 위키, 색인, 규칙 | valid | 6줄 보고 서식 |
| orchestrator/retro-3.md | retro | 회차 3 회고 — 숫자·걸린 것·고칠 것 | 2026-09-09 | orchestrator | 회차3회고·retro-3·회고 / 회고, 회차, 개선, 제안 | valid | 20행 · 머리말 없음(회고) · 회차 3 이 닫힐 때 orchestrator 가 남겼다 |
| archivist/inbox/2026-09-09-part-incoming-inspection/28d181e9-647f-4b69-8fe7-554982ecd8de-part_incoming_inspection.csv | data | 부품 입고 검사 성적서 원본 (부품 6종, 2026-07-03~08-21) | 2026-09-09 | 의뢰인(첨부) | 입고검사·입고검사성적서·part-incoming-inspection·부품검사·세번째원본 / 부품, 입고, 검사, 성적서, 규격, spec, 공급사, supplier, 샤워헤드, SH-2200, 원본, csv | valid | 열 10개(recv_date·part_no·serial·supplier·spec_item·spec_max·measured·unit·install_date·chamber) · 2026-07-03~08-21(서로 다른 입고일 11) · 34행 · SH-2200 9행·나머지 5종 각 5행 · 사이드카에 SHA-256 과 형식 주의 넷 |
| archivist/wiki/part-inspection-data.md | wiki | 이 방의 자료 — 부품 입고 검사 성적서 CSV 와 그 한계 | 2026-09-09 | archivist | 입고검사자료·part-inspection-data·부품검사자료·성적서자료·세번째원본·부품재측정 / 자료, 원본, csv, 부품, 입고, 검사, 성적서, 규격, 샤워헤드, SH-2200, 회차4, 회차5, 재측정 | valid | 작업 15 에서 새로 세운 위키 · 셋째 원본의 세어 본 값과 한계를 한자리에 모았다 · 작업 19 에서 "아직 아무도 분석하지 않았다"가 뒤집혀 고쳤다 — 작업 16·17 이 이 자료를 썼다 · 작업 20 에서 작업 18 보고서를 근거표에 더함 · 작업 21 에서 재측정 자료 2행을 더했다(뒤집힌 문장은 없다) |
| archivist/task-15-notes.md | notes | 작업 15 노트 | 2026-09-09 | archivist | 작업15노트·task-15-notes / 노트, 진행, 원본들이기 | valid | 진행 파일(머리말 없음) |
| archivist/task-15-evidence.log | log | 작업 15 근거 로그 (원본 들이기·세어 본 값·색인 전수 대조) | 2026-09-09 | archivist | 작업15근거·evidence-log15·입고검사세기 / 근거, 로그, 원본, 세기, 색인, 전수검사 | valid | 머리말 없음(로그) |
| archivist/task-15-report.md | report | 작업 15 보고 — 부품 입고 검사 성적서 들이기와 색인·위키 갱신 | 2026-09-09 | archivist | 작업15보고·task-15-report·입고검사들이기보고 / 보고, 원본, 색인, 위키, 사이드카 | valid | 6줄 보고 서식 · 머리말 없음 |
| analyst/task-16-part-inspection-vs-yield.md | analysis | 입고 검사 성적서가 07-28 두 후보를 비대칭으로 가른다 — 정비 쪽은 물리쳐지고, 샤워헤드 쪽은 물리치던 CH-2B 대조군이 자격을 잃어 판정 불가로 남는다 (CH-3B 에 들어간 샤워헤드는 규격을 1.60배 벗어나 있었다) | 2026-09-09 | analyst | 입고검사대조·비대칭판정·판정불가·part-inspection-vs-yield·대조군무효·SH2200-B-0412 / 입고검사, 성적서, 규격초과, 샤워헤드, SH-2200, 정기정비, PM, PART, 대조군, CH-3B, CH-2B, CH-3A, 분석, 회차4 | valid | 회차 4 의 분석 판 · 작업 11 의 결론 하나(CH-2B 대조군)를 뒤집는다 · 교차 검토(작업 17)의 필수 3·보완 4 를 같은 파일 안에서 반영했다 |
| analyst/task-16-evidence.log | log | 작업 16 근거 로그 (세 자료 맞대기·창 다섯·짝짓기) | 2026-09-09 | analyst | 작업16근거·evidence-log16 / 근거, 로그, 입고검사, 대조군 | valid | 458행 · 머리말 없음(로그) |
| analyst/task-16-analysis.py | code | 작업 16 분석 스크립트 | 2026-09-09 | analyst | 작업16코드·task-16-analysis / 코드, 분석, 파이썬 | valid | 1024행 · 머리말 없음(코드) |
| analyst/task-16-citation-check.py | code | 작업 16 인용 검사기 | 2026-09-09 | analyst | 작업16인용검사·citation-check16 / 코드, 인용, 검사 | valid | 203행 · 머리말 없음(코드) |
| analyst/task-16-citation-check.log | log | 작업 16 인용 전수 대조 결과 | 2026-09-09 | analyst | 작업16인용로그·citation-check-log16 / 로그, 인용, 검사 | valid | 231행 · 머리말 없음(로그) · 인용 96곳 어긋남 0곳 |
| analyst/task-16-corrections.log | log | 작업 16 이월 정정 3건의 근거 | 2026-09-09 | analyst | 작업16정정로그·corrections-log16 / 로그, 정정, 이월 | valid | 161행 · 머리말 없음(로그) · task-11 을 같은 파일에서 고친 기록 |
| analyst/task-16-notes.md | notes | 작업 16 노트 | 2026-09-09 | analyst | 작업16노트·task-16-notes / 노트, 진행 | valid | 58행 · 진행 파일(머리말 없음) |
| analyst/task-16-report.md | report | 작업 16 보고 — 갈림 판정과 근거 파일 경로 | 2026-09-09 | analyst | 작업16보고·task-16-report / 보고, 판정 | valid | 6줄 보고 서식 · 머리말 없음 |
| researcher/task-17-cross-review.md | research | 작업 16 교차 검토 — 통과. 수치와 자기 서술 숫자가 전부 재현되고 짝짓기 열쇠는 유일하며 대조군 자격 상실에 반례가 없다. 다만 인용 셋이 어긋나고 이월 정정 하나가 덜 끝났으며 결론 한 줄이 같은 문서의 한계보다 세다 | 2026-09-09 | researcher | 작업16교차검토·task-16-cross-review·교차검토17·짝짓기검증·대조군무효검증 / 교차검토, 검증, 재현, 재계산, 인용대조, 반례, 짝짓기, 입고검사, 대조군, 판정, 회차4 | valid | 필수 정정 3건·보완 권고 4건을 달아 통과 · analyst 의 파이썬을 쓰지 않고 node 로 새로 구현해 재현 |
| researcher/task-17-verify.js | code | 작업 17 재구현 검증 스크립트 | 2026-09-09 | researcher | 작업17검증코드·task-17-verify / 코드, 검증, 재구현 | valid | 211행 · 머리말 없음(코드) |
| researcher/task-17-cite.js | code | 작업 17 인용 대조 스크립트 | 2026-09-09 | researcher | 작업17인용코드·task-17-cite / 코드, 인용, 검사 | valid | 34행 · 머리말 없음(코드) |
| researcher/task-17-cite.log | log | 작업 17 인용 대조 결과 | 2026-09-09 | researcher | 작업17인용로그·cite-log17 / 로그, 인용, 검사 | valid | 101행 · 머리말 없음(로그) |
| researcher/task-17-evidence.log | log | 작업 17 근거 로그 (재계산·짝짓기·반례 세기) | 2026-09-09 | researcher | 작업17근거·evidence-log17 / 근거, 로그, 검증, 반례 | valid | 175행 · 머리말 없음(로그) |
| researcher/task-17-notes.md | notes | 작업 17 노트 | 2026-09-09 | researcher | 작업17노트·task-17-notes / 노트, 진행 | valid | 82행 · 진행 파일(머리말 없음) |
| researcher/task-17-report.md | report | 작업 17 보고 — 통과 판정과 정정 7건 | 2026-09-09 | researcher | 작업17보고·task-17-report / 보고, 교차검토, 판정 | valid | 6줄 보고 서식 · 머리말 없음 |
| reporter/task-18-part-inspection-report.md | report | 07-28 두 후보는 반쪽만 갈렸다 — 정기 정비 쪽은 후보에서 내려가고, 샤워헤드 교체 쪽은 견줄 상대가 없어 판정 불가로 남는다 | 2026-09-09 | reporter | 입고검사보고서·part-inspection-report·0728판정보고·샤워헤드판정불가·규격초과부품보고 / 보고서, 입고검사, 규격초과, 샤워헤드, SH-2200, 정기정비, PM, 대조군, 판정불가, CH-3B, CH-2B | valid | 사람이 읽을 보고서 · 194행 · 반영 범위 작업 17 까지 · 회차 4 에 통과 · 두 후보 가르기까지 넣은 현재 판이다 — task-13 의 CH-2B 대목은 작업 16 이 뒤집은 자리라 낡았다 |
| reporter/task-18-notes.md | notes | 작업 18 노트 | 2026-09-09 | reporter | 작업18노트·task-18-notes / 노트, 진행 | valid | 57행 · 진행 파일(머리말 없음) |
| archivist/task-19-notes.md | notes | 작업 19 노트 | 2026-09-09 | archivist | 작업19노트·task-19-notes / 노트, 진행, 정정 | valid | 진행 파일(머리말 없음) |
| archivist/task-19-evidence.log | log | 작업 19 근거 로그 (정정 반영·색인 전수 대조) | 2026-09-09 | archivist | 작업19근거·evidence-log19·정정근거 / 근거, 로그, 정정, 색인, 전수검사 | valid | 머리말 없음(로그) |
| archivist/task-19-report.md | report | 작업 19 보고 — 작업 16 이 작업 11 을 뒤집은 것을 위키와 색인에 반영 | 2026-09-09 | archivist | 작업19보고·task-19-report·정정보고 / 보고, 정정, 위키, 색인 | valid | 6줄 보고 서식 · 머리말 없음 |
| reporter/task-18-review.log | log | 작업 18 검토 로그 | 2026-09-09 | reporter | 작업18검토로그·review-log18 / 로그, 검토, 보고서 | valid | 556행 · 머리말 없음(로그) · 검토 서브에이전트 2회(1회 불통과 → 반려 → 2회 통과)의 기록 |
| reporter/task-18-report.md | report | 작업 18 보고 | 2026-09-09 | reporter | 작업18보고·task-18-report / 보고, 보고서 | valid | 6줄 보고 서식 · 머리말 없음 |
| reporter/task-18-evidence.log | log | 작업 18 근거 로그 | 2026-09-09 | reporter | 작업18근거·evidence-log18 / 근거, 로그, 보고서 | valid | 34행 · 머리말 없음(로그) |
| archivist/task-20-notes.md | notes | 작업 20 노트 | 2026-09-09 | archivist | 작업20노트·task-20-notes / 노트, 진행, 회차반영 | valid | 진행 파일(머리말 없음) |
| archivist/task-20-evidence.log | log | 작업 20 근거 로그 (회차 4 반영·이월 다섯·색인 전수 대조) | 2026-09-09 | archivist | 작업20근거·evidence-log20·회차4반영근거 / 근거, 로그, 회차반영, 이월, 색인, 전수검사 | valid | 머리말 없음(로그) |
| archivist/task-20-report.md | report | 작업 20 보고 — 회차 4 반영과 이월 다섯 | 2026-09-09 | archivist | 작업20보고·task-20-report·회차4반영보고 / 보고, 회차반영, 이월, 위키, 색인 | valid | 6줄 보고 서식 · 머리말 없음 |
| orchestrator/retro-4.md | retro | 회차 4 회고 — 숫자·걸린 것·고칠 것 | 2026-09-09 | orchestrator | 회차4회고·retro-4·회고 / 회고, 회차, 개선, 제안 | valid | 19행 · 머리말 없음(회고) · 회차 4 가 닫힐 때 orchestrator 가 남겼다 |
| archivist/inbox/2026-09-09-yield-by-lot-addendum/fee7dd34-07cb-47a1-ab27-cb68fd3b59b5-yield_by_lot_addendum.csv | data | 로트별 수율 원본 부록 (1~3라인, 2026-08-26~09-03) | 2026-09-09 | 의뢰인(첨부) | 수율부록·로트별수율부록·yield-by-lot-addendum·수율추가분 / 수율·로트·설비·챔버·불량·파티클·원본·csv·부록·회차5 | valid | 열 7개(lot_id·date·line·chamber·yield_pct[%]·defect_count[개]·particle_defects[개]) · 2026-08-26~09-03 · 109행 · 앞 원본과 겹치는 lot_id 0 · 형식 흠 넷(완전 동일 행 한 쌍 L1719 · particle_defects 빈칸 1 · 날짜 2026/08/30 1 · 소문자 ch-3b 1) |
| archivist/inbox/2026-09-09-equipment-history-addendum/0712fc84-e908-4582-992b-63aebebca36d-equipment_history_addendum.csv | data | 설비 이력 원본 부록 (챔버 6개, 2026-08-26~09-02) | 2026-09-09 | 의뢰인(첨부) | 설비이력부록·equipment-history-addendum·챔버이력부록·정비이력부록 / 설비·챔버·이력·정비·세정·알람·부품교체·원본·csv·부록·회차5 | valid | 열 6개(date·chamber·event_type·detail·duration_min[분]·worker) · 2026-08-26~09-02 · 10행 · CLEAN 6·ALARM 2·PART 1·RECIPE 1 · worker 빈칸 1 · 08-21~08-25 닷새는 앞 원본에도 이 부록에도 없다 |
| archivist/inbox/2026-09-09-part-remeasure/521f2858-a080-4f86-b6a2-e5baf2b00d33-part_remeasure.csv | data | 부품 재측정 원본 (샤워헤드 2낱개, 2026-08-27~08-28) | 2026-09-09 | 의뢰인(첨부) | 부품재측정·part-remeasure·재측정성적서·샤워헤드재측정 / 부품·재측정·검사·규격·공급사·샤워헤드·SH-2200·원본·csv·회차5 | valid | 열 11개(serial·part_no·supplier·spec_item·spec_max·incoming_date·incoming_value·remeasure_date·remeasure_value·unit·note) · 값 단위는 um · 재측정일 2026-08-27~08-28 · 2행 · 빈칸 0 · 입고 값이 입고 검사 성적서와 어긋난 자리 0 |
| archivist/task-21-notes.md | notes | 작업 21 노트 | 2026-09-09 | archivist | 작업21노트·task-21-notes / 노트, 진행, 원본들이기 | valid | 진행 파일(머리말 없음) |
| archivist/task-21-evidence.log | log | 작업 21 근거 로그 (해시 대조·행 수 세기·색인 전수 대조) | 2026-09-09 | archivist | 작업21근거·evidence-log21·원본들이기근거 / 근거, 로그, 해시, 원본, 색인, 전수검사 | valid | 머리말 없음(로그) |
| archivist/task-21-report.md | report | 작업 21 보고 — 원본 셋 들이기와 사이드카·위키·색인 갱신 | 2026-09-09 | archivist | 작업21보고·task-21-report / 보고, 원본, 사이드카, 색인 | valid | 6줄 보고 서식 · 머리말 없음 |
