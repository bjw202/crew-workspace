# 작업 1 노트

## 가설·계획
첨부 들이기 → 사이드카 → index.md → knowledge 훑기 → 00-prior-knowledge.md → knowledge/index.md 방 줄.

## 지금까지 확인한 것
- 원본 CSV: 673행(머리글 1 + 데이터 672), 25551바이트, 열 7개.
  lot_id·date·line·chamber·yield_pct(%)·defect_count(개)·particle_defects(개).
  기간 2026-07-01~2026-08-25(56일). line 1·2·3 각 224행. chamber CH-1A/1B/2A/2B/3A/3B 각 112행. 빈칸 0.
- inbox 복사본은 원본과 바이트 동일(cmp 확인). 권한 444 로 잠금.
- 끝 조건 검사: grep -c '| data |' index.md = 1 · 00-prior-knowledge.md 25줄 존재 ·
  grep -c '^| 수율개선-2026q3 |' knowledge/index.md = 1.
- knowledge 사전 지식 없음: domain 비어 있음, index.md 부재(새로 만듦), 다른 방 없음,
  낱말 13개 훑기에 걸린 것은 orchestrator 가 만든 projects/수율개선-2026q3.md 하나뿐.
- git status: 두 저장소 모두 내 폴더(및 archivist 예외인 knowledge/index.md) 밖 변경 없음.

## 읽은 파일
- knowledge/projects/수율개선-2026q3.md (목표·별명)
- 업로드 CSV (head/tail/awk 집계)

## 다음 한 걸음
- 커밋 두 곳(rooms, knowledge) → 보고 작성 → 전송.
- 원격 저장소가 없어 push 는 건너뛴다(로컬 커밋만). 보고 "못 확인한 것"에 적는다.
