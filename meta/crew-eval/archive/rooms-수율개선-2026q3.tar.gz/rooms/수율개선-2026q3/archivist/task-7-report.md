---
room: 수율개선-2026q3
task: 7
kind: report
title: 작업 7 보고 — 재현 주장 범위 좁힘·색인 포함 규칙
created: 2026-09-08
updated: 2026-09-08
aliases: 작업7보고, task-7-report, 색인규칙보고
tags: 보고, 색인, 규칙, 위키, 재현
sources: archivist/wiki/yield-data.md, archivist/index.md, archivist/task-7-notes.md
status: valid
supersedes: none
---
작업: 7
결론: yield-data.md 의 재현 주장을 확인된 범위(researcher 1회·같은 seed)로 좁혀 같은 페이지의 "다른 seed 로 돌려 본 실행은 없다"와 맞췄고, index.md 머리에 포함 규칙을 적어 목록을 방의 파일 수와 맞췄다.
근거: 서브에이전트 검토(등급 1)에서 끝 조건 ①~③ 모두 통과. 규칙의 세는 법으로 센 파일 수 = 표의 파일 행 수(확인 시점 32), 표에만 있는 경로 0 · 표에 빠진 파일 0 · 중복 0(집합 대조). seed 고정은 analyst/task-2-analysis.py 8·15·110행에서 직접 확인. 원본 CSV SHA-256 580945bc463a…·권한 444 그대로. 커밋 9c7e1b8 은 archivist/ 4파일만.
내가 정한 것: 포함 규칙을 "다 넣고 둘만 뺀다"(.gitkeep · inbox 사이드카)로 정했다 — 뺄 것이 많을수록 다음 사람이 세는 수가 갈리기 때문이고, 사이드카는 원본 줄의 비고에 있어 두 번 세지 않으려는 것이다. kind 는 머리말이 있으면 그대로, 없으면 무엇인지 적기로 했다(code·log·notes·handoff 등). 검토 지적 1건(index 자기 줄의 kind 를 머리말대로 wiki 로)은 반영했다. 회차 2 가 도는 중이라 analyst/task-2-chamber-yield-drop.md 머리말이 이미 void 여서 index 줄도 void + 대체 경로(작업 5 판)로 고쳤다.
못 확인한 것: archivist/wiki/ch-3b-yield-drop.md 의 근거가 아직 작업 2 판(void)을 가리킨다 — 작업 5 판으로 옮기는 것은 회차 2 반영 배분에서 하겠다. 보고를 쓰는 사이 reporter 가 작업 6 파일 둘을 만들어 30행 → 32행으로 다시 맞췄다. 다른 봇이 일하는 중이라 행 수는 이렇게 움직인다 — 규칙대로 다시 세면 언제든 맞출 수 있다. 원격 저장소가 없어 push 는 못 했다.
결과물: archivist/wiki/yield-data.md · archivist/index.md · archivist/task-7-report.md · archivist/task-7-notes.md
