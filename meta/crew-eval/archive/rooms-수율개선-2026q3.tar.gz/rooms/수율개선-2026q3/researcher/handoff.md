task: 23
dispatch: 327
stage: reported
next: 작업 23 을 마쳤다. 보고를 방에 보냈다. 다음 배분을 기다린다.
notes: researcher/task-23-notes.md
report: researcher/task-23-report.md
