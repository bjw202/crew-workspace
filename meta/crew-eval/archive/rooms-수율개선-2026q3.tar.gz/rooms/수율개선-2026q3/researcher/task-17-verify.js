// 작업 17 교차 검토 — analyst 작업 16 의 수치를 node 로 새로 구현해 대조한다.
// analyst/task-16-analysis.py 는 읽지도 돌리지도 않았다. 원본 CSV 셋에서 다시 센다.
const fs = require('fs');
const ROOM = '<작업판>/rooms/수율개선-2026q3/';
const P_INSP = ROOM + 'archivist/inbox/2026-09-09-part-incoming-inspection/28d181e9-647f-4b69-8fe7-554982ecd8de-part_incoming_inspection.csv';
const P_YLD  = ROOM + 'archivist/inbox/2026-09-08-yield-by-lot/44cdd855-be6e-4b66-a014-e7eb3a056769-yield_by_lot.csv';
const P_EQ   = ROOM + 'archivist/inbox/2026-09-08-equipment-history/423efc74-8819-445a-bb81-90ca388034fd-equipment_history.csv';

const out = [];
const say = s => out.push(s);
const hr = t => { say(''); say('='.repeat(110)); say(t); say('='.repeat(110)); };

// ---- CSV 읽기: 파일 행 번호(머리글=1행)를 그대로 달아 둔다 ----
function readCsv(p) {
  const lines = fs.readFileSync(p, 'utf8').replace(/\r/g, '').replace(/\n$/, '').split('\n');
  const head = lines[0].split(',');
  const rows = lines.slice(1).map((l, i) => {
    const c = l.split(',');
    const o = { _line: i + 2 };           // 파일 행 번호
    head.forEach((h, j) => o[h] = (c[j] === undefined ? '' : c[j]));
    return o;
  });
  return { head, rows, nLines: lines.length };
}
// 날짜 정규화 — 원본에 2026/08/01 · 2026/08/03 처럼 슬래시 표기가 섞여 있다.
const nd = s => s.trim().replace(/\//g, '-');
const dayNo = s => Math.round(Date.parse(nd(s) + 'T00:00:00Z') / 86400000);
const dStr = n => new Date(n * 86400000).toISOString().slice(0, 10);

const insp = readCsv(P_INSP), yld = readCsv(P_YLD), eq = readCsv(P_EQ);
yld.rows.forEach(r => { r.d = dayNo(r.date); r.y = +r.yield_pct; r.dc = +r.defect_count; r.pd = +r.particle_defects; });
eq.rows.forEach(r => r.d = dayNo(r.date));

hr('[0] 적재 — 파일 행 수와 데이터 행 수');
say(`INSPECT 파일 ${insp.nLines}행 · 데이터 ${insp.rows.length}행   (본문 '34행')`);
say(`EQUIP   파일 ${eq.nLines}행 · 데이터 ${eq.rows.length}행   (본문 '48행')`);
say(`YIELD   파일 ${yld.nLines}행 · 데이터 ${yld.rows.length}행`);
say(`YIELD 기간: ${dStr(Math.min(...yld.rows.map(r=>r.d)))} ~ ${dStr(Math.max(...yld.rows.map(r=>r.d)))}`);
const slashI = insp.rows.filter(r => r.recv_date.includes('/') || r.install_date.includes('/'));
const slashE = eq.rows.filter(r => r.date.includes('/'));
say(`날짜에 슬래시 표기가 섞인 행: INSPECT ${slashI.length}건 [${slashI.map(r=>'insp#'+r._line).join(' ')}] · EQUIP ${slashE.length}건 [${slashE.map(r=>'eq#'+r._line).join(' ')}]`);

hr('[1] 규격 대조 — 34행 전부, (2a) 적힌 값 그대로 / (2b) mm 만 um 로');
const um = r => (r.unit === 'mm' ? +r.measured * 1000 : +r.measured);
const ex2a = insp.rows.filter(r => +r.measured > +r.spec_max);
const ex2b = insp.rows.filter(r => um(r) > +r.spec_max);
say(`(2a) 초과 ${ex2a.length}행 : ${ex2a.map(r=>'insp#'+r._line+' '+r.serial).join(' | ')}`);
say(`(2b) 초과 ${ex2b.length}행 : ${ex2b.map(r=>'insp#'+r._line+' '+r.serial).join(' | ')}`);
const installed = insp.rows.filter(r => r.install_date !== '' && r.chamber !== '');
const instSer = [...new Set(installed.map(r => r.serial))];
say(`설치된 행 ${installed.length}행 [${installed.map(r=>'insp#'+r._line).join(' ')}] · 설치된 낱개 ${instSer.length}개 [${instSer.join(' ')}]   (본문 '5행'·'넷')`);
const exInst2a = ex2a.filter(r => r.install_date !== ''), exInst2b = ex2b.filter(r => r.install_date !== '');
say(`초과이면서 설치: (2a) ${exInst2a.length}행 · (2b) ${exInst2b.length}행 · 낱개 ${new Set(exInst2b.map(r=>r.serial)).size}개   (본문 '두 셈법 모두 3행'·'낱개로 세면 둘')`);
say(`서로 다른 낱개(전체): ${new Set(insp.rows.map(r=>r.serial)).size}개`);
say(`중복 serial: ${[...new Set(insp.rows.map(r=>r.serial))].filter(s=>insp.rows.filter(r=>r.serial===s).length>1).join(',')} — 그 행 [${insp.rows.filter(r=>r.serial==='SH2200-B-0412').map(r=>'insp#'+r._line).join(' ')}]`);
// 1절 표 네 줄 되세기
say('');
say('1절 표 되세기 (설치일 · 챔버 · 부품 · serial · 잰 값 · 상한 · 초과배수)');
instSer.forEach(s => { const r = insp.rows.find(x => x.serial === s);
  say(`  ${nd(r.install_date)} ${r.chamber} ${r.part_no} ${r.serial} ${r.spec_item} ${r.measured}${r.unit} / ${r.spec_max} → 초과배수 ${(um(r)/+r.spec_max).toFixed(4)} ${um(r)>+r.spec_max?'초과':'적합'}`); });

hr('[2] 공급사 갈래 — (2b) 기준, 낱개로 중복을 지우고');
const bySup = {};
insp.rows.forEach(r => { const k = r.supplier === '' ? '(빈칸)' : r.supplier;
  (bySup[k] = bySup[k] || { all: new Set(), ex: new Set(), shAll: new Set(), shEx: new Set() });
  bySup[k].all.add(r.serial); if (um(r) > +r.spec_max) bySup[k].ex.add(r.serial);
  if (r.part_no === 'SH-2200') { bySup[k].shAll.add(r.serial); if (um(r) > +r.spec_max) bySup[k].shEx.add(r.serial); } });
Object.keys(bySup).sort().forEach(k => { const v = bySup[k];
  say(`  ${k.padEnd(12)} 전체 낱개 ${v.all.size} · 초과 낱개 ${v.ex.size} · 비율 ${(v.ex.size/v.all.size).toFixed(4)} · SH-2200 ${v.shAll.size}개 중 ${v.shEx.size}개`); });
say(`  합계 낱개 ${Object.values(bySup).reduce((a,v)=>a+v.all.size,0)}   (본문 표 16·16·1)`);

hr('[3] 짝짓기 — 열쇠 (install_date, chamber) 가 유일한가');
const part = eq.rows.filter(r => r.event_type === 'PART');
say(`EQUIP PART 사건 ${part.length}건 : ${part.map(r=>'eq#'+r._line+' '+nd(r.date)+' '+r.chamber+' 「'+r.detail+'」').join(' | ')}`);
const keys = [...new Set(installed.map(r => nd(r.install_date) + '@' + r.chamber))];
say(`INSPECT 설치 열쇠 ${keys.length}개 : ${keys.join(' , ')}`);
let uniqOk = true;
keys.forEach(k => { const [d, c] = k.split('@');
  const m = part.filter(r => nd(r.date) === d && r.chamber === c);
  const rowsForKey = installed.filter(r => nd(r.install_date) + '@' + r.chamber === k);
  const serForKey = new Set(rowsForKey.map(r => r.serial));
  if (m.length !== 1 || serForKey.size !== 1) uniqOk = false;
  say(`  ${k} → PART 후보 ${m.length}건 [${m.map(r=>'eq#'+r._line).join(' ')}] · 성적서 행 ${rowsForKey.length} · 낱개 ${serForKey.size} [${[...serForKey].join(' ')}] · part_no 가 detail 안에: ${m.length? (m[0].detail.includes(rowsForKey[0].part_no)?'참':'거짓') : '-'}`); });
say(`짝 못 찾은 PART 사건 : ${part.filter(r => !keys.includes(nd(r.date)+'@'+r.chamber)).length}건`);
say(`짝 못 찾은 설치 낱개 : ${instSer.filter(s => { const r = insp.rows.find(x=>x.serial===s); return !part.some(p => nd(p.date)===nd(r.install_date) && p.chamber===r.chamber); }).length}건`);
say(`열쇠가 1:1 로 유일한가 : ${uniqOk ? '참 (열쇠 4개 모두 PART 1건·낱개 1개)' : '거짓'}`);
// 반례 찾기: 같은 (날짜,챔버) 에 PART 가 둘 이상인 자리가 EQUIP 전체에 있는가
const dcCount = {};
part.forEach(r => { const k = nd(r.date)+'@'+r.chamber; dcCount[k] = (dcCount[k]||0)+1; });
say(`EQUIP 전체에서 한 (날짜,챔버) 에 PART 가 둘 이상인 자리 : ${Object.entries(dcCount).filter(([,v])=>v>1).length}곳`);
const dcAll = {};
eq.rows.forEach(r => { const k = nd(r.date)+'@'+r.chamber; dcAll[k]=(dcAll[k]||0)+1; });
say(`(참고) 한 (날짜,챔버) 에 사건이 둘 이상인 자리 : ${Object.entries(dcAll).filter(([,v])=>v>1).map(([k,v])=>k+'×'+v).join(' , ')}`);

hr('[4] Δ수율 — 창 W 를 돌려 가며 (전 D-W~D-1 · 후 D+1~D+W · 당일 뺌)');
const EV = [
  ['E1', '2026-07-15', 'CH-1A', 'PART HC-40'], ['E2', '2026-07-28', 'CH-3B', 'PART SH-2200'],
  ['E3', '2026-08-06', 'CH-2B', 'PART SH-2200'], ['E4', '2026-08-18', 'CH-1B', 'PART OR-15'],
  ['E5', '2026-07-28', 'CH-3A', 'PM 대조군'], ['E6', '2026-07-21', 'CH-2B', 'PM 대조군'] ];
const mean = a => a.reduce((x, y) => x + y, 0) / a.length;
const svar = a => { const m = mean(a); return a.reduce((s, x) => s + (x - m) ** 2, 0) / (a.length - 1); };
function welch(A, B) { // B - A
  const v1 = svar(A) / A.length, v2 = svar(B) / B.length;
  const t = (mean(B) - mean(A)) / Math.sqrt(v1 + v2);
  const df = (v1 + v2) ** 2 / (v1 ** 2 / (A.length - 1) + v2 ** 2 / (B.length - 1));
  return { t, df };
}
function win(ch, D, W) {
  const d0 = dayNo(D);
  const pre = yld.rows.filter(r => r.chamber === ch && r.d >= d0 - W && r.d <= d0 - 1);
  const post = yld.rows.filter(r => r.chamber === ch && r.d >= d0 + 1 && r.d <= d0 + W);
  return { pre, post };
}
const pRatio = rs => rs.reduce((s, r) => s + r.pd, 0) / rs.reduce((s, r) => s + r.dc, 0);
const dRatio = rs => { const byd = {}; rs.forEach(r => { (byd[r.d] = byd[r.d] || []).push(r); });
  return mean(Object.values(byd).map(g => pRatio(g))); };
const WS = [3, 5, 7, 10, 14];
say('사건 날짜       챔버   W  전로트 후로트   전평균   후평균       Δ   Welch t      ΔP(정의P)  ΔD(정의D)');
const res = {};
EV.forEach(([id, D, ch]) => { WS.forEach(W => {
  const { pre, post } = win(ch, D, W); const w = welch(pre.map(r=>r.y), post.map(r=>r.y));
  const delta = mean(post.map(r=>r.y)) - mean(pre.map(r=>r.y));
  res[id + '_' + W] = delta;
  say(`  ${id} ${D} ${ch} ${String(W).padStart(3)} ${String(pre.length).padStart(6)} ${String(post.length).padStart(6)} ${mean(pre.map(r=>r.y)).toFixed(2).padStart(8)} ${mean(post.map(r=>r.y)).toFixed(2).padStart(8)} ${delta.toFixed(2).padStart(8)} ${w.t.toFixed(3).padStart(9)} ${(pRatio(post)-pRatio(pre)).toFixed(4).padStart(14)} ${(dRatio(post)-dRatio(pre)).toFixed(4).padStart(10)}`);
}); say(''); });

hr('[4b] 손잡이 돌리기 — W 를 배분에 없는 값으로도 돌려 결론이 창 고르기의 산물인지 본다');
const WX = [2, 4, 6, 8, 9, 12, 16, 21, 28];
say('  W   E2(CH-3B) Δ   E5(CH-3A) Δ   E3(CH-2B) Δ   E1(CH-1A) Δ   E2 가 6사건 중 최하위인가');
WX.forEach(W => {
  const ds = EV.map(([id, D, ch]) => { const { pre, post } = win(ch, D, W);
    return { id, n: Math.min(pre.length, post.length), v: mean(post.map(r=>r.y)) - mean(pre.map(r=>r.y)) }; });
  const ok = ds.every(x => x.n >= 4);
  const lowest = ds.reduce((a, b) => a.v < b.v ? a : b).id;
  const g = i => ds.find(x => x.id === i).v.toFixed(2).padStart(12);
  say(`  ${String(W).padStart(2)} ${g('E2')} ${g('E5')} ${g('E3')} ${g('E1')}   ${lowest === 'E2' ? '참' : '거짓 ('+lowest+')'}${ok?'':'  ※한쪽 창 4로트 미만 있음'}`);
});

hr('[5] 규격 초과 두 사건의 Δ 부호 (본문 5절)');
say('  W    E1(1.22배) Δ   E2(1.60배) Δ   부호');
let same = 0;
WS.forEach(W => { const a = res['E1_' + W], b = res['E2_' + W];
  const s = Math.sign(a) === Math.sign(b); if (s) same++;
  say(`  ${String(W).padStart(2)} ${a.toFixed(2).padStart(14)} ${b.toFixed(2).padStart(14)}   ${s ? '같음' : '다름'}`); });
say(`부호가 같은 창 : ${same} / ${WS.length}   (본문 '다섯 중 하나뿐')`);

hr('[6] 07-29 앞뒤 파티클 비율 — 여섯 챔버 (앞 07-01~07-28 · 뒤 07-29~08-25)');
const A0 = dayNo('2026-07-01'), A1 = dayNo('2026-07-28'), B0 = dayNo('2026-07-29'), B1 = dayNo('2026-08-25');
const chs = [...new Set(yld.rows.map(r => r.chamber))].sort();
const tab = chs.map(ch => { const a = yld.rows.filter(r => r.chamber === ch && r.d >= A0 && r.d <= A1);
  const b = yld.rows.filter(r => r.chamber === ch && r.d >= B0 && r.d <= B1);
  return { ch, pa: pRatio(a), pb: pRatio(b), dP: pRatio(b) - pRatio(a), dY: mean(b.map(r=>r.y)) - mean(a.map(r=>r.y)) }; });
tab.sort((x, y) => y.dP - x.dP).forEach(r => say(`  ${r.ch}  정의P ${r.pa.toFixed(4)} → ${r.pb.toFixed(4)}  ΔP ${r.dP.toFixed(4).padStart(8)}  Δ수율 ${r.dY.toFixed(2).padStart(6)}`));
say(`ΔP 가 양수인 챔버 ${tab.filter(r=>r.dP>0).length}개 [${tab.filter(r=>r.dP>0).map(r=>r.ch).join(',')}] · 음수 ${tab.filter(r=>r.dP<0).length}개   (본문 '오른 챔버는 CH-3B 하나')`);

hr('[7] CH-3B 불량 종류별 — 앞/뒤 로트당 평균과 Welch t');
const a3 = yld.rows.filter(r => r.chamber === 'CH-3B' && r.d >= A0 && r.d <= A1);
const b3 = yld.rows.filter(r => r.chamber === 'CH-3B' && r.d >= B0 && r.d <= B1);
const show = (nm, f) => { const A = a3.map(f), B = b3.map(f); const w = welch(A, B);
  say(`  ${nm.padEnd(12)} 앞 ${mean(A).toFixed(2).padStart(7)} (n=${A.length})  뒤 ${mean(B).toFixed(2).padStart(7)} (n=${B.length})  차이 ${(mean(B)-mean(A)).toFixed(2).padStart(7)}  Welch t ${w.t.toFixed(3).padStart(8)}`); };
show('파티클 불량', r => r.pd); show('그 밖의 불량', r => r.dc - r.pd); show('전체 불량', r => r.dc);

hr('[8] 하루 단위 07-28 → 07-29 (CH-3B)');
[['2026-07-28'], ['2026-07-29']].forEach(([d]) => { const rs = yld.rows.filter(r => r.chamber === 'CH-3B' && r.d === dayNo(d));
  say(`  ${d}  로트 ${rs.length}개 [${rs.map(r=>'yield#'+r._line).join(' ')}]  수율평균 ${mean(rs.map(r=>r.y)).toFixed(2)}  전체불량 ${rs.reduce((s,r)=>s+r.dc,0)}  파티클 ${rs.reduce((s,r)=>s+r.pd,0)}  그밖 ${rs.reduce((s,r)=>s+r.dc-r.pd,0)}`); });

hr('[9] EQUIP 에서 파티클과 닿는 사건');
const pw = eq.rows.filter(r => /파티클|particle/i.test(r.detail));
say(`detail 에 파티클/particle 이 든 행 ${pw.length}건 / 데이터 ${eq.rows.length}행`);
say(`  그중 CAL ${pw.filter(r=>r.event_type==='CAL').length}건 (모두 ${[...new Set(pw.filter(r=>r.event_type==='CAL').map(r=>nd(r.date)))].join(',')})`);
pw.filter(r => r.event_type !== 'CAL').forEach(r => say(`  남은 것: eq#${r._line} ${nd(r.date)} ${r.chamber} ${r.event_type} 「${r.detail}」 ${r.duration_min}분`));
const c3 = eq.rows.filter(r => r.chamber === 'CH-3B');
say(`CH-3B 사건 ${c3.length}건 · 그중 PART ${c3.filter(r=>r.event_type==='PART').length}건 [${c3.filter(r=>r.event_type==='PART').map(r=>nd(r.date)).join(',')}] · EQUIP 마지막 날 ${dStr(Math.max(...eq.rows.map(r=>r.d)))}`);

hr('[10] eq#27 과 eq#29 에서 값이 다른 칸');
const r27 = eq.rows.find(r => r._line === 27), r29 = eq.rows.find(r => r._line === 29);
say(`  다른 칸: ${eq.head.filter(h => r27[h] !== r29[h]).join(',')} — 그 밖은 모두 같다`);
say(`  eq#28(PART) 의 duration ${eq.rows.find(r=>r._line===28).duration_min}분 · eq#38(PART) 의 duration ${eq.rows.find(r=>r._line===38).duration_min}분`);

hr('[11] mm 두 행 · 입고→설치 날 수');
insp.rows.filter(r => r.unit === 'mm').forEach(r => say(`  insp#${r._line} ${r.serial} ${r.measured}mm → ${um(r)}um / 상한 ${r.spec_max} · 설치 ${r.install_date === '' ? '안 됨' : r.install_date}`));
installed.forEach(r => say(`  insp#${r._line} ${r.serial} 입고 ${nd(r.recv_date)} → 설치 ${nd(r.install_date)} = ${dayNo(r.install_date) - dayNo(r.recv_date)}일`));

fs.writeFileSync(ROOM + 'researcher/task-17-evidence.log', out.join('\n') + '\n');
console.log(out.join('\n'));

// ---- [12] 덧붙임: 6절을 (2a) 로도 세어 본다 (지적 6) ----
{
  const o2 = [];
  o2.push('');
  o2.push('='.repeat(110));
  o2.push('[12] 공급사 갈래를 (2a) 로도 — 본문 6절은 (2b)·낱개 하나만 실었다');
  o2.push('='.repeat(110));
  const raw = r => +r.measured;                       // (2a) 적힌 값 그대로
  const conv = r => (r.unit === 'mm' ? +r.measured * 1000 : +r.measured);   // (2b)
  [['(2a) 적힌 값 그대로', raw], ['(2b) mm 를 um 로', conv]].forEach(([nm, f]) => {
    const t = {};
    insp.rows.filter(r => r.part_no === 'SH-2200').forEach(r => {
      const k = r.supplier === '' ? '(빈칸)' : r.supplier;
      (t[k] = t[k] || { rowAll: 0, rowEx: 0, sAll: new Set(), sEx: new Set() });
      t[k].rowAll++; if (f(r) > +r.spec_max) t[k].rowEx++;
      t[k].sAll.add(r.serial); if (f(r) > +r.spec_max) t[k].sEx.add(r.serial);
    });
    o2.push(`  ${nm}`);
    Object.keys(t).sort().forEach(k => o2.push(
      `    ${k.padEnd(12)} 행 ${t[k].rowEx}/${t[k].rowAll} = ${(t[k].rowEx/t[k].rowAll).toFixed(4)}  ·  낱개 ${t[k].sEx.size}/${t[k].sAll.size} = ${(t[k].sEx.size/t[k].sAll.size).toFixed(4)}`));
  });
  o2.push('  갈리는 까닭: SH2200-A-1190(insp#22) 이 0.0031 mm 라 (2a) 에서는 적합, (2b) 에서는 3.1 um 로 초과다.');
  fs.appendFileSync(ROOM + 'researcher/task-17-evidence.log', o2.join('\n') + '\n');
  console.log(o2.join('\n'));
}
