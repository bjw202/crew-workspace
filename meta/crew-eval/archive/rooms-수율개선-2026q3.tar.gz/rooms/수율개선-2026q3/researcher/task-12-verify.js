// task-12 교차 검토 재계산 — researcher
// analyst/task-11-analysis.py 를 돌리지 않고 원본 CSV 둘에서 새로 구현한다.
// 실행: node task-12-verify.js > task-12-evidence.log
'use strict';
const fs = require('fs');
const path = require('path');

const ROOM = path.resolve(__dirname, '..');
const EQ_CSV = path.join(ROOM, 'archivist/inbox/2026-09-08-equipment-history/423efc74-8819-445a-bb81-90ca388034fd-equipment_history.csv');
const Y_CSV  = path.join(ROOM, 'archivist/inbox/2026-09-08-yield-by-lot/44cdd855-be6e-4b66-a014-e7eb3a056769-yield_by_lot.csv');

const out = [];
const P = (s = '') => out.push(s);
const H = (t) => { P(''); P('='.repeat(100)); P(t); P('='.repeat(100)); };
const f = (x, n = 4) => (x === null || x === undefined || Number.isNaN(x)) ? '  n/a  ' : x.toFixed(n);

// ---------- 기본 통계 (모두 ddof=1 표본) ----------
const mean = a => a.reduce((s, x) => s + x, 0) / a.length;
function varS(a) { // ddof=1
  if (a.length < 2) return NaN;
  const m = mean(a);
  return a.reduce((s, x) => s + (x - m) * (x - m), 0) / (a.length - 1);
}
function varP(a) { // ddof=0
  const m = mean(a);
  return a.reduce((s, x) => s + (x - m) * (x - m), 0) / a.length;
}
const sdS = a => Math.sqrt(varS(a));
const sdP = a => Math.sqrt(varP(a));
function welch(after, before) { // t = (after - before) / se
  const na = after.length, nb = before.length;
  if (na < 2 || nb < 2) return { t: NaN, df: NaN };
  const va = varS(after), vb = varS(before);
  const se2 = va / na + vb / nb;
  if (se2 <= 0) return { t: NaN, df: NaN };
  const t = (mean(after) - mean(before)) / Math.sqrt(se2);
  const df = (se2 * se2) / ((va * va) / (na * na * (na - 1)) + (vb * vb) / (nb * nb * (nb - 1)));
  return { t, df };
}
function pct(sorted, q) { // 선형보간
  const i = (sorted.length - 1) * q;
  const lo = Math.floor(i), hi = Math.ceil(i);
  return lo === hi ? sorted[lo] : sorted[lo] + (sorted[hi] - sorted[lo]) * (i - lo);
}

// ---------- 날짜 ----------
const DAY = 86400000;
const toD = s => new Date(s + 'T00:00:00Z').getTime();
const toS = t => new Date(t).toISOString().slice(0, 10);
const diffD = (a, b) => Math.round((toD(a) - toD(b)) / DAY);
const shift = (s, n) => toS(toD(s) + n * DAY);

// ---------- CSV 읽기 ----------
function readCsv(p) {
  const lines = fs.readFileSync(p, 'utf8').split('\n').map(l => l.replace(/\r$/, '')).filter(l => l.trim() !== '');
  const head = lines[0].split(',').map(h => h.trim());
  return lines.slice(1).map((l, i) => {
    const c = l.split(',');
    const o = { __line: i + 2 };            // 원본 CSV 행 번호 (머리글 1행)
    head.forEach((h, j) => o[h] = c[j] === undefined ? '' : c[j]);
    return o;
  });
}

H('[A] 입력 검사 — 원본 CSV 둘을 내가 다시 읽는다');
const eqRaw = readCsv(EQ_CSV);
const yRaw = readCsv(Y_CSV);
P(`설비 이력 데이터 행 수: ${eqRaw.length}   (task-11 로그 주장 48)`);
P(`로트 수율 데이터 행 수: ${yRaw.length}   (task-11 로그 주장 672)`);

// 함정 1: 날짜 슬래시 정규화
let slash = 0;
const eq = eqRaw.map(r => {
  let d = r.date;
  if (d.includes('/')) { slash++; d = d.replace(/\//g, '-'); }
  return { date: d, chamber: r.chamber, type: r.event_type, detail: r.detail,
           dur: Number(r.duration_min), worker: r.worker, line: r.__line };
});
P(`슬래시 날짜를 정규화한 행 수: ${slash}   (주장 1)  ${slash === 1 ? '일치' : '불일치'}`);
eqRaw.forEach(r => { if (r.date.includes('/')) P(`  원본 CSV ${r.__line}행: '${r.date}' -> '${r.date.replace(/\//g, '-')}'  ${r.chamber} ${r.event_type}`); });

// 함정 2: worker 결측
const missW = eq.filter(r => r.worker.trim() === '');
P(`worker 가 빈칸인 행 수: ${missW.length}   (주장 1)  ${missW.length === 1 ? '일치' : '불일치'}`);
missW.forEach(r => P(`  원본 CSV ${r.line}행: ${r.date} ${r.chamber} ${r.type}`));

// 함정 3: SH-2200 부분 문자열
const sh = eq.filter(r => r.detail.includes('SH-2200'));
P(`'SH-2200' 부분 문자열로 묶은 건수: ${sh.length}   (주장 2)  ${sh.length === 2 ? '일치' : '불일치'}`);
sh.forEach(r => P(`  ${r.date} ${r.chamber} ${r.type} detail='${r.detail}'  (원본 ${r.line}행)`));
// detail 문자열 완전 일치로 묶으면 몇 건인가 (analyst 의 주의가 옳은지)
const exact = eq.filter(r => r.detail === sh[0].detail);
P(`  참고: detail 문자열 완전 일치로 묶으면 ${exact.length}건 — 부분 문자열이 아니면 대조군을 놓친다는 주장은 ${exact.length < 2 ? '옳다' : '틀리다'}`);

// event_type 별 / chamber 별
const cnt = (arr, k) => arr.reduce((m, r) => (m[r[k]] = (m[r[k]] || 0) + 1, m), {});
P('event_type 별 행 수: ' + JSON.stringify(cnt(eq, 'type')));
P('chamber 별 이벤트 행 수: ' + JSON.stringify(cnt(eq, 'chamber')));

// 수율 CSV 검사
const Y = yRaw.map(r => ({
  lot: r.lot_id, date: r.date, line: r.line, ch: r.chamber,
  y: Number(r.yield_pct), dc: Number(r.defect_count), pd: Number(r.particle_defects), src: r.__line
}));
const bad = Y.filter(r => !Number.isFinite(r.y) || !Number.isFinite(r.dc) || !Number.isFinite(r.pd));
P(`수율 CSV 파싱 실패 행: ${bad.length}`);
const dupLot = Y.length - new Set(Y.map(r => r.lot)).size;
P(`lot_id 중복: ${dupLot}`);
const dates = [...new Set(Y.map(r => r.date))].sort();
P(`수율 날짜 범위: ${dates[0]} ~ ${dates[dates.length - 1]}  (${dates.length}일)`);
P('수율 챔버별 행 수: ' + JSON.stringify(cnt(Y, 'ch')));
// (챔버,날) 조합당 로트 수
const perCD = {};
Y.forEach(r => { const k = r.ch + '|' + r.date; perCD[k] = (perCD[k] || 0) + 1; });
const notTwo = Object.entries(perCD).filter(([, v]) => v !== 2);
P(`(챔버,날) 조합 수: ${Object.keys(perCD).length}   로트가 2가 아닌 조합: ${notTwo.length}`);
const eqDates = [...new Set(eq.map(r => r.date))].sort();
P(`설비 이력 날짜 범위: ${eqDates[0]} ~ ${eqDates[eqDates.length - 1]}`);

// ---------- 색인 ----------
const CHS = [...new Set(Y.map(r => r.ch))].sort();
const byCh = {}; CHS.forEach(c => byCh[c] = Y.filter(r => r.ch === c));
const lotsOf = (ch, d0, d1) => byCh[ch].filter(r => r.date >= d0 && r.date <= d1);
const dailyMean = {};   // ch -> [{date, y, P}]
CHS.forEach(c => {
  const m = {};
  byCh[c].forEach(r => { (m[r.date] = m[r.date] || []).push(r); });
  dailyMean[c] = Object.keys(m).sort().map(d => ({
    date: d, y: mean(m[d].map(r => r.y)),
    P: m[d].reduce((s, r) => s + r.pd, 0) / m[d].reduce((s, r) => s + r.dc, 0)
  }));
});
const Pof = rows => rows.reduce((s, r) => s + r.pd, 0) / rows.reduce((s, r) => s + r.dc, 0);

const DROP = '2026-07-29';

H('[B] 표준편차 눈금 재계산 (끝 조건 ⑥) — CH-3B 일평균 수율');
const d3b = dailyMean['CH-3B'];
const seg = (d0, d1) => d3b.filter(r => r.date >= d0 && r.date <= d1);
const base = seg('2026-07-01', '2026-07-24');
const pre28 = seg('2026-07-01', '2026-07-28');
const post = seg('2026-07-29', '2026-08-25');
P(`CH-3B 일평균 점 개수: ${d3b.length}   (주장 56)`);
P('');
P('항목                                  n   ddof=0 (모)   ddof=1 (표본)   task-11 주장(모/표본)');
P('----------------------------------------------------------------------------------------');
P(`(a) 기준선 07-01~07-24 수율 sd       ${base.length}      ${f(sdP(base.map(r => r.y)))}        ${f(sdS(base.map(r => r.y)))}       0.6198 / 0.6331`);
P(`(b) 07-01~07-28 수율 sd              ${pre28.length}      ${f(sdP(pre28.map(r => r.y)))}        ${f(sdS(pre28.map(r => r.y)))}       0.6205 / 0.6319`);
P(`(c) 07-29~08-25 수율 sd              ${post.length}      ${f(sdP(post.map(r => r.y)))}        ${f(sdS(post.map(r => r.y)))}       0.5824 / 0.5931`);
P(`(d) 기준선 파티클비율(날마다) sd     ${base.length}      ${f(sdP(base.map(r => r.P)))}        ${f(sdS(base.map(r => r.P)))}       0.0183 / 0.0187`);
P('');
P(`평균: 기준선 ${f(mean(base.map(r => r.y)))} · 07-01~07-28 ${f(mean(pre28.map(r => r.y)))} · 07-29~08-25 ${f(mean(post.map(r => r.y)))} · 기준선 파티클비율 ${f(mean(base.map(r => r.P)))}`);
const w2828 = welch(post.map(r => r.y), pre28.map(r => r.y));
P(`07-29 앞뒤 28일 대 28일 Welch t (ddof=1) = ${f(w2828.t)}   df = ${f(w2828.df, 2)}   (task-11 주장 -22.0631 / df 53.78)`);
P(`Δ = ${f(mean(post.map(r => r.y)) - mean(pre28.map(r => r.y)))} %p   (task-11 주장 -3.6136)`);
const bm = mean(base.map(r => r.y));
P(`기준선 문턱: 평균-3sd = ${f(bm - 3 * sdP(base.map(r => r.y)))}(모) / ${f(bm - 3 * sdS(base.map(r => r.y)))}(표본)   (주장 91.8889 / 91.8489)`);
P(`            평균-2sd = ${f(bm - 2 * sdP(base.map(r => r.y)))}(모) / ${f(bm - 2 * sdS(base.map(r => r.y)))}(표본)   (주장 92.5087 / 92.4820)`);

// ---------- 이벤트 전후 창 ----------
function window(ch, d, W) {
  const before = lotsOf(ch, shift(d, -W), shift(d, -1));
  const after  = lotsOf(ch, shift(d, 1), shift(d, W));
  return { before, after };
}
function delta(ch, d, W, minN = 8) {
  const { before, after } = window(ch, d, W);
  if (before.length < minN || after.length < minN) return null;
  const bY = before.map(r => r.y), aY = after.map(r => r.y);
  const { t, df } = welch(aY, bY);
  return { nB: before.length, nA: after.length, mB: mean(bY), mA: mean(aY),
           d: mean(aY) - mean(bY), t, df, pB: Pof(before), pA: Pof(after), dP: Pof(after) - Pof(before) };
}

H('[C] 이벤트 48건 전후 (전후 7일 창, 당일 제외) — task-11 [3]절 재계산');
P('date       chamber type    n_전 n_후    전수율    후수율    Δ수율   Welch_t      ΔP   원본행');
P('-'.repeat(100));
const ev7 = [];
eq.slice().sort((a, b) => a.date.localeCompare(b.date) || a.chamber.localeCompare(b.chamber) || a.type.localeCompare(b.type))
  .forEach(r => {
    const s = delta(r.chamber, r.date, 7);
    ev7.push({ ...r, s });
    if (!s) P(`${r.date} ${r.chamber}  ${r.type.padEnd(6)}  ${String(window(r.chamber, r.date, 7).before.length).padStart(3)}  ${String(window(r.chamber, r.date, 7).after.length).padStart(3)}    창부족    창부족   창부족    창부족   창부족   ${r.line}`);
    else P(`${r.date} ${r.chamber}  ${r.type.padEnd(6)}  ${String(s.nB).padStart(3)}  ${String(s.nA).padStart(3)}   ${f(s.mB, 3)}   ${f(s.mA, 3)}  ${(s.d >= 0 ? '+' : '') + f(s.d, 3)}   ${f(s.t, 2).padStart(7)}  ${(s.dP >= 0 ? '+' : '') + f(s.dP)}   ${r.line}`);
  });
P('-'.repeat(100));
P(`이벤트 행 수: ${ev7.length}   창부족: ${ev7.filter(e => !e.s).length}   통계를 낸 건수: ${ev7.filter(e => e.s).length}   (주장 48 / 4 / 44)`);

P('');
P('-- Δ수율이 작은 순 상위 10건 --');
ev7.filter(e => e.s).sort((a, b) => a.s.d - b.s.d).slice(0, 10)
  .forEach((e, i) => P(`  ${String(i + 1).padStart(2)}  ${e.date} ${e.chamber} ${e.type.padEnd(6)} Δ=${f(e.s.d, 3)}  t=${f(e.s.t, 2)}  ${e.detail}`));
const nonD = ev7.filter(e => e.s && e.chamber !== 'CH-3B').sort((a, b) => a.s.d - b.s.d)[0];
const d0728 = ev7.find(e => e.date === '2026-07-28' && e.chamber === 'CH-3B');
P(`CH-3B 밖에서 가장 크게 떨어진 건: ${nonD.date} ${nonD.chamber} ${nonD.type} Δ=${f(nonD.s.d, 3)}`);
P(`  07-28 CH-3B(${f(d0728.s.d, 3)}) 대비 비율 = ${f(d0728.s.d / nonD.s.d, 2)} 배  → 본문 "7분의 1" 주장의 실제 값은 ${f(nonD.s.d / d0728.s.d, 4)} (= 1/${f(d0728.s.d / nonD.s.d, 2)})`);

H('[D] 대조군 셋 — 이력에 실제로 있는가 · Δ가 보고대로인가 (끝 조건 ②)');
function showEv(date, ch, type) {
  const hit = eq.filter(r => r.date === date && r.chamber === ch && (!type || r.type === type));
  P(`이력 대조: ${date} ${ch} ${type || ''} → ${hit.length}건 ${hit.length ? '있다' : '없다'}`);
  hit.forEach(r => P(`   원본 CSV ${r.line}행: ${r.date},${r.chamber},${r.type},${r.detail},${r.dur},${r.worker || '(결측)'}`));
  return hit;
}
P('(2-1) CH-3A 2026-07-28 정기 정비 — 보고 주장 Δ +0.004 %p');
showEv('2026-07-28', 'CH-3A', 'PM');
let s = delta('CH-3A', '2026-07-28', 7);
P(`   내 재계산: Δ = ${(s.d >= 0 ? '+' : '') + f(s.d, 4)} %p   t = ${f(s.t, 4)}   ΔP = ${(s.dP >= 0 ? '+' : '') + f(s.dP)}   (전 ${f(s.mB, 3)} → 후 ${f(s.mA, 3)})`);
P(`   대조 결과: ${Math.abs(s.d - 0.004) < 0.0005 ? '일치' : '불일치'}`);

P('');
P('(2-2) CH-2B 2026-08-06 SH-2200 교체 — 보고 주장 Δ -0.015 %p (7일) / -0.033 %p (28일)');
showEv('2026-08-06', 'CH-2B', 'PART');
s = delta('CH-2B', '2026-08-06', 7);
P(`   내 재계산 7일 창:  Δ = ${f(s.d, 4)} %p   t = ${f(s.t, 4)}   ΔP = ${(s.dP >= 0 ? '+' : '') + f(s.dP)}   (전 ${f(s.mB, 3)} → 후 ${f(s.mA, 3)})`);
const s28 = delta('CH-2B', '2026-08-06', 28, 1);
P(`   내 재계산 28일 창: Δ = ${f(s28.d, 4)} %p   (전 ${s28.nB}로트 ${f(s28.mB, 3)} → 후 ${s28.nA}로트 ${f(s28.mA, 3)})`);
const s28b = delta('CH-3B', '2026-07-28', 28, 1);
P(`   같은 28일 창 CH-3B 07-28: Δ = ${f(s28b.d, 4)} %p  (주장 -3.617)  (전 ${s28b.nB}로트 → 후 ${s28b.nA}로트)`);
P(`   대조 결과: 7일 ${Math.abs(s.d + 0.015) < 0.0005 ? '일치' : '불일치'} · 28일 ${Math.abs(s28.d + 0.033) < 0.0005 ? '일치' : '불일치'}`);

P('');
P('(2-3) 2026-07-05 여섯 챔버 계측 교정 — 보고 주장 Δ 중앙값 +0.135 %p');
const cals = eq.filter(r => r.type === 'CAL');
P(`   기간 안 CAL 이벤트: ${cals.length}건, 날짜 = ${[...new Set(cals.map(r => r.date))].join(',')}, 챔버 = ${cals.map(r => r.chamber).join(',')}`);
const calD = cals.map(r => ({ ch: r.chamber, s: delta(r.chamber, r.date, 7) }));
calD.forEach(c => P(`   ${c.ch}: Δ = ${(c.s.d >= 0 ? '+' : '') + f(c.s.d, 3)}   ΔP = ${(c.s.dP >= 0 ? '+' : '') + f(c.s.dP)}`));
const calSorted = calD.map(c => c.s.d).sort((a, b) => a - b);
const calMed = (calSorted[2] + calSorted[3]) / 2;
P(`   중앙값 = ${(calMed >= 0 ? '+' : '') + f(calMed, 4)}   최소 ${f(calSorted[0], 3)}   최대 ${f(calSorted[5], 3)}   음수 ${calSorted.filter(x => x < 0).length}건 / 양수 ${calSorted.filter(x => x > 0).length}건`);
P(`   대조 결과: ${Math.abs(calMed - 0.135) < 0.0005 ? '일치' : '불일치'}`);

H('[E] 후보 좁히기가 분석의 선택인가 (끝 조건 ③) — 창 길이 W 를 바꿔 본다');
const Ws = [3, 5, 7, 10, 14, 21];
P('W(일)  CH-3B 07-28 Δ   CH-3A 07-28 Δ   CH-2B 08-06 Δ   CH-3B 07-20 Δ   48건 중 07-28 순위   CH-3B 밖 최대하락');
P('-'.repeat(110));
for (const W of Ws) {
  const full = 2 * W;   // 창을 꽉 채운 이벤트만 견준다 (창 길이마다 같은 잣대)
  const all = eq.map(r => ({ ...r, s: delta(r.chamber, r.date, W, full) })).filter(e => e.s);
  const sorted = all.slice().sort((a, b) => a.s.d - b.s.d);
  const rank = sorted.findIndex(e => e.date === '2026-07-28' && e.chamber === 'CH-3B') + 1;
  const g = (d, c) => { const x = delta(c, d, W, full); return x ? f(x.d, 3) : '창부족'; };
  const outside = sorted.filter(e => e.chamber !== 'CH-3B')[0];
  const os = outside ? `${outside.chamber} ${outside.date} ${f(outside.s.d, 3)}` : '(창을 채운 CH-3B 밖 이벤트 없음)';
  P(`${String(W).padStart(2)}     ${g('2026-07-28', 'CH-3B').padStart(9)}      ${g('2026-07-28', 'CH-3A').padStart(9)}      ${g('2026-08-06', 'CH-2B').padStart(9)}      ${g('2026-07-20', 'CH-3B').padStart(9)}        ${String(rank).padStart(2)} / ${all.length}          ${os}`);
}
P('읽는 법: 창 길이를 3일에서 21일까지 바꿔도 07-28 CH-3B 가 1위이고 대조군 둘이 평평하면, 후보 좁히기는 창 길이의 산물이 아니다.');

H('[E1b] 창 길이마다 하락 상위 5건 · 07-20 의 자리 · "셋을 빼면 1%p 없음"이 언제 깨지는가');
for (const W of Ws) {
  const full = 2 * W;
  const all = eq.map(r => ({ ...r, s: delta(r.chamber, r.date, W, full) })).filter(e => e.s);
  const sorted = all.slice().sort((a, b) => a.s.d - b.s.d);
  const r20 = sorted.findIndex(e => e.date === '2026-07-20' && e.chamber === 'CH-3B') + 1;
  const rest = all.filter(e => !(e.chamber === 'CH-3B' && (e.date === '2026-07-28' || e.date === '2026-08-03')));
  const mx = rest.slice().sort((a, b) => Math.abs(b.s.d) - Math.abs(a.s.d))[0];
  P('');
  P(`W=${W}일  (창을 채운 ${all.length}건)`);
  P('  하락 상위 5건: ' + sorted.slice(0, 5).map(e => `${e.date}/${e.chamber}/${e.type}/${f(e.s.d, 3)}`).join('  '));
  P(`  07-20 CH-3B 의 자리: Δ=${r20 ? f(sorted[r20 - 1].s.d, 3) : 'n/a'}  순위 ${r20 || '창부족'} / ${all.length}`);
  P(`  07-28 두 건과 08-03 을 뺀 뒤 |Δ| 최대: ${f(Math.abs(mx.s.d), 3)} (${mx.date}/${mx.chamber}/${mx.type})  → 1%p 넘는 건 ${rest.filter(e => Math.abs(e.s.d) > 1).length}건`);
  P('  07-06 CH-3B 의 Δ: ' + (delta('CH-3B', '2026-07-06', W, full) ? f(delta('CH-3B', '2026-07-06', W, full).d, 3) : '창부족'));
}

H('[E2] "이벤트 당일 D 를 양쪽 창에서 뺀다"는 선택도 바꿔 본다 (끝 조건 ③)');
function deltaVar(ch, d, W, mode) {
  // mode: 'excl' 당일 제외(보고와 같음) / 'pre' 당일을 전 창에 / 'post' 당일을 후 창에
  const b = lotsOf(ch, shift(d, -W), mode === 'pre' ? d : shift(d, -1));
  const a = lotsOf(ch, mode === 'post' ? d : shift(d, 1), shift(d, W));
  if (b.length < 8 || a.length < 8) return null;
  return mean(a.map(r => r.y)) - mean(b.map(r => r.y));
}
P('처리      CH-3B 07-28 Δ   CH-3A 07-28 Δ   CH-2B 08-06 Δ   48건 중 07-28 순위');
P('-'.repeat(80));
for (const m of ['excl', 'pre', 'post']) {
  const all = eq.map(r => ({ ...r, v: deltaVar(r.chamber, r.date, 7, m) })).filter(e => e.v !== null);
  const sorted = all.slice().sort((a, b) => a.v - b.v);
  const rank = sorted.findIndex(e => e.date === '2026-07-28' && e.chamber === 'CH-3B') + 1;
  const g = (d, c) => { const x = deltaVar(c, d, 7, m); return x === null ? '창부족' : f(x, 3); };
  const label = { excl: '당일 제외', pre: '당일→전 창', post: '당일→후 창' }[m];
  P(`${label.padEnd(10)}  ${g('2026-07-28', 'CH-3B').padStart(9)}      ${g('2026-07-28', 'CH-3A').padStart(9)}      ${g('2026-08-06', 'CH-2B').padStart(9)}        ${rank} / ${all.length}`);
}

H('[F] 후보 범위 R 을 바꿔 본다 (끝 조건 ③) — 보고가 고른 -14일 ~ 0일이 실제로 무엇을 담는가');
const ev3b = eq.filter(r => r.chamber === 'CH-3B').sort((a, b) => a.date.localeCompare(b.date));
P('CH-3B 이벤트 9건과 07-29 기준 간격:');
ev3b.forEach(r => {
  const s7 = delta('CH-3B', r.date, 7);
  P(`  ${r.date}  ${r.type.padEnd(6)} ${r.detail.padEnd(26)} 간격 ${String(diffD(r.date, DROP)).padStart(4)}일   7일창 Δ=${s7 ? f(s7.d, 3) : '창부족'}   원본 ${r.line}행`);
});
P('');
P('R(일)  범위 시작    범위 안 CH-3B 이벤트 (건수)  목록');
P('-'.repeat(100));
for (const R of [1, 3, 7, 9, 14, 21, 24, 28]) {
  const start = shift(DROP, -R);
  const inR = ev3b.filter(r => r.date >= start && r.date <= DROP);
  P(`${String(R).padStart(3)}    ${start}   ${String(inR.length).padStart(3)}건                     ${inR.map(r => r.date + '/' + r.type).join(', ') || '(없음)'}`);
}
P('');
P('※ 보고 본문 30-31행은 범위를 "-14일 ~ 0일 (2026-07-15~07-29)" 로 선언하고,');
P('   "이 범위 안에 든 CH-3B 이벤트는 07-28 의 두 건뿐이다" 라고 적었다.');
P('   위 표에서 R=14 의 실제 결과를 볼 것.');

H('[G] 플라시보 분포 (끝 조건 ④) — 창 길이별로 07-28 의 순위와 2~5위');
for (const W of [3, 5, 7, 14]) {
  const rows = [];
  CHS.forEach(c => {
    dates.forEach(d => {
      const b = lotsOf(c, shift(d, -W), shift(d, -1)), a = lotsOf(c, shift(d, 1), shift(d, W));
      if (b.length === 2 * W && a.length === 2 * W) rows.push({ ch: c, date: d, d: mean(a.map(r => r.y)) - mean(b.map(r => r.y)) });
    });
  });
  rows.sort((x, y) => x.d - y.d);
  const vals = rows.map(r => r.d).sort((a, b) => a - b);
  const rank = rows.findIndex(r => r.ch === 'CH-3B' && r.date === '2026-07-28') + 1;
  P('');
  P(`W=${W}일  표본 ${rows.length}개   CH-3B 07-28 순위 ${rank}/${rows.length}   최소 ${f(vals[0])}  5%p ${f(pct(vals, 0.05))}  중앙값 ${f(pct(vals, 0.5))}  95%p ${f(pct(vals, 0.95))}  최대 ${f(vals[vals.length - 1])}`);
  P('   아래에서 5건: ' + rows.slice(0, 5).map(r => `${r.date}/${r.ch}/${f(r.d, 4)}`).join('  '));
  const evSet = new Set(eq.map(r => r.chamber + '|' + r.date));
  const withE = rows.filter(r => evSet.has(r.ch + '|' + r.date)).map(r => r.d);
  const noE = rows.filter(r => !evSet.has(r.ch + '|' + r.date)).map(r => r.d);
  const w = welch(withE, noE);
  P(`   이벤트 있는 날 n=${withE.length} 평균 ${f(mean(withE))} / 없는 날 n=${noE.length} 평균 ${f(mean(noE))}   차이 ${f(mean(withE) - mean(noE))}   Welch t ${f(w.t, 4)}`);
  // 하락일(07-29)을 창이 걸치는 CH-3B 날을 뺀 순위
  const clean = rows.filter(r => !(r.ch === 'CH-3B' && Math.abs(diffD(r.date, DROP)) <= W));
  P(`   ※ 창이 07-29 를 걸치는 CH-3B 날(±${W}일)을 모두 빼면 남은 ${clean.length}개의 최소는 ${f(clean[0].d)} (${clean[0].date}/${clean[0].ch})`);
}

H('[H] 07-28 겹침의 특이성 재계산');
const dayKey = {};
eq.forEach(r => { const k = r.chamber + '|' + r.date; (dayKey[k] = dayKey[k] || []).push(r); });
const multi = Object.entries(dayKey).filter(([, v]) => v.length >= 2);
P(`이벤트가 2건 이상인 (챔버,날) 조합: ${multi.length}건   (주장 5)`);
multi.sort().forEach(([k, v]) => P(`  ${k.split('|')[1]} ${k.split('|')[0]}  ${v.map(r => r.type).sort().join(',')}  ${v.map(r => r.detail).join(' | ')}`));
const pmPart = multi.filter(([, v]) => v.some(r => r.type === 'PM') && v.some(r => r.type === 'PART'));
P(`PM 과 PART 가 같은 날 함께 있는 조합: ${pmPart.length}건   (주장 1)`);
const durByDay = Object.entries(dayKey).map(([k, v]) => ({ k, sum: v.reduce((s, r) => s + r.dur, 0) })).sort((a, b) => b.sum - a.sum);
P(`하루 duration 합 최대: ${durByDay[0].sum}분 (${durByDay[0].k})   (주장 330분 / 2026-07-28 CH-3B)`);
P(`전체 (챔버,날) 조합 수(수율 기준): ${Object.keys(perCD).length}   (주장 336)`);
const durByCh = {}; eq.forEach(r => durByCh[r.chamber] = (durByCh[r.chamber] || 0) + r.dur);
P('챔버별 duration 합: ' + JSON.stringify(durByCh) + '   (주장 CH-3B 830분이 최대)');

H('[I] 08-10 특별 세정 (3d) 재계산');
const preC = lotsOf('CH-3B', '2026-07-29', '2026-08-09');
const postC = lotsOf('CH-3B', '2026-08-11', '2026-08-25');
const wc = welch(postC.map(r => r.y), preC.map(r => r.y));
P(`세정 전 07-29~08-09: 로트 ${preC.length}  평균 ${f(mean(preC.map(r => r.y)), 3)}  sd(ddof=1) ${f(sdS(preC.map(r => r.y)))}  P ${f(Pof(preC))}   (주장 24로트 90.123 / 0.8593 / 0.5487)`);
P(`세정 후 08-11~08-25: 로트 ${postC.length}  평균 ${f(mean(postC.map(r => r.y)), 3)}  sd(ddof=1) ${f(sdS(postC.map(r => r.y)))}  P ${f(Pof(postC))}   (주장 30로트 90.118 / 0.9018 / 0.5482)`);
P(`Δ수율 ${f(mean(postC.map(r => r.y)) - mean(preC.map(r => r.y)), 4)}   Welch t ${f(wc.t, 4)}   ΔP ${f(Pof(postC) - Pof(preC))}   (주장 -0.005 / -0.0191 / -0.0005)`);
P(`기준선 평균 ${f(bm, 3)} 대비 세정 후 ${f(mean(postC.map(r => r.y)) - bm, 3)} %p   (주장 -3.630)`);

H('[J] 변화점 검정 재현 (내 seed 로 독립 순열검정)');
function mulberry32(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
function maxAbsT(v, minSide = 7) {
  let best = { t: 0, i: -1 };
  for (let i = minSide; i <= v.length - minSide; i++) {
    const a = v.slice(0, i), b = v.slice(i);
    const { t } = welch(b, a);
    if (Number.isFinite(t) && Math.abs(t) > Math.abs(best.t)) best = { t, i };
  }
  return best;
}
const rnd = mulberry32(20261212);
P('chamber  변화점        앞n  뒤n     Welch t   섞은것>=실제(2000회)        p     task-11 주장');
P('-'.repeat(100));
const claim = { 'CH-1A': ['2026-07-13', 1.6184, 0.6392], 'CH-1B': ['2026-07-13', -3.0411, 0.0770], 'CH-2A': ['2026-08-17', 1.9016, 0.4668], 'CH-2B': ['2026-08-19', -1.7222, 0.5597], 'CH-3A': ['2026-08-14', -1.3616, 0.8071], 'CH-3B': ['2026-07-29', -22.0631, 0.0005] };
for (const c of CHS) {
  const v = dailyMean[c].map(r => r.y);
  const b = maxAbsT(v);
  let ge = 0;
  for (let k = 0; k < 2000; k++) {
    const sh2 = v.slice();
    for (let i = sh2.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [sh2[i], sh2[j]] = [sh2[j], sh2[i]]; }
    if (Math.abs(maxAbsT(sh2).t) >= Math.abs(b.t)) ge++;
  }
  const p = (ge + 1) / 2001;
  const cp = dailyMean[c][b.i].date;
  const cl = claim[c];
  P(`${c}    ${cp}   ${String(b.i).padStart(3)}  ${String(v.length - b.i).padStart(3)}   ${f(b.t, 4).padStart(9)}   ${String(ge).padStart(8)}            ${f(p, 4)}     ${cl[0]} / ${f(cl[1], 4)} / ${f(cl[2], 4)}  ${cp === cl[0] && Math.abs(b.t - cl[1]) < 0.0001 ? '날짜·t 일치' : '불일치'}`);
}

H('[K] 보고 본문의 나머지 수치 대조');
// §2 종류별 중앙값
P('event_type 별 Δ수율 중앙값 (창부족 제외) — 보고 §2 표 대조');
const byType = {};
ev7.filter(e => e.s).forEach(e => (byType[e.type] = byType[e.type] || []).push(e.s.d));
const claimT = { ALARM: [5, 0.169, -0.048, 0.287], CAL: [6, 0.135, -0.219, 0.374], CLEAN: [21, -0.048, -1.471, 0.376], PART: [4, 0.106, -3.351, 0.335], PM: [6, -0.263, -3.351, 0.239], RECIPE: [2, -0.004, -0.029, 0.021] };
Object.keys(byType).sort().forEach(t => {
  const a = byType[t].slice().sort((x, y) => x - y);
  const med = a.length % 2 ? a[(a.length - 1) / 2] : (a[a.length / 2 - 1] + a[a.length / 2]) / 2;
  const c = claimT[t];
  const ok = a.length === c[0] && Math.abs(med - c[1]) < 0.0006 && Math.abs(a[0] - c[2]) < 0.0006 && Math.abs(a[a.length - 1] - c[3]) < 0.0006;
  P(`  ${t.padEnd(7)} n=${String(a.length).padStart(2)} 중앙값 ${f(med, 3).padStart(7)} 최소 ${f(a[0], 3).padStart(7)} 최대 ${f(a[a.length - 1], 3).padStart(7)}   주장 n=${c[0]} ${f(c[1], 3)} ${f(c[2], 3)} ${f(c[3], 3)}   ${ok ? '일치' : '불일치'}`);
});
P('');
P('보고 §2 "그 셋(07-28 PART·PM, 08-03 CLEAN)을 빼면 48건 어디에도 1%p 를 넘는 변화가 없다" 대조:');
const rest = ev7.filter(e => e.s).filter(e => !(e.chamber === 'CH-3B' && (e.date === '2026-07-28' || e.date === '2026-08-03')));
const worst = rest.slice().sort((a, b) => Math.abs(b.s.d) - Math.abs(a.s.d))[0];
P(`  남은 ${rest.length}건의 |Δ| 최대 = ${f(Math.abs(worst.s.d), 3)} %p (${worst.date} ${worst.chamber} ${worst.type})   → 1%p 넘는 건 ${rest.filter(e => Math.abs(e.s.d) > 1).length}건`);
P('');
P('보고 §5 "기간 안 RECIPE 는 2건뿐이고 CH-3B 에는 0건" 대조:');
const rec = eq.filter(r => r.type === 'RECIPE');
P(`  RECIPE ${rec.length}건: ${rec.map(r => r.date + '/' + r.chamber).join(', ')}   CH-3B 것 ${rec.filter(r => r.chamber === 'CH-3B').length}건`);
P('보고 §5 "CH-3B 정기 세정은 07-06·07-20·08-03·08-17 로 14일 간격" 대조:');
const cl3b = ev3b.filter(r => r.type === 'CLEAN' && r.detail.includes('정기'));
P(`  ${cl3b.map(r => r.date).join(' → ')}   간격 ${cl3b.slice(1).map((r, i) => diffD(r.date, cl3b[i].date)).join(', ')}일`);
P('보고 §5 "07-28 CH-3B 두 건, CH-3A 정비, 08-06 CH-2B 교체가 모두 김정비" 대조:');
eq.filter(r => ['2026-07-28', '2026-08-06'].includes(r.date) && ['PM', 'PART'].includes(r.type))
  .forEach(r => P(`  ${r.date} ${r.chamber} ${r.type} worker=${r.worker}`));
P('보고 §5 "ALARM 5건 중 CH-3B 것은 08-20 하나" 대조:');
const al = eq.filter(r => r.type === 'ALARM');
P(`  ALARM ${al.length}건: ${al.map(r => r.date + '/' + r.chamber).join(', ')}`);
P('보고 §6 "08-10 특별 세정 사유 파티클 대응 / 08-20 파티클 모니터 경고" 대조:');
eq.filter(r => ['2026-08-10', '2026-08-20'].includes(r.date) && r.chamber === 'CH-3B').forEach(r => P(`  ${r.date} ${r.chamber} ${r.type} '${r.detail}' ${r.dur}분`));
P('보고 §3a "CH-3A·CH-3B 둘 다 240분, 담당 김정비" 대조:');
eq.filter(r => r.date === '2026-07-28').forEach(r => P(`  ${r.chamber} ${r.type} ${r.dur}분 ${r.worker}`));
P('보고 §3b "SH-2200 교체 시간 90분과 95분" 대조:');
sh.forEach(r => P(`  ${r.date} ${r.chamber} ${r.dur}분 ${r.worker}`));
P('보고 §2 "범위를 -24일까지 넓히면 더해지는 셋의 Δ는 -0.39 ~ -0.10%p" 대조:');
['2026-07-05', '2026-07-06', '2026-07-20'].forEach(d => { const x = delta('CH-3B', d, 7); P(`  ${d} Δ=${f(x.d, 4)}`); });

H('[L] 끝');
fs.writeFileSync(path.join(__dirname, 'task-12-evidence.log'), out.join('\n') + '\n');
console.log(out.join('\n'));
