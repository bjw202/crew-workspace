# -*- coding: utf-8 -*-
"""task-16 인용 전수 대조 + 자기 서술 숫자 되세기.
행 번호는 1부터 센다. 리스트는 0부터이므로 src[n-1] 로 읽는다.
재현: cd rooms/수율개선-2026q3/analyst && python3 task-16-citation-check.py > task-16-citation-check.log
"""
import re, os

base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
J = lambda *p: os.path.join(base, *p)

doc   = J("analyst/task-16-part-inspection-vs-yield.md")
log16 = J("analyst/task-16-evidence.log")
log11 = J("analyst/task-11-evidence.log")
doc11 = J("analyst/task-11-equipment-history-vs-yield.md")
insp  = J("archivist/inbox/2026-09-09-part-incoming-inspection/"
          "28d181e9-647f-4b69-8fe7-554982ecd8de-part_incoming_inspection.csv")
eqf   = J("archivist/inbox/2026-09-08-equipment-history/"
          "423efc74-8819-445a-bb81-90ca388034fd-equipment_history.csv")
yld   = J("archivist/inbox/2026-09-08-yield-by-lot/"
          "44cdd855-be6e-4b66-a014-e7eb3a056769-yield_by_lot.csv")


def lines(p):
    txt = open(p, encoding="utf-8", newline="").read().replace("\r\n", "\n")
    if txt.endswith("\n"):
        txt = txt[:-1]
    return txt.split("\n")


D, L16, L11, D11 = lines(doc), lines(log16), lines(log11), lines(doc11)
I, E, Y = lines(insp), lines(eqf), lines(yld)

print("본문 %d행 · log16 %d행 · log11 %d행 · 대조(task-11 본문) %d행" % (len(D), len(L16), len(L11), len(D11)))
print("insp %d행 · eq %d행 · yield %d행 (모두 머리글을 1행으로 센 파일 행 수)" % (len(I), len(E), len(Y)))
print("행 번호는 1부터 센다. 아래 각 줄은 그 인용이 실제로 가리키는 줄의 앞부분이다.")
print("=" * 116)


def spans(tag):
    out = []
    pat = re.compile(re.escape(tag) + r"#(?:행 )?(\d+(?:[-~]\d+)?(?:·\d+(?:[-~]\d+)?)*)")
    for i, ln in enumerate(D, 1):
        for m in pat.finditer(ln):
            for part in m.group(1).split("·"):
                if "-" in part or "~" in part:
                    a, b = re.split(r"[-~]", part)
                    a, b = int(a), int(b)
                else:
                    a = b = int(part)
                out.append((i, tag + "#" + part, a, b))
    return out


def check(tag, src, srcname):
    got = spans(tag)
    print()
    print("[%s] 인용 %d곳 — 대상 %s (%d행)" % (tag, len(got), srcname, len(src)))
    print("-" * 116)
    bad = 0
    for docline, raw, a, b in got:
        if a < 1 or b > len(src) or a > b:
            bad += 1
            print("  본문#%-4d %-16s  ** 범위 벗어남 (대상은 1~%d행) **" % (docline, raw, len(src)))
            continue
        print("  본문#%-4d %-16s  %d행: %s" % (docline, raw, a, src[a - 1].strip()[:66]))
        if b != a:
            print("  %-28s  %d행: %s" % ("", b, src[b - 1].strip()[:66]))
    print("  범위를 벗어난 인용: %d곳" % bad)
    return len(got), bad


tot = bads = 0
for tag, src, name in [("insp", I, "입고 검사 성적서 CSV"),
                       ("eq", E, "설비 이력 CSV"),
                       ("yield", Y, "로트 수율 CSV"),
                       ("log16", L16, "analyst/task-16-evidence.log"),
                       ("log11", L11, "analyst/task-11-evidence.log"),
                       ("대조", D11, "analyst/task-11-equipment-history-vs-yield.md")]:
    n, b = check(tag, src, name)
    tot += n
    bads += b

print()
print("=" * 116)
print("인용 합계 %d곳 · 범위를 벗어난 인용 %d곳" % (tot, bads))

print()
print("[뜻 대조] 자리가 맞는 것만으로는 모자라다 — 그 줄에 그 낱말이 있는지 본다")
print("-" * 116)
anchors = [("insp", 8, "SH2200-B-0412"), ("insp", 8, "4.8"), ("insp", 11, "SH2200-B-0412"),
           ("insp", 19, "SH2200-A-1187"), ("insp", 19, "2.1"), ("insp", 5, "HC40-A-0771"),
           ("insp", 26, "OR15-B-3301"), ("insp", 22, "0.0031"), ("insp", 20, "mm"),
           ("eq", 18, "히터 코일"), ("eq", 27, "CH-3A"), ("eq", 28, "샤워헤드"),
           ("eq", 29, "CH-3B,PM"), ("eq", 38, "Showerhead"), ("eq", 39, "특별 세정"),
           ("eq", 48, "O-링"), ("eq", 49, "파티클 모니터")]
anchors16 = [(140, "CH-3A"), (144, "CH-3A"), (259, "0.7000"), (260, "0.8000"),
             (48, "5 / 34"), (59, "6 / 34"), (128, "0.11"), (132, "0.10"),
             (129, "-0.02"), (130, "-0.02"), (131, "0.06")]
anchors11 = [(115, "3a."), (126, "무너진다"), (46, "5절 표(201행)")]
src_map = {"insp": I, "eq": E}
miss = 0
for tag, n, word in anchors:
    ok = word in src_map[tag][n - 1]
    if not ok:
        miss += 1
    print("  %s#%-3d 에 \"%s\" %s" % (tag, n, word, "있음" if ok else "** 없음 **"))
for n, word in anchors16:
    ok = word in L16[n - 1]
    if not ok:
        miss += 1
    print("  log16#%-3d 에 \"%s\" %s" % (n, word, "있음" if ok else "** 없음 **"))
for n, word in anchors11:
    ok = word in D11[n - 1]
    if not ok:
        miss += 1
    print("  대조#%-4d 에 \"%s\" %s" % (n, word, "있음" if ok else "** 없음 **"))
print("  낱말이 없는 자리: %d곳" % miss)

print()
print("[자기 서술 숫자 되세기] — 본문이 스스로 센 수를 원본에서 다시 센다")
print("-" * 116)
rows = [l for l in I[1:] if l.strip()]
print("  성적서 데이터 행: %d (본문 '34행') -> %s" % (len(rows), "일치" if len(rows) == 34 else "불일치"))

def f(l, i):
    return l.split(",")[i]

units = {}
for l in rows:
    units[f(l, 7)] = units.get(f(l, 7), 0) + 1
print("  unit 별 행 수: %s" % " · ".join("%s %d" % (k, units[k]) for k in sorted(units)))

def over(l, conv):
    m, s = float(f(l, 6)), float(f(l, 5))
    if conv and f(l, 7) == "mm":
        m *= 1000
    return m > s

o2a = [l for l in rows if over(l, False)]
o2b = [l for l in rows if over(l, True)]
print("  규격 초과 (2a) %d행 · (2b) %d행 (본문 '5행'·'6행') -> %s"
      % (len(o2a), len(o2b), "일치" if (len(o2a), len(o2b)) == (5, 6) else "불일치"))

inst = [l for l in rows if f(l, 8) and f(l, 9)]
inst_u = sorted(set((f(l, 1), f(l, 2)) for l in inst))
print("  설치된 행 %d · 설치된 낱개 %d (본문 '5행'·'넷') -> %s"
      % (len(inst), len(inst_u), "일치" if (len(inst), len(inst_u)) == (5, 4) else "불일치"))
oi2a = [l for l in o2a if f(l, 8)]
oi2b = [l for l in o2b if f(l, 8)]
oiu = sorted(set((f(l, 1), f(l, 2)) for l in oi2b))
print("  규격 초과이면서 설치된 행: (2a) %d · (2b) %d · 낱개 %d (본문 '3행'·'둘') -> %s"
      % (len(oi2a), len(oi2b), len(oiu), "일치" if (len(oi2a), len(oi2b), len(oiu)) == (3, 3, 2) else "불일치"))

uniq = sorted(set((f(l, 1), f(l, 2)) for l in rows))
print("  서로 다른 낱개 수: %d (사이드카 '33')" % len(uniq))
sup = {}
for pn, sn in uniq:
    ls = [l for l in rows if (f(l, 1), f(l, 2)) == (pn, sn)]
    s = f(ls[0], 3) or "(빈칸)"
    ov = any(over(l, True) for l in ls)
    a, b = sup.get(s, (0, 0))
    sup[s] = (a + 1, b + (1 if ov else 0))
print("  공급사별 낱개(전체/초과, (2b)): %s (본문 BSTech 16/3 · AlphaParts 16/2)"
      % " · ".join("%s %d/%d" % (k, sup[k][0], sup[k][1]) for k in sorted(sup)))

erow = [l for l in E[1:] if l.strip()]
part = [l for l in erow if l.split(",")[2] == "PART"]
pw = [l for l in erow if ("파티클" in l or "particle" in l.lower())]
cal = [l for l in pw if l.split(",")[2] == "CAL"]
print("  설비 이력 데이터 행 %d · PART 사건 %d건 (본문 '넷') -> %s"
      % (len(erow), len(part), "일치" if len(part) == 4 else "불일치"))
print("  detail 에 파티클/particle 이 든 행 %d건 · 그중 CAL %d건 (본문 '8행'·'6행') -> %s"
      % (len(pw), len(cal), "일치" if (len(pw), len(cal)) == (8, 6) else "불일치"))
rest = [l for l in pw if l.split(",")[2] != "CAL"]
print("  남은 %d건의 챔버·날짜: %s (본문 '둘 다 CH-3B · 둘 다 07-28 뒤')"
      % (len(rest), " · ".join(x.split(",")[0] + " " + x.split(",")[1] for x in rest)))

print("  task-11 본문 줄 수: %d (본문 '281') -> %s" % (len(D11), "일치" if len(D11) == 281 else "불일치"))

print()
print("[전칭 문장 되세기] — \"~뿐이다 · 하나도 없다\" 는 반례를 세어 확인한다")
print("-" * 116)
b3 = [l for l in erow if l.split(",")[1] == "CH-3B"]
b3p = [l for l in b3 if l.split(",")[2] == "PART"]
print("  CH-3B 사건 %d건 · 그중 PART %d건 %s (본문 '08-20 까지 PART 는 07-28 하나')"
      % (len(b3), len(b3p), [x.split(",")[0] for x in b3p]))
print("  설비 이력 마지막 날짜: %s (본문 '08-20 에서 끝난다')"
      % max(l.split(",")[0].replace("/", "-") for l in erow))
fa, fb = E[26].split(","), E[28].split(",")
d27 = [i for i in range(6) if fa[i] != fb[i]]
print("  eq#27 과 eq#29 에서 값이 다른 칸 번호: %s (본문 '챔버만 다르다' → 칸 1 하나라야 한다)" % d27)
mm = [l for l in rows if f(l, 7) == "mm"]
mmni = [l for l in mm if not f(l, 8)]
print("  unit 이 mm 인 행 %d · 그중 설치되지 않은 행 %d (본문 '둘 다 설치되지 않았다') -> %s"
      % (len(mm), len(mmni), "일치" if len(mm) == len(mmni) == 2 else "불일치"))
print("  install_date 가 빈 행 %d (사이드카 '29') -> %s"
      % (len([l for l in rows if not f(l, 8)]),
         "일치" if len([l for l in rows if not f(l, 8)]) == 29 else "불일치"))

print()
print("=" * 116)
print("이 대조는 결정적이다 — 파일을 읽어 세기만 하고 난수를 쓰지 않는다.")
print("=" * 116)
