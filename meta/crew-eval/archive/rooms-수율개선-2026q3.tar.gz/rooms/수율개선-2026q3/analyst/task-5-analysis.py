#!/usr/bin/env python3
"""task-5: 작업 2 산출물에서 검토가 짚은 문장 셋의 근거를 보충 계산한다.
작업 2 의 수치를 다시 내는 것이 아니라, 작업 2 본문에는 있었으나 근거 로그에
인쇄되지 않았던 값 셋만 새로 인쇄한다. 작업 2 의 파일(analysis.py·evidence.log)은
읽지도 고치지도 않고, 원본 CSV 에서 처음부터 다시 계산한다.
출력: analyst/task-5-evidence.log
재현: cd rooms/수율개선-2026q3/analyst && python3 task-5-analysis.py > task-5-evidence.log
"""
import csv, math, statistics as st
from collections import defaultdict, OrderedDict

CSV = ("../archivist/inbox/2026-09-08-yield-by-lot/"
       "44cdd855-be6e-4b66-a014-e7eb3a056769-yield_by_lot.csv")
CP  = "2026-07-29"          # 작업 2 가 찾은 CH-3B 변화점
BASE_END = "2026-07-25"     # 기준선 구간의 끝(이 날은 포함하지 않음)

def line(s=""): print(s)

rows = []
with open(CSV, newline="", encoding="utf-8") as f:
    for r in csv.DictReader(f):
        rows.append(dict(date=r["date"], line=int(r["line"]), chamber=r["chamber"],
                         yield_pct=float(r["yield_pct"]),
                         defect_count=int(r["defect_count"]),
                         particle_defects=int(r["particle_defects"])))
CHAMBERS = sorted({r["chamber"] for r in rows})

def pearson(x, y):
    mx, my = st.mean(x), st.mean(y)
    num = sum((a-mx)*(b-my) for a, b in zip(x, y))
    den = math.sqrt(sum((a-mx)**2 for a in x) * sum((b-my)**2 for b in y))
    return num/den if den else float("nan")

def daily(rs, key):
    d = defaultdict(list)
    for r in rs: d[r["date"]].append(r)
    return OrderedDict((dt, key(d[dt])) for dt in sorted(d))

mean_yield = lambda g: st.mean(x["yield_pct"] for x in g)
pool_ratio = lambda g: sum(x["particle_defects"] for x in g) / sum(x["defect_count"] for x in g)

line("=" * 78)
line("task-5 보충 근거 — 작업 2 본문의 문장 셋에 대한 계산")
line("=" * 78)
line(f"입력 : {CSV}  (데이터 {len(rows)}행)")
line("작업 2 의 수치를 다시 내지 않는다. 아래 셋은 작업 2 본문에는 있었으나")
line("작업 2 근거 로그에 인쇄되지 않았던 값이다.")

# ---------- A. 상관 -0.900 의 정체 ----------
line("")
line("=" * 78)
line("[A] 파티클 비율과 수율의 상관을 07-29 앞뒤로 나누면 (본문 문장 ①의 근거)")
line("=" * 78)
line("작업 2 근거 로그 [7] 절에는 챔버별 '전체' 상관만 있었다.")
line(f"여기서는 같은 상관을 {CP} 앞뒤 두 구간 안에서 따로 낸다.")
line("로트 단위, 파티클 비율 = particle_defects / defect_count (로트 하나의 비율).")
line("")
line("chamber | 전체 r | 07-29 이전 r (n) | 07-29 이후 r (n)")
for ch in CHAMBERS:
    rs = [r for r in rows if r["chamber"] == ch]
    def rr(sub):
        return pearson([r["yield_pct"] for r in sub],
                       [r["particle_defects"]/r["defect_count"] for r in sub])
    b = [r for r in rs if r["date"] <  CP]
    a = [r for r in rs if r["date"] >= CP]
    line(f"{ch} | {rr(rs):+.3f} | {rr(b):+.3f} ({len(b)}) | {rr(a):+.3f} ({len(a)})")

rs = [r for r in rows if r["chamber"] == "CH-3B"]
b = [r for r in rs if r["date"] < CP]; a = [r for r in rs if r["date"] >= CP]
pb = [r["particle_defects"]/r["defect_count"] for r in b]
pa = [r["particle_defects"]/r["defect_count"] for r in a]
line("")
line("CH-3B 의 두 무리가 실제로 떨어져 있는지 — 파티클 비율의 범위:")
line(f"  07-29 이전 {len(pb)}로트: 최소 {min(pb):.4f} · 최대 {max(pb):.4f} · 평균 {st.mean(pb):.4f}")
line(f"  07-29 이후 {len(pa)}로트: 최소 {min(pa):.4f} · 최대 {max(pa):.4f} · 평균 {st.mean(pa):.4f}")
line(f"  두 무리의 값이 겹치는가: {'겹침' if max(pb) >= min(pa) else '겹치지 않음 (전 최대 < 후 최소)'}")
line(f"  수율도 같은 방식으로: 이전 최소 {min(r['yield_pct'] for r in b):.2f} ~ 최대 "
     f"{max(r['yield_pct'] for r in b):.2f} · 이후 최소 {min(r['yield_pct'] for r in a):.2f} ~ 최대 "
     f"{max(r['yield_pct'] for r in a):.2f}")

# ---------- B. -3sd 첫 이탈일의 검색 범위 ----------
line("")
line("=" * 78)
line(f"[B] 기준선 이탈일을 검색 범위 없이 전 기간에서 다시 (본문 문장 ②의 근거)")
line("=" * 78)
dy = daily(rs, mean_yield); dp = daily(rs, pool_ratio)
base_y = [dy[d] for d in dy if d < BASE_END]
base_p = [dp[d] for d in dp if d < BASE_END]
my_, sy_ = st.mean(base_y), st.pstdev(base_y)
mp_, sp_ = st.mean(base_p), st.pstdev(base_p)
line(f"기준선(2026-07-01 ~ 07-24, {len(base_y)}일): 수율 {my_:.2f}%(sd {sy_:.2f}) · "
     f"파티클 비율 {mp_:.4f}(sd {sp_:.4f})")
line(f"-3sd 문턱 = {my_-3*sy_:.2f}% · -2sd 문턱 = {my_-2*sy_:.2f}%")
line("")
line("전 기간(07-01~08-25) 56일 중 일평균 수율이 -3sd 문턱 아래인 날 — 전부:")
below3 = [(d, dy[d]) for d in dy if dy[d] < my_ - 3*sy_]
for d, v in below3:
    line(f"  {d} | {v:.2f}%")
line(f"  합계 {len(below3)}일")
before_cp = [d for d, v in below3 if d < CP]
line(f"  이 중 {CP} 이전에 있던 날: {before_cp if before_cp else '없음'}")
line("")
line("기준선 구간 안의 그 날과 그 앞뒤 사흘:")
ds = list(dy)
for d, _ in below3:
    if d < CP:
        i = ds.index(d)
        for j in range(max(0, i-1), min(len(ds), i+2)):
            line(f"  {ds[j]} | {dy[ds[j]]:.2f}% | 파티클 비율 {dp[ds[j]]:.4f}")
line("")
line("전 기간에서 파티클 비율이 +3sd 문턱 위인 날 — 전부:")
above3 = [(d, dp[d]) for d in dp if dp[d] > mp_ + 3*sp_]
line(f"  첫 날 {above3[0][0]} · 마지막 날 {above3[-1][0]} · 합계 {len(above3)}일")
line(f"  {CP} 이전에 있던 날: "
     f"{[d for d, v in above3 if d < CP] if [d for d,v in above3 if d < CP] else '없음'}")
line("")
line(f"{CP} 이후 일평균 수율이 -2sd 문턱({my_-2*sy_:.2f}%) 위로 회복한 날: "
     f"{[d for d in dy if d >= CP and dy[d] > my_-2*sy_] or '없음 (0일)'}")

# ---------- C. 파티클 비율의 두 정의 ----------
line("")
line("=" * 78)
line("[C] 파티클 비율의 두 정의를 나란히 (본문 문장 ③의 근거)")
line("=" * 78)
line("정의 P(합÷합)  = 구간의 particle_defects 합 / 구간의 defect_count 합")
line("정의 D(일평균)  = 날마다 (그날 particle 합 / 그날 defect 합)을 낸 뒤 그 값들의 평균")
line("작업 2 본문 표는 정의 P, 작업 2 근거 로그 [3] 절의 전·후 평균과 t·p 는 정의 D 다.")
line("")
line("chamber | 기준일 | P 전 | P 후 | P 차이 | D 전 | D 후 | D 차이")
CPS = {"CH-1A": "2026-07-13", "CH-1B": "2026-07-13", "CH-2A": "2026-08-17",
       "CH-2B": "2026-08-19", "CH-3A": "2026-08-14", "CH-3B": "2026-07-29"}
for ch in CHAMBERS:
    rsx = [r for r in rows if r["chamber"] == ch]
    cp = CPS[ch]
    b_ = [r for r in rsx if r["date"] <  cp]; a_ = [r for r in rsx if r["date"] >= cp]
    P_b = pool_ratio(b_); P_a = pool_ratio(a_)
    dpx = daily(rsx, pool_ratio)
    D_b = st.mean([dpx[d] for d in dpx if d <  cp])
    D_a = st.mean([dpx[d] for d in dpx if d >= cp])
    line(f"{ch} | {cp} | {P_b:.4f} | {P_a:.4f} | {P_a-P_b:+.4f} | "
         f"{D_b:.4f} | {D_a:.4f} | {D_a-D_b:+.4f}")
line("")
line("두 정의가 갈리는 까닭: 날마다 불량 총수가 다르므로, 정의 D 는 불량이 적은 날에도")
line("같은 무게를 준다. 작업 2 의 결론에 쓰인 값은 정의 P 다.")

# ---------- D. 작업 2 핵심 수치가 그대로인지 다시 확인 ----------
line("")
line("=" * 78)
line("[D] 작업 2 핵심 수치 재확인 — 이 새 판에서 바뀐 것이 없음을 보이기 위해")
line("=" * 78)
by = [dy[d] for d in dy if d <  CP]; ay = [dy[d] for d in dy if d >= CP]
na, nb = len(ay), len(by)
va, vb = st.variance(by), st.variance(ay)
t = (st.mean(ay) - st.mean(by)) / math.sqrt(va/nb + vb/na)
line(f"CH-3B 일평균 수율 {CP} 전 {nb}일 평균 : {st.mean(by):.2f}%")
line(f"CH-3B 일평균 수율 {CP} 이후 {na}일 평균 : {st.mean(ay):.2f}%")
line(f"차이 : {st.mean(ay)-st.mean(by):+.2f} %p")
line(f"Welch t : {t:.2f}")
line(f"파티클 비율(정의 P) {CP} 전 → 후 : {pool_ratio(b):.4f} → {pool_ratio(a):.4f}")
line("(순열검정 p=0.0005 는 난수를 쓰므로 여기서 다시 내지 않는다 —"
     " 작업 2 의 task-2-evidence.log#81 이 그대로 근거다.)")
line("")
line("=" * 78)
line("계산 끝. 재현: cd rooms/수율개선-2026q3/analyst && python3 task-5-analysis.py")
line("=" * 78)
