# -*- coding: utf-8 -*-
"""
task-11 분석 스크립트
재현: cd <루트>/analyst && /usr/bin/python3 task-11-analysis.py > task-11-evidence.log
표준 라이브러리만 사용 (csv, statistics, random, math, datetime, unicodedata).
원본 CSV 는 읽기 전용으로만 연다.
"""

import csv
import math
import random
import statistics
import unicodedata
from datetime import date, timedelta

# ---------------------------------------------------------------- 경로
ROOT = "<작업판>/rooms/수율개선-2026q3"
EQ_PATH = (ROOT + "/archivist/inbox/2026-09-08-equipment-history/"
           "423efc74-8819-445a-bb81-90ca388034fd-equipment_history.csv")
YL_PATH = (ROOT + "/archivist/inbox/2026-09-08-yield-by-lot/"
           "44cdd855-be6e-4b66-a014-e7eb3a056769-yield_by_lot.csv")

SEED = 20260909
DATA_START = date(2026, 7, 1)
DATA_END = date(2026, 8, 25)
DROP_DAY = date(2026, 7, 29)
CHAMBERS = ["CH-1A", "CH-1B", "CH-2A", "CH-2B", "CH-3A", "CH-3B"]
EVENT_TYPES = ["ALARM", "CAL", "CLEAN", "PART", "PM", "RECIPE"]
WIN = 7          # 전후 창 길이(일)
MIN_LOTS = 8     # 창 하나에 필요한 최소 로트 수


# ---------------------------------------------------------------- 출력 도우미
def dw(s):
    """동아시아 전각 문자를 2칸으로 세는 표시 폭."""
    n = 0
    for ch in s:
        n += 2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1
    return n


def padr(s, n):
    s = str(s)
    return s + " " * max(0, n - dw(s))


def padl(s, n):
    s = str(s)
    return " " * max(0, n - dw(s)) + s


def sec(num, title):
    print("=" * 100)
    print("[%d] %s" % (num, title))
    print("=" * 100)


def f2(x):
    return "n/a" if x is None else "%.2f" % x


def f4(x):
    return "n/a" if x is None else "%.4f" % x


# ---------------------------------------------------------------- 통계
def mean(xs):
    return sum(xs) / len(xs)


def sd(xs, ddof=1):
    n = len(xs)
    if n - ddof <= 0:
        return None
    m = mean(xs)
    return math.sqrt(sum((x - m) ** 2 for x in xs) / (n - ddof))


def welch(a, b):
    """(t, df) — t = (mean(b) - mean(a)) / se, 분산은 ddof=1."""
    na, nb = len(a), len(b)
    if na < 2 or nb < 2:
        return None, None
    va = statistics.variance(a)
    vb = statistics.variance(b)
    se2 = va / na + vb / nb
    if se2 <= 0:
        return None, None
    t = (mean(b) - mean(a)) / math.sqrt(se2)
    num = se2 ** 2
    den = (va / na) ** 2 / (na - 1) + (vb / nb) ** 2 / (nb - 1)
    df = num / den if den > 0 else None
    return t, df


def welch_from_sums(s1, q1, n1, s2, q2, n2):
    """누적합으로 낸 Welch t (분산 ddof=1). 앞 구간 1, 뒤 구간 2 → t = (m2-m1)/se."""
    if n1 < 2 or n2 < 2:
        return None
    m1 = s1 / n1
    m2 = s2 / n2
    v1 = (q1 - n1 * m1 * m1) / (n1 - 1)
    v2 = (q2 - n2 * m2 * m2) / (n2 - 1)
    if v1 < 0:
        v1 = 0.0
    if v2 < 0:
        v2 = 0.0
    se2 = v1 / n1 + v2 / n2
    if se2 <= 0:
        return None
    return (m2 - m1) / math.sqrt(se2)


def pct(sorted_vals, q):
    """선형보간 백분위 (numpy 기본과 같은 방식)."""
    n = len(sorted_vals)
    if n == 0:
        return None
    if n == 1:
        return sorted_vals[0]
    pos = q / 100.0 * (n - 1)
    lo = int(math.floor(pos))
    hi = int(math.ceil(pos))
    if lo == hi:
        return sorted_vals[lo]
    return sorted_vals[lo] + (sorted_vals[hi] - sorted_vals[lo]) * (pos - lo)


def daterange(a, b):
    d = a
    while d <= b:
        yield d
        d += timedelta(days=1)


# ---------------------------------------------------------------- 입력 읽기
def load_equipment():
    rows = []
    norm_rows = []       # 날짜를 정규화한 데이터 행 번호
    missing_worker = []  # worker 가 빈칸인 데이터 행
    with open(EQ_PATH, "r", encoding="utf-8", newline="") as fh:
        rd = csv.DictReader(fh)
        header = rd.fieldnames
        for i, r in enumerate(rd, start=1):
            raw_date = r["date"]
            norm = raw_date.replace("/", "-")
            if norm != raw_date:
                norm_rows.append((i, raw_date, norm))
            worker = (r["worker"] or "").strip()
            if worker == "":
                missing_worker.append((i, norm, r["chamber"], r["event_type"]))
                worker = None
            rows.append({
                "row": i,
                "date": date.fromisoformat(norm),
                "chamber": r["chamber"].strip(),
                "event_type": r["event_type"].strip(),
                "detail": r["detail"].strip(),
                "duration_min": int(r["duration_min"]),
                "worker": worker,
            })
    return rows, header, norm_rows, missing_worker


def load_yield():
    rows = []
    with open(YL_PATH, "r", encoding="utf-8", newline="") as fh:
        rd = csv.DictReader(fh)
        header = rd.fieldnames
        for i, r in enumerate(rd, start=1):
            rows.append({
                "row": i,
                "lot_id": r["lot_id"].strip(),
                "date": date.fromisoformat(r["date"].strip().replace("/", "-")),
                "line": r["line"].strip(),
                "chamber": r["chamber"].strip(),
                "yield_pct": float(r["yield_pct"]),
                "defect_count": int(r["defect_count"]),
                "particle_defects": int(r["particle_defects"]),
            })
    return rows, header


EQ, EQ_HDR, NORM_ROWS, MISSING_WORKER = load_equipment()
YL, YL_HDR = load_yield()

# 색인
BY_CD = {}   # (chamber, date) -> 로트 목록
for r in YL:
    BY_CD.setdefault((r["chamber"], r["date"]), []).append(r)

EV_BY_CD = {}  # (chamber, date) -> 이벤트 목록
for e in EQ:
    EV_BY_CD.setdefault((e["chamber"], e["date"]), []).append(e)

DAYS = list(daterange(DATA_START, DATA_END))


def lots(chamber, d1, d2, skip=None):
    out = []
    for d in daterange(d1, d2):
        if skip is not None and d == skip:
            continue
        out.extend(BY_CD.get((chamber, d), []))
    return out


def pratio(ls):
    """정의 P = 구간의 particle_defects 합 / 구간의 defect_count 합."""
    dc = sum(x["defect_count"] for x in ls)
    if dc == 0:
        return None
    return sum(x["particle_defects"] for x in ls) / dc


def daily_yield(chamber):
    """56일 일평균 수율 (하루 2로트의 평균)."""
    return [mean([x["yield_pct"] for x in BY_CD[(chamber, d)]]) for d in DAYS]


def daily_pratio(chamber, d1, d2):
    out = []
    for d in daterange(d1, d2):
        p = pratio(BY_CD.get((chamber, d), []))
        if p is not None:
            out.append(p)
    return out


def window(chamber, d):
    """이벤트 (chamber, d) 의 전후 창 통계. 당일 d 는 양쪽 모두에서 제외."""
    b = lots(chamber, d - timedelta(days=WIN), d - timedelta(days=1))
    a = lots(chamber, d + timedelta(days=1), d + timedelta(days=WIN))
    res = {"n_b": len(b), "n_a": len(a), "ok": len(b) >= MIN_LOTS and len(a) >= MIN_LOTS}
    if not res["ok"]:
        res.update({"mb": None, "ma": None, "delta": None, "t": None,
                    "pb": None, "pa": None, "dp": None})
        return res
    yb = [x["yield_pct"] for x in b]
    ya = [x["yield_pct"] for x in a]
    t, _ = welch(yb, ya)
    pb = pratio(b)
    pa = pratio(a)
    res.update({"mb": mean(yb), "ma": mean(ya), "delta": mean(ya) - mean(yb),
                "t": t, "pb": pb, "pa": pa,
                "dp": (pa - pb) if (pa is not None and pb is not None) else None})
    return res


def disturb(chamber, d):
    """후 창 안에 있는 그 챔버의 다른 이벤트 목록."""
    out = []
    for k in range(1, WIN + 1):
        dd = d + timedelta(days=k)
        for e in EV_BY_CD.get((chamber, dd), []):
            out.append("%s:%s" % (dd.strftime("%m-%d"), e["event_type"]))
    return ",".join(out) if out else "-"


# ================================================================ 머리말
print("task-11 분석 로그 — 설비 이력과 로트 수율의 대조")
print("생성 스크립트: task-11-analysis.py  (표준 라이브러리만, 외부 의존 없음)")
print("규약: 이 로그의 모든 표준편차와 Welch t 는 표본표준편차(ddof=1)로 낸다."
      " 단 [1]절에서만 눈금 맞춤을 위해 모표준편차(ddof=0)를 나란히 인쇄한다.")
print("규약: 파티클 비율 정의 P = 구간의 particle_defects 합 / 구간의 defect_count 합.")
print("규약: 두 집단 비교는 Welch t (분산 ddof=1, 자유도 Welch-Satterthwaite)."
      " 부호는 t = (뒤 구간 평균 - 앞 구간 평균) / 표준오차 이므로 음수는 하락이다.")
print("규약: 난수 seed = %d (고정). 난수는 [8]절 순열검정에서만 쓴다." % SEED)
print()

# ================================================================ [0]
sec(0, "입력 검사")
print("설비 이력 파일: %s" % EQ_PATH)
print("  데이터 행 수: %d   열 수: %d   열 이름: %s" % (len(EQ), len(EQ_HDR), ",".join(EQ_HDR)))
print("  날짜 범위: %s ~ %s" % (min(e["date"] for e in EQ), max(e["date"] for e in EQ)))
print("  챔버별 행 수:")
for c in CHAMBERS:
    print("    %s : %d" % (c, sum(1 for e in EQ if e["chamber"] == c)))
print("  event_type 별 행 수:")
for t in EVENT_TYPES:
    print("    %-7s : %d" % (t, sum(1 for e in EQ if e["event_type"] == t)))
print()
print("로트 수율 파일: %s" % YL_PATH)
print("  데이터 행 수: %d   열 수: %d   열 이름: %s" % (len(YL), len(YL_HDR), ",".join(YL_HDR)))
print("  날짜 범위: %s ~ %s  (%d일)" % (min(r["date"] for r in YL), max(r["date"] for r in YL), len(DAYS)))
print("  챔버별 행 수:")
for c in CHAMBERS:
    print("    %s : %d" % (c, sum(1 for r in YL if r["chamber"] == c)))
print()
print("-- 함정 1: 날짜 표기 정규화 (슬래시 -> 하이픈) --")
print("  정규화한 행 수: %d  (기대 1)  %s" % (len(NORM_ROWS), "일치" if len(NORM_ROWS) == 1 else "불일치"))
for i, raw, norm in NORM_ROWS:
    print("  데이터 %d행째: '%s' -> '%s'" % (i, raw, norm))
print()
print("-- 함정 2: worker 결측 --")
print("  worker 가 빈칸인 행 수: %d" % len(MISSING_WORKER))
for i, d, c, t in MISSING_WORKER:
    print("  데이터 %d행째: %s %s %s  worker = (결측, None 으로 둠. 채우지 않음)" % (i, d, c, t))
print()
print("-- 함정 3: SH-2200 부품 묶기 (문자열이 아니라 부분 문자열로) --")
sh = [e for e in EQ if "SH-2200" in e["detail"]]
print("  'SH-2200' 부분 문자열로 묶은 건수: %d  (기대 2)  %s" % (len(sh), "일치" if len(sh) == 2 else "불일치"))
for e in sh:
    print("  %s %s %s  detail='%s'  (표기가 서로 다르다)" % (e["date"], e["chamber"], e["event_type"], e["detail"]))
distinct = sorted(set(e["detail"] for e in sh))
print("  서로 다른 detail 표기 %d가지: %s" % (len(distinct), " | ".join(distinct)))
print()
print("-- 수율 CSV: 챔버당 하루 정확히 2로트인가 --")
viol = []
for c in CHAMBERS:
    for d in DAYS:
        n = len(BY_CD.get((c, d), []))
        if n != 2:
            viol.append((c, d, n))
print("  검사한 (챔버,날) 조합: %d" % (len(CHAMBERS) * len(DAYS)))
print("  로트 수가 2가 아닌 조합: %d" % len(viol))
for c, d, n in viol:
    print("    %s %s : %d 로트" % (c, d, n))
print("  빈칸 검사: 모든 행에서 yield_pct·defect_count·particle_defects 파싱 성공 (실패 시 예외로 중단됨)")
print()

# ================================================================ [1]
sec(1, "표준편차 규약과 앞선 분석과의 눈금 맞춤")
dy3b = daily_yield("CH-3B")
print("CH-3B 일평균 수율 점 개수: %d (기대 56)  %s" % (len(dy3b), "일치" if len(dy3b) == 56 else "불일치"))
print()

base_days = [d for d in DAYS if date(2026, 7, 1) <= d <= date(2026, 7, 24)]
seg_b = [dy3b[DAYS.index(d)] for d in DAYS if date(2026, 7, 1) <= d <= date(2026, 7, 28)]
seg_a = [dy3b[DAYS.index(d)] for d in DAYS if date(2026, 7, 29) <= d <= date(2026, 8, 25)]
base_y = [dy3b[DAYS.index(d)] for d in base_days]
base_p = daily_pratio("CH-3B", date(2026, 7, 1), date(2026, 7, 24))

print(padr("항목", 46) + padl("n", 4) + padl("ddof=0 (모)", 14) + padl("ddof=1 (표본)", 15))
print("-" * 79)
rows_sd = [
    ("(a) 기준선 07-01~07-24 24일 수율 sd", base_y),
    ("(b) 07-01~07-28 28일 수율 sd", seg_b),
    ("(c) 07-29~08-25 28일 수율 sd", seg_a),
    ("(d) 기준선 24일 파티클 비율(정의 P, 날마다) sd", base_p),
]
for label, xs in rows_sd:
    print(padr(label, 46) + padl(len(xs), 4)
          + padl("%.4f" % sd(xs, 0), 14) + padl("%.4f" % sd(xs, 1), 15))
print()
print("참고 평균: 기준선 24일 수율 %.4f · 07-01~07-28 %.4f · 07-29~08-25 %.4f · 기준선 파티클비율 %.4f"
      % (mean(base_y), mean(seg_b), mean(seg_a), mean(base_p)))
print()

t_28, df_28 = welch(seg_b, seg_a)
print("2026-07-29 앞뒤 28일 대 28일 Welch t (ddof=1): t = %.4f   df = %.2f   n = %d vs %d"
      % (t_28, df_28, len(seg_b), len(seg_a)))
print("  소수 둘째 자리까지: %.2f" % t_28)
print("  앞선 분석이 적은 값: -22.06")
print("  대조 결과: %s" % ("일치" if abs(round(t_28, 2) - (-22.06)) < 1e-9 else "불일치"))
print()

m0, s0 = mean(base_y), sd(base_y, 0)
m1, s1 = mean(base_y), sd(base_y, 1)
print("기준선(07-01~07-24, 24일) 수율 문턱")
print(padr("문턱", 16) + padl("ddof=0 (모)", 14) + padl("ddof=1 (표본)", 15) + padl("차이(1-0)", 12))
print("-" * 57)
for k in (2, 3):
    v0 = m0 - k * s0
    v1 = m1 - k * s1
    print(padr("평균 - %dsd" % k, 16) + padl("%.4f" % v0, 14) + padl("%.4f" % v1, 15)
          + padl("%+.4f" % (v1 - v0), 12))
print("  평균 %.4f · sd(ddof=0) %.4f · sd(ddof=1) %.4f · sd 비율 %.4f"
      % (m0, s0, s1, s1 / s0))
print("  읽는 법: 표본(ddof=1) 문턱이 모(ddof=0) 문턱보다 더 낮다. 즉 표본 쪽이 더 보수적이다.")
pm, ps0, ps1 = mean(base_p), sd(base_p, 0), sd(base_p, 1)
print("  (추가, 방향이 반대인 지표) 기준선 파티클 비율 문턱: 평균 %.4f · +2sd = %.4f(ddof=0) / %.4f(ddof=1)"
      % (pm, pm + 2 * ps0, pm + 2 * ps1))
print()

# ================================================================ [2]
sec(2, "CH-3B 의 이벤트 전부와 2026-07-29 와의 간격")
print("간격 = (이벤트 날 - 2026-07-29) 일수. 음수 = 하락 이전, 0 = 당일, 양수 = 이후.")
print()
ev3b = sorted([e for e in EQ if e["chamber"] == "CH-3B"], key=lambda e: (e["date"], e["event_type"]))
print(padr("date", 12) + padr("type", 8) + padr("detail", 34)
      + padl("dur(min)", 10) + "  " + padr("worker", 10) + padl("07-29 기준 간격(일)", 20))
print("-" * 96)
for e in ev3b:
    gap = (e["date"] - DROP_DAY).days
    print(padr(str(e["date"]), 12) + padr(e["event_type"], 8) + padr(e["detail"], 34)
          + padl(e["duration_min"], 10) + "  "
          + padr(e["worker"] if e["worker"] else "(결측)", 10)
          + padl("%+d" % gap, 20))
print("-" * 96)
print("인쇄한 CH-3B 이벤트 행 수 합계: %d" % len(ev3b))
before_drop = [e for e in ev3b if (e["date"] - DROP_DAY).days < 0]
after_drop = [e for e in ev3b if (e["date"] - DROP_DAY).days > 0]
print("  하락일 07-29 이전 이벤트 %d건, 이후 이벤트 %d건, 당일 이벤트 %d건"
      % (len(before_drop), len(after_drop), len(ev3b) - len(before_drop) - len(after_drop)))
if before_drop:
    nearest = max(before_drop, key=lambda e: e["date"])
    same_day = [e for e in before_drop if e["date"] == nearest["date"]]
    print("  하락일 07-29 직전 가장 가까운 이벤트: %s (%+d일) — %s"
          % (nearest["date"], (nearest["date"] - DROP_DAY).days,
             ", ".join("%s '%s'" % (e["event_type"], e["detail"]) for e in same_day)))
print()

# ================================================================ [3]
sec(3, "이벤트 48건 전부의 전후 수율 변화")
print("창 규칙: 전 창 = 같은 챔버의 D-7~D-1 로트, 후 창 = D+1~D+7 로트."
      " 이벤트 당일 D 는 전·후 두 창 모두에서 제외한다(정비 중 투입 로트의 상태가 애매하므로).")
print("창부족 = 전 창 또는 후 창의 로트가 8개 미만(데이터 기간 07-01~08-25 밖으로 나간 경우).")
print("Δ수율 = 후 평균 - 전 평균 (%p). Welch t 부호도 같다. ΔP = 후 P - 전 P.")
print()
H = (padr("date", 11) + padr("chamber", 8) + padr("type", 7) + padr("detail(20자)", 22)
     + padl("n_전", 5) + padl("n_후", 5) + padl("전수율", 9) + padl("후수율", 9)
     + padl("Δ수율", 8) + padl("Welch_t", 9) + padl("P_전", 8) + padl("P_후", 8)
     + padl("ΔP", 9) + "  " + padr("창교란", 22))
print(H)
print("-" * dw(H))
results = {}   # (chamber, date, type) -> window 결과
short_cnt = 0
for e in sorted(EQ, key=lambda x: (x["date"], x["chamber"], x["event_type"])):
    w = window(e["chamber"], e["date"])
    results[(e["chamber"], e["date"], e["event_type"])] = w
    det = e["detail"][:20]
    line = (padr(str(e["date"]), 11) + padr(e["chamber"], 8) + padr(e["event_type"], 7)
            + padr(det, 22) + padl(w["n_b"], 5) + padl(w["n_a"], 5))
    if not w["ok"]:
        short_cnt += 1
        line += padl("창부족", 9) + padl("창부족", 9) + padl("창부족", 8) + padl("창부족", 9) \
            + padl("창부족", 8) + padl("창부족", 8) + padl("창부족", 9)
    else:
        line += (padl("%.3f" % w["mb"], 9) + padl("%.3f" % w["ma"], 9)
                 + padl("%+.3f" % w["delta"], 8) + padl(f2(w["t"]), 9)
                 + padl(f4(w["pb"]), 8) + padl(f4(w["pa"]), 8)
                 + padl("%+.4f" % w["dp"] if w["dp"] is not None else "n/a", 9))
    line += "  " + padr(disturb(e["chamber"], e["date"]), 22)
    print(line)
print("-" * dw(H))
print("인쇄한 이벤트 행 수 합계: %d (기대 48)  %s" % (len(EQ), "일치" if len(EQ) == 48 else "불일치"))
print("창부족으로 통계를 내지 못한 건수 합계: %d" % short_cnt)
print("통계를 낸 건수: %d" % (len(EQ) - short_cnt))
print()
print("-- Δ수율이 작은 순(가장 크게 떨어진 순) 상위 10건 --")
ranked = sorted([(k, v) for k, v in results.items() if v["ok"]], key=lambda kv: kv[1]["delta"])
H2 = (padl("#", 3) + "  " + padr("date", 11) + padr("chamber", 8) + padr("type", 7)
      + padl("Δ수율", 9) + padl("Welch_t", 9) + padl("ΔP", 10) + "  " + padr("detail", 30))
print(H2)
print("-" * dw(H2))
for i, (k, v) in enumerate(ranked[:10], start=1):
    ch, d, ty = k
    det = [e["detail"] for e in EQ if e["chamber"] == ch and e["date"] == d and e["event_type"] == ty][0]
    print(padl(i, 3) + "  " + padr(str(d), 11) + padr(ch, 8) + padr(ty, 7)
          + padl("%+.3f" % v["delta"], 9) + padl(f2(v["t"]), 9)
          + padl("%+.4f" % v["dp"], 10) + "  " + padr(det, 30))
print()

# ================================================================ [4]
sec(4, "event_type 별 묶음 대조")
print("목적: 그 종류의 이벤트가 보통 수율을 움직이는가. 창부족 건은 목록·중앙값·최소·최대에서 뺀다.")
print()
for ty in EVENT_TYPES:
    evs = sorted([e for e in EQ if e["event_type"] == ty], key=lambda x: (x["date"], x["chamber"]))
    usable = []
    dropped = 0
    items = []
    for e in evs:
        w = results[(e["chamber"], e["date"], e["event_type"])]
        if not w["ok"]:
            dropped += 1
            continue
        usable.append(w["delta"])
        items.append("%s/%s/%+.3f" % (e["date"].strftime("%m-%d"), e["chamber"], w["delta"]))
    print("%-7s  건수 %d  (창부족으로 뺀 건수 %d, 남은 건수 %d)" % (ty, len(evs), dropped, len(usable)))
    if items:
        for i in range(0, len(items), 4):
            print("         " + "   ".join(padr(x, 22) for x in items[i:i + 4]).rstrip())
    else:
        print("         (통계를 낼 수 있는 건이 없다)")
    if usable:
        print("         Δ수율 중앙값 %+.3f   최소 %+.3f   최대 %+.3f   평균 %+.3f"
              % (statistics.median(usable), min(usable), max(usable), mean(usable)))
    else:
        print("         Δ수율 중앙값 n/a   최소 n/a   최대 n/a   평균 n/a")
    print()

# ================================================================ [5]
sec(5, "대조군 넷 — 개별 자리")

print("(5a) PM(정기 정비) 6건")
pm_list = [(date(2026, 7, 14), "CH-1A"), (date(2026, 7, 14), "CH-1B"),
           (date(2026, 7, 21), "CH-2A"), (date(2026, 7, 21), "CH-2B"),
           (date(2026, 7, 28), "CH-3A"), (date(2026, 7, 28), "CH-3B")]
H3 = (padr("date", 11) + padr("chamber", 8) + padl("n_전", 5) + padl("n_후", 5)
      + padl("전수율", 9) + padl("후수율", 9) + padl("Δ수율", 9) + padl("Welch_t", 9)
      + padl("P_전", 8) + padl("P_후", 8) + padl("ΔP", 10))
print(H3)
print("-" * dw(H3))
pm_delta = {}
for d, c in pm_list:
    w = results[(c, d, "PM")]
    pm_delta[c] = w
    print(padr(str(d), 11) + padr(c, 8) + padl(w["n_b"], 5) + padl(w["n_a"], 5)
          + padl("%.3f" % w["mb"], 9) + padl("%.3f" % w["ma"], 9)
          + padl("%+.3f" % w["delta"], 9) + padl(f2(w["t"]), 9)
          + padl(f4(w["pb"]), 8) + padl(f4(w["pa"]), 8) + padl("%+.4f" % w["dp"], 10))
print("-" * dw(H3))
pm_ds = [pm_delta[c]["delta"] for _, c in pm_list]
print("PM 6건 Δ수율: 중앙값 %+.3f   최소 %+.3f   최대 %+.3f" % (statistics.median(pm_ds), min(pm_ds), max(pm_ds)))
print()
same_day = sorted(set(e["chamber"] for e in EQ if e["date"] == date(2026, 7, 28) and e["event_type"] == "PM"))
print("★ 같은 날 대조: 2026-07-28 에 PM 을 받은 챔버는 %s — 두 챔버가 같은 날 같은 정기 정비를 받았다."
      % ", ".join(same_day))
a3, b3 = pm_delta["CH-3A"], pm_delta["CH-3B"]
print("   CH-3A 07-28 PM : Δ수율 %+.3f %%p   ΔP %+.4f   (전 %.3f -> 후 %.3f)"
      % (a3["delta"], a3["dp"], a3["mb"], a3["ma"]))
print("   CH-3B 07-28 PM : Δ수율 %+.3f %%p   ΔP %+.4f   (전 %.3f -> 후 %.3f)"
      % (b3["delta"], b3["dp"], b3["mb"], b3["ma"]))
print("   두 챔버 Δ수율 차이 (CH-3B - CH-3A) = %+.3f %%p" % (b3["delta"] - a3["delta"]))
print("   주의: CH-3B 07-28 에는 PM 과 PART(SH-2200 교체)가 같은 날 함께 있다."
      " 두 이벤트의 전후 창이 같으므로 Δ 값도 같다 — 이 창만으로는 둘을 갈라내지 못한다.")
print()

print("(5b) SH-2200 샤워헤드 교체 2건 ('SH-2200' 부분 문자열로 묶은 결과)")
print(H3)
print("-" * dw(H3))
sh_sorted = sorted(sh, key=lambda e: e["date"])
for e in sh_sorted:
    w = results[(e["chamber"], e["date"], e["event_type"])]
    print(padr(str(e["date"]), 11) + padr(e["chamber"], 8) + padl(w["n_b"], 5) + padl(w["n_a"], 5)
          + padl("%.3f" % w["mb"], 9) + padl("%.3f" % w["ma"], 9)
          + padl("%+.3f" % w["delta"], 9) + padl(f2(w["t"]), 9)
          + padl(f4(w["pb"]), 8) + padl(f4(w["pa"]), 8) + padl("%+.4f" % w["dp"], 10))
print("-" * dw(H3))
print("detail 표기: " + " | ".join("%s %s='%s'" % (e["date"], e["chamber"], e["detail"]) for e in sh_sorted))
print()
print("28일 창(당일 제외, 데이터 기간 안으로 잘림)으로 다시 본 같은 2건")
H4 = (padr("date", 11) + padr("chamber", 8) + padl("전일수", 7) + padl("후일수", 7)
      + padl("전28평균", 10) + padl("후28평균", 10) + padl("Δ28수율", 10)
      + padl("P_전28", 9) + padl("P_후28", 9) + padl("ΔP28", 10))
print(H4)
print("-" * dw(H4))
for e in sh_sorted:
    d, c = e["date"], e["chamber"]
    b1 = max(DATA_START, d - timedelta(days=28))
    a2 = min(DATA_END, d + timedelta(days=28))
    lb = lots(c, b1, d - timedelta(days=1))
    la = lots(c, d + timedelta(days=1), a2)
    nb_days = (d - timedelta(days=1) - b1).days + 1
    na_days = (a2 - (d + timedelta(days=1))).days + 1
    mb, ma = mean([x["yield_pct"] for x in lb]), mean([x["yield_pct"] for x in la])
    pb, pa = pratio(lb), pratio(la)
    print(padr(str(d), 11) + padr(c, 8) + padl(nb_days, 7) + padl(na_days, 7)
          + padl("%.3f" % mb, 10) + padl("%.3f" % ma, 10) + padl("%+.3f" % (ma - mb), 10)
          + padl("%.4f" % pb, 9) + padl("%.4f" % pa, 9) + padl("%+.4f" % (pa - pb), 10))
print("-" * dw(H4))
print("읽는 법: 같은 부품을 같은 방식으로 갈았는데 두 챔버의 Δ 가 같은 방향·같은 크기가 아니면,"
      " 부품 교체 자체를 하락의 원인으로 보기 어렵다.")
print()

print("(5c) CAL(파티클 계측기 교정) 2026-07-05")
cal_day = date(2026, 7, 5)
cal_ch = sorted(set(e["chamber"] for e in EQ if e["date"] == cal_day and e["event_type"] == "CAL"))
print("07-05 에 CAL 을 받은 챔버: %s  (%d개 / 전체 6개)  %s"
      % (", ".join(cal_ch), len(cal_ch), "여섯 챔버 전부가 같은 날 받았다" if len(cal_ch) == 6 else "일부만 받았다"))
other_cal = [e for e in EQ if e["event_type"] == "CAL" and e["date"] != cal_day]
print("07-05 이외의 CAL 이벤트: %d건" % len(other_cal))
print(H3)
print("-" * dw(H3))
cal_deltas = []
for c in cal_ch:
    w = results[(c, cal_day, "CAL")]
    cal_deltas.append((c, w["delta"], w["dp"]))
    print(padr(str(cal_day), 11) + padr(c, 8) + padl(w["n_b"], 5) + padl(w["n_a"], 5)
          + padl("%.3f" % w["mb"], 9) + padl("%.3f" % w["ma"], 9)
          + padl("%+.3f" % w["delta"], 9) + padl(f2(w["t"]), 9)
          + padl(f4(w["pb"]), 8) + padl(f4(w["pa"]), 8) + padl("%+.4f" % w["dp"], 10))
print("-" * dw(H3))
cds = [x[1] for x in cal_deltas]
cps = [x[2] for x in cal_deltas]
print("CAL 6건 Δ수율: 중앙값 %+.3f   최소 %+.3f   최대 %+.3f   평균 %+.3f   음수 %d건 / 양수 %d건"
      % (statistics.median(cds), min(cds), max(cds), mean(cds),
         sum(1 for x in cds if x < 0), sum(1 for x in cds if x > 0)))
print("CAL 6건 ΔP    : 중앙값 %+.4f   최소 %+.4f   최대 %+.4f   음수 %d건 / 양수 %d건"
      % (statistics.median(cps), min(cps), max(cps),
         sum(1 for x in cps if x < 0), sum(1 for x in cps if x > 0)))
print("읽는 법: 계측 눈금이 07-05 에 바뀐 것이라면 여섯 챔버가 같은 방향으로 함께 움직였을 자리다.")
print("  주의: 07-05 CH-3A 에는 CAL 과 CLEAN 이 같은 날 함께 있어 이 행의 Δ 는 두 이벤트가 섞인 값이다.")
print()

print("(5d) CH-3B 2026-08-10 특별 세정 (파티클 대응, 180분)")
sp = [e for e in EQ if e["chamber"] == "CH-3B" and e["date"] == date(2026, 8, 10)]
for e in sp:
    print("  이벤트 확인: %s %s %s '%s' %d분 worker=%s"
          % (e["date"], e["chamber"], e["event_type"], e["detail"], e["duration_min"], e["worker"]))
pre = lots("CH-3B", date(2026, 7, 29), date(2026, 8, 9))
post = lots("CH-3B", date(2026, 8, 11), date(2026, 8, 25))
ypre = [x["yield_pct"] for x in pre]
ypost = [x["yield_pct"] for x in post]
t_sp, df_sp = welch(ypre, ypost)
print("  구간 정의: 세정 전 = 07-29~08-09 (하락 이후~세정 직전), 세정 후 = 08-11~08-25. 세정 당일 08-10 은 제외.")
print("  Welch t 는 로트 단위 수율로 냈다 ([3]절과 같은 단위).")
H5 = (padr("구간", 18) + padl("일수", 6) + padl("로트수", 7) + padl("평균수율", 10)
      + padl("수율sd(ddof=1)", 15) + padl("P(정의 P)", 11))
print(H5)
print("-" * dw(H5))
print(padr("세정 전 07-29~08-09", 18) + padl(12, 6) + padl(len(pre), 7)
      + padl("%.3f" % mean(ypre), 10) + padl("%.4f" % sd(ypre, 1), 15) + padl("%.4f" % pratio(pre), 11))
print(padr("세정 후 08-11~08-25", 18) + padl(15, 6) + padl(len(post), 7)
      + padl("%.3f" % mean(ypost), 10) + padl("%.4f" % sd(ypost, 1), 15) + padl("%.4f" % pratio(post), 11))
print("-" * dw(H5))
print("  Δ수율 (후 - 전) = %+.3f %%p    Welch t = %.4f   df = %.2f" % (mean(ypost) - mean(ypre), t_sp, df_sp))
print("  ΔP (후 - 전)   = %+.4f" % (pratio(post) - pratio(pre)))
print("  기준선(07-01~07-24) 평균 수율 %.3f 과 견주면, 세정 후 평균은 기준선보다 %+.3f %%p 이다."
      % (mean(base_y), mean(ypost) - mean(base_y)))
print()

# ================================================================ [6]
sec(6, "07-28 겹침의 특이성")
combo = {}
for e in EQ:
    combo.setdefault((e["chamber"], e["date"]), []).append(e)

pm_part = sorted([k for k, v in combo.items()
                  if any(x["event_type"] == "PM" for x in v) and any(x["event_type"] == "PART" for x in v)],
                 key=lambda k: (k[1], k[0]))
print("-- PM 과 PART 가 같은 날 함께 있는 (챔버, 날) 조합 --")
for c, d in pm_part:
    tys = ",".join(sorted(x["event_type"] for x in combo[(c, d)]))
    dets = " | ".join(x["detail"] for x in combo[(c, d)])
    print("  %s %s  종류=%s  detail=%s" % (d, c, tys, dets))
if not pm_part:
    print("  (없음)")
print("  개수: %d" % len(pm_part))
print()

multi = sorted([k for k, v in combo.items() if len(v) >= 2], key=lambda k: (k[1], k[0]))
print("-- 이벤트가 2건 이상인 (챔버, 날) 조합 --")
H6 = padr("date", 11) + padr("chamber", 8) + padl("건수", 6) + "  " + padr("종류 목록", 20) + padr("detail 목록", 50)
print(H6)
print("-" * dw(H6))
for c, d in multi:
    v = sorted(combo[(c, d)], key=lambda x: x["event_type"])
    print(padr(str(d), 11) + padr(c, 8) + padl(len(v), 6) + "  "
          + padr(",".join(x["event_type"] for x in v), 20)
          + padr(" | ".join(x["detail"] for x in v), 50))
print("-" * dw(H6))
print("  개수: %d" % len(multi))
print()

print("-- 챔버별 총 이벤트 시간 (duration_min 합) --")
print(padr("chamber", 9) + padl("건수", 6) + padl("duration_min 합", 17))
print("-" * 32)
for c in CHAMBERS:
    es = [e for e in EQ if e["chamber"] == c]
    print(padr(c, 9) + padl(len(es), 6) + padl(sum(e["duration_min"] for e in es), 17))
print("-" * 32)
print(padr("합계", 9) + padl(len(EQ), 6) + padl(sum(e["duration_min"] for e in EQ), 17))
print()
d728 = [e for e in EQ if e["chamber"] == "CH-3B" and e["date"] == date(2026, 7, 28)]
print("2026-07-28 하루 CH-3B 의 duration 합: %d 분 (%d건: %s)"
      % (sum(e["duration_min"] for e in d728), len(d728),
         ", ".join("%s %d분" % (e["event_type"], e["duration_min"]) for e in d728)))
day_tot = {}
for e in EQ:
    day_tot[(e["chamber"], e["date"])] = day_tot.get((e["chamber"], e["date"]), 0) + e["duration_min"]
mx = max(day_tot.values())
print("  전체 (챔버,날) 조합 중 하루 duration 합 최대는 %d 분: %s"
      % (mx, ", ".join("%s %s" % (d, c) for (c, d), v in sorted(day_tot.items(), key=lambda kv: (kv[0][1], kv[0][0])) if v == mx)))
print()

# ================================================================ [7]
sec(7, "플라시보 분포 — 이벤트가 있는 날의 Δ 가 특별한가")
print("여섯 챔버 각각에 대해 전후 창이 완전히 확보되는 모든 날 D(07-08~08-18)에서 [3]절과 같은 방식으로"
      " Δ수율을 낸다(이벤트 유무와 무관). 당일 D 는 양쪽 창에서 제외한다.")
pl_days = [d for d in DAYS if date(2026, 7, 8) <= d <= date(2026, 8, 18)]
placebo = []   # (chamber, date, delta, has_event)
for c in CHAMBERS:
    for d in pl_days:
        b = lots(c, d - timedelta(days=WIN), d - timedelta(days=1))
        a = lots(c, d + timedelta(days=1), d + timedelta(days=WIN))
        dl = mean([x["yield_pct"] for x in a]) - mean([x["yield_pct"] for x in b])
        placebo.append((c, d, dl, (c, d) in EV_BY_CD))
print("표본 수: 챔버 %d × 날 %d = %d  (기대 252)  %s"
      % (len(CHAMBERS), len(pl_days), len(placebo), "일치" if len(placebo) == 252 else "불일치"))
pl_vals = sorted(x[2] for x in placebo)
print()
print(padr("통계", 12) + padl("Δ수율(%p)", 14))
print("-" * 26)
for lbl, v in [("최소", pl_vals[0]), ("5백분위", pct(pl_vals, 5)), ("25백분위", pct(pl_vals, 25)),
               ("50백분위", pct(pl_vals, 50)), ("75백분위", pct(pl_vals, 75)),
               ("95백분위", pct(pl_vals, 95)), ("최대", pl_vals[-1])]:
    print(padr(lbl, 12) + padl("%+.4f" % v, 14))
print("-" * 26)
print("평균 %+.4f   sd(ddof=1) %.4f" % (mean(pl_vals), sd(pl_vals, 1)))
print("(백분위는 선형보간 방식으로 냈다.)")
print()
target = [x for x in placebo if x[0] == "CH-3B" and x[1] == date(2026, 7, 28)]
tv = target[0][2]
rank = sum(1 for v in pl_vals if v < tv) + 1
le = sum(1 for v in pl_vals if v <= tv)
print("CH-3B 07-28 의 Δ수율 = %+.4f %%p" % tv)
print("  이 분포에서 작은 쪽부터 센 순위: %d / %d   (백분위 %.2f%%, 즉 이 값 이하가 전체의 %.2f%%)"
      % (rank, len(pl_vals), 100.0 * le / len(pl_vals), 100.0 * le / len(pl_vals)))
print("  더 작은(더 크게 떨어진) 값의 개수: %d" % (rank - 1))
if rank <= 3:
    print("  아래에서 %d번째 안에 드는 값들:" % min(5, len(pl_vals)))
    for c, d, v, he in sorted(placebo, key=lambda x: x[2])[:5]:
        print("    %s %s  Δ=%+.4f  이벤트 있는 날=%s" % (d, c, v, "예" if he else "아니오"))
print()
ev_d = [x[2] for x in placebo if x[3]]
no_d = [x[2] for x in placebo if not x[3]]
t_pl, df_pl = welch(no_d, ev_d)
print("-- 이벤트가 있는 날 vs 없는 날 --")
H7 = padr("집합", 22) + padl("n", 6) + padl("평균Δ", 11) + padl("중앙값Δ", 11) + padl("sd(ddof=1)", 12)
print(H7)
print("-" * dw(H7))
print(padr("이벤트 있는 날", 22) + padl(len(ev_d), 6) + padl("%+.4f" % mean(ev_d), 11)
      + padl("%+.4f" % statistics.median(ev_d), 11) + padl("%.4f" % sd(ev_d, 1), 12))
print(padr("이벤트 없는 날", 22) + padl(len(no_d), 6) + padl("%+.4f" % mean(no_d), 11)
      + padl("%+.4f" % statistics.median(no_d), 11) + padl("%.4f" % sd(no_d, 1), 12))
print("-" * dw(H7))
print("Welch t = %.4f   df = %.2f   (부호: 이벤트 있는 날 평균 - 이벤트 없는 날 평균 방향)" % (t_pl, df_pl))
print("평균 차이 (있는 날 - 없는 날) = %+.4f %%p" % (mean(ev_d) - mean(no_d)))
print()

# ================================================================ [8]
sec(8, "변화점 재현 (seed 고정)")
print("방법: 챔버의 일평균 수율 56점에서 앞뒤 최소 7일을 남기고 자를 수 있는 모든 날을 시험해"
      " |Welch t| 가 최대인 날을 고른다. 변화점 날짜 = 뒤 구간의 첫날.")
print("p 값: 값 순서를 %d번 섞어(seed %d) 같은 방식으로 매번 최대 |t| 를 다시 찾고,"
      " p = (섞은 것 중 실제 |t| 이상인 개수 + 1) / %d." % (2000, SEED, 2001))
print("모든 분산은 ddof=1. 누적합·누적제곱합으로 각 분할의 평균·분산을 O(1)에 낸다(수식은 같다).")
print()

MIN_SIDE = 7
N_PERM = 2000
SPLITS = list(range(MIN_SIDE, len(DAYS) - MIN_SIDE + 1))


def best_split(vals):
    n = len(vals)
    S = [0.0] * (n + 1)
    Q = [0.0] * (n + 1)
    for i, v in enumerate(vals):
        S[i + 1] = S[i] + v
        Q[i + 1] = Q[i] + v * v
    best_i, best_t = None, -1.0
    for i in SPLITS:
        t = welch_from_sums(S[i], Q[i], i, S[n] - S[i], Q[n] - Q[i], n - i)
        if t is None:
            continue
        if abs(t) > best_t:
            best_t, best_i = abs(t), i
    if best_i is None:
        return None, None, None
    n1 = best_i
    t_signed = welch_from_sums(S[n1], Q[n1], n1, S[n] - S[n1], Q[n] - Q[n1], n - n1)
    return best_i, t_signed, best_t


def max_abs_t(vals):
    n = len(vals)
    S = [0.0] * (n + 1)
    Q = [0.0] * (n + 1)
    for i, v in enumerate(vals):
        S[i + 1] = S[i] + v
        Q[i + 1] = Q[i] + v * v
    m = -1.0
    for i in SPLITS:
        t = welch_from_sums(S[i], Q[i], i, S[n] - S[i], Q[n] - Q[i], n - i)
        if t is not None and abs(t) > m:
            m = abs(t)
    return m


random.seed(SEED)
print("random.seed(%d) 를 순열검정 직전에 한 번 걸고, 챔버를 %s 순서로 돌린다 (결정적)."
      % (SEED, " -> ".join(CHAMBERS)))
print()
cp_rows = []
for c in CHAMBERS:
    vals = daily_yield(c)
    idx, t_s, t_a = best_split(vals)
    cp_date = DAYS[idx]
    work = list(vals)
    ge = 0
    for _ in range(N_PERM):
        random.shuffle(work)
        if max_abs_t(work) >= t_a - 1e-12:
            ge += 1
    p = (ge + 1) / (N_PERM + 1)
    cp_rows.append((c, cp_date, idx, len(vals) - idx, t_s, t_a, ge, p))

H8 = (padr("chamber", 9) + padr("변화점", 12) + padl("앞n", 5) + padl("뒤n", 5)
      + padl("Welch t", 11) + padl("|t|", 10) + padl("섞은것>=실제", 14) + padl("p", 10))
print(H8)
print("-" * dw(H8))
for c, cd, n1, n2, t_s, t_a, ge, p in cp_rows:
    print(padr(c, 9) + padr(str(cd), 12) + padl(n1, 5) + padl(n2, 5)
          + padl("%.4f" % t_s, 11) + padl("%.4f" % t_a, 10) + padl(ge, 14) + padl("%.4f" % p, 10))
print("-" * dw(H8))
print()
r3b = [r for r in cp_rows if r[0] == "CH-3B"][0]
print("CH-3B 변화점: %s   t = %.4f   p = %.4f" % (r3b[1], r3b[4], r3b[7]))
print("  앞선 분석이 적은 값: 2026-07-29 / p = 0.0005")
print("  날짜 대조: %s" % ("일치" if r3b[1] == DROP_DAY else "불일치 (이번 %s)" % r3b[1]))
print("  p 대조: %s (이번 p = %.4f (정확히 %d/%d = %.6f), 앞선 값 0.0005 — 소수 넷째 자리까지 비교)"
      % ("일치" if round(r3b[7], 4) == 0.0005 else "불일치", r3b[7], r3b[6] + 1, N_PERM + 1, r3b[7]))
print("  p 의 하한: 섞은 것 중 실제 이상이 0개일 때 p = 1/%d = %.6f 이므로 이보다 작은 p 는 이 방법으로 나올 수 없다."
      % (N_PERM + 1, 1.0 / (N_PERM + 1)))
print()

# ================================================================ [9]
sec(9, "요약 수치 모음 — 문서에 인용할 값")
print("(1) 07-29 계단 하락 — CH-3B 일평균 수율, 07-01~07-28 (28일) 대 07-29~08-25 (28일)")
print("    전 평균 %.4f %%  →  후 평균 %.4f %%   Δ = %+.4f %%p   Welch t = %.4f (ddof=1)"
      % (mean(seg_b), mean(seg_a), mean(seg_a) - mean(seg_b), t_28))
print()
print("(2) CH-3B 07-28 PM+PART (같은 날 겹침, 전후 7일 창)")
print("    Δ수율 %+.3f %%p   Welch t %.4f   ΔP %+.4f   (전 %.3f → 후 %.3f)"
      % (b3["delta"], b3["t"], b3["dp"], b3["mb"], b3["ma"]))
print("    PM 과 PART 의 창이 같으므로 두 행의 Δ 는 같은 값이다.")
print()
print("(3) CH-3A 07-28 PM (같은 날 PM 을 받은 대조군)")
print("    Δ수율 %+.3f %%p   Welch t %.4f   ΔP %+.4f   (전 %.3f → 후 %.3f)"
      % (a3["delta"], a3["t"], a3["dp"], a3["mb"], a3["ma"]))
print()
w2b = results[("CH-2B", date(2026, 8, 6), "PART")]
print("(4) CH-2B 08-06 SH-2200 샤워헤드 교체 (같은 부품 대조군)")
print("    Δ수율 %+.3f %%p   Welch t %.4f   ΔP %+.4f   (전 %.3f → 후 %.3f)"
      % (w2b["delta"], w2b["t"], w2b["dp"], w2b["mb"], w2b["ma"]))
print()
print("(5) 07-05 CAL 여섯 챔버 Δ수율 목록")
print("    " + "   ".join("%s %+.3f" % (c, d) for c, d, _ in cal_deltas))
print("    중앙값 %+.3f   최소 %+.3f   최대 %+.3f   (음수 %d / 양수 %d)"
      % (statistics.median(cds), min(cds), max(cds),
         sum(1 for x in cds if x < 0), sum(1 for x in cds if x > 0)))
print("    ΔP 목록: " + "   ".join("%s %+.4f" % (c, p) for c, _, p in cal_deltas))
print()
print("(6) CH-3B 08-10 특별 세정 전후")
print("    세정 전 07-29~08-09 평균 수율 %.3f %% (P %.4f)  →  세정 후 08-11~08-25 평균 수율 %.3f %% (P %.4f)"
      % (mean(ypre), pratio(pre), mean(ypost), pratio(post)))
print("    Δ수율 %+.3f %%p   Welch t %.4f   ΔP %+.4f"
      % (mean(ypost) - mean(ypre), t_sp, pratio(post) - pratio(pre)))
print("    기준선(07-01~07-24) 평균 %.3f %% 대비 세정 후 %+.3f %%p" % (mean(base_y), mean(ypost) - mean(base_y)))
print()
print("(7) 겹침 개수")
print("    PM 과 PART 가 같은 날 함께 있는 (챔버,날) 조합: %d개  %s"
      % (len(pm_part), " / ".join("%s %s" % (d, c) for c, d in pm_part)))
print("    이벤트가 2건 이상인 (챔버,날) 조합: %d개" % len(multi))
print()
print("(8) 플라시보 분포에서 CH-3B 07-28 의 자리")
print("    Δ = %+.4f %%p   순위 %d / %d (작은 쪽부터)   백분위 %.2f%%"
      % (tv, rank, len(pl_vals), 100.0 * le / len(pl_vals)))
print("    분포 5백분위 %+.4f · 중앙값 %+.4f · 95백분위 %+.4f" % (pct(pl_vals, 5), pct(pl_vals, 50), pct(pl_vals, 95)))
print()
print("(9) 변화점 검정 (seed %d, 2000회 순열)" % SEED)
for c, cd, n1, n2, t_s, t_a, ge, p in cp_rows:
    print("    %-7s 변화점 %s   t %9.4f   p %.4f" % (c, cd, t_s, p))
print()
# ================================================================ [10]
sec(10, "창 길이를 바꿔 가며 다시 재기 — 07-20 정기 세정이 후보인가")
print("창 규칙(이 절에만 적용): 전 창 = D-W~D-1, 후 창 = D+1~D+W, 이벤트 당일 D 는 양쪽 창에서 제외한다."
      " 창부족 판정은 [3]절의 8로트 문턱을 쓰지 않는다 — W 가 작으면 창을 다 채워도 8로트에 못 미치기 때문이다."
      " 대신 전 창과 후 창이 각각 2W 로트(W일 × 하루 2로트)를 데이터 기간 07-01~08-25 안에서 온전히 채웠는가로"
      " 정하고, 한쪽이라도 잘리면 창부족으로 둔다.")
print("Δ수율 = 후 평균 - 전 평균 (%p). 순위는 그 W 에서 통계를 낸 이벤트들 중"
      " 작은 쪽(크게 떨어진 쪽)부터 센다. 같은 값이 여럿이면 같은 순위를 준다(자기보다 작은 값의 개수 + 1).")
print()

WS10 = [3, 5, 7, 10, 14, 21]


def win_w(chamber, d, W):
    """창 길이 W 의 전후 창 통계. 당일 제외. 양쪽 창이 2W 로트를 다 채워야 통계를 낸다."""
    b = lots(chamber, d - timedelta(days=W), d - timedelta(days=1))
    a = lots(chamber, d + timedelta(days=1), d + timedelta(days=W))
    ok = (len(b) >= 2 * W) and (len(a) >= 2 * W)
    if not ok:
        return {"ok": False, "n_b": len(b), "n_a": len(a), "mb": None, "ma": None, "delta": None}
    yb = [x["yield_pct"] for x in b]
    ya = [x["yield_pct"] for x in a]
    return {"ok": True, "n_b": len(b), "n_a": len(a),
            "mb": mean(yb), "ma": mean(ya), "delta": mean(ya) - mean(yb)}


# 이벤트 한 건이 한 항목이다([3]절과 같은 단위). (챔버,날,종류) 가 겹치는 건이 있어도 따로 센다.
EV_IX = sorted(range(len(EQ)),
               key=lambda i: (EQ[i]["date"], EQ[i]["chamber"], EQ[i]["event_type"], EQ[i]["detail"]))
n_keys = len(set((EQ[i]["chamber"], EQ[i]["date"], EQ[i]["event_type"]) for i in EV_IX))
print("이 절이 도는 이벤트 건수: %d (기대 48)  %s   서로 다른 (챔버,날,종류) 키 개수: %d"
      % (len(EV_IX), "일치" if len(EV_IX) == 48 else "불일치", n_keys))
if n_keys != len(EV_IX):
    dup = {}
    for i in EV_IX:
        dup.setdefault((EQ[i]["chamber"], EQ[i]["date"], EQ[i]["event_type"]), []).append(i)
    for k, v in sorted(dup.items(), key=lambda kv: (kv[0][1], kv[0][0])):
        if len(v) > 1:
            print("  같은 (챔버,날,종류) 가 %d건인 자리: %s %s %s  detail=%s"
                  % (len(v), k[1], k[0], k[2], " | ".join(EQ[i]["detail"] for i in v)))
print()

W_VALS = {}    # W -> {이벤트 index: win_w 결과}
W_OK = {}      # W -> 통계를 낸 Δ 목록(정렬)
for W in WS10:
    vv = {}
    for i in EV_IX:
        vv[i] = win_w(EQ[i]["chamber"], EQ[i]["date"], W)
    W_VALS[W] = vv
    W_OK[W] = sorted(v["delta"] for v in vv.values() if v["ok"])


def rank10(W, i):
    """작은 쪽부터 센 순위. 통계를 내지 못했으면 None."""
    v = W_VALS[W][i]
    if not v["ok"]:
        return None
    return sum(1 for x in W_OK[W] if x < v["delta"]) + 1


def cell10(W, i):
    v = W_VALS[W][i]
    if not v["ok"]:
        return "창부족"
    return "%+.3f %d/%d" % (v["delta"], rank10(W, i), len(W_OK[W]))


def find_ev(c, d, ty):
    for i in EV_IX:
        if EQ[i]["chamber"] == c and EQ[i]["date"] == d and EQ[i]["event_type"] == ty:
            return i
    return None


def ev_label(i):
    return "%s %s %s" % (EQ[i]["date"], EQ[i]["chamber"], EQ[i]["event_type"])


FOCUS10 = [find_ev("CH-3B", date(2026, 7, 6), "CLEAN"),
           find_ev("CH-3B", date(2026, 7, 20), "CLEAN"),
           find_ev("CH-3B", date(2026, 7, 28), "PART"),
           find_ev("CH-3B", date(2026, 7, 28), "PM"),
           find_ev("CH-3B", date(2026, 8, 3), "CLEAN")]

print("(10a) 창 길이별 Δ수율 표 — 칸은 'Δ수율(%p)  순위/그 W 에서 통계를 낸 건수'")
H10 = padr("이벤트", 26) + "".join(padl("W=%d" % W, 15) for W in WS10)
print(H10)
print("-" * dw(H10))
for i in FOCUS10:
    print(padr(ev_label(i), 26) + "".join(padl(cell10(W, i), 15) for W in WS10))
print("-" * dw(H10))
for i in FOCUS10:
    print("  %s  detail='%s'  dur %d분" % (ev_label(i), EQ[i]["detail"], EQ[i]["duration_min"]))
print()

print("(10b) W 마다 한 줄 요약")
EXCL10 = set(i for i in EV_IX
             if EQ[i]["chamber"] == "CH-3B" and EQ[i]["date"] in (date(2026, 7, 28), date(2026, 8, 3)))
print("     제외 집합(아래 '나머지 중 |Δ| 최대'에서 뺀 이벤트 %d건): " % len(EXCL10)
      + " / ".join(ev_label(i) for i in sorted(EXCL10, key=lambda i: (EQ[i]["date"], EQ[i]["event_type"]))))
print()
for W in WS10:
    okk = [i for i in EV_IX if W_VALS[W][i]["ok"]]
    print("W=%-2d  통계를 낸 건수 %d / %d  (창부족 %d)"
          % (W, len(okk), len(EV_IX), len(EV_IX) - len(okk)))
    low3 = sorted(okk, key=lambda i: (W_VALS[W][i]["delta"], EQ[i]["date"], EQ[i]["chamber"]))[:3]
    if low3:
        print("      Δ 최소 3건: " + "   ".join(
            padr("%s %+.3f" % (ev_label(i), W_VALS[W][i]["delta"]), 32) for i in low3).rstrip())
    else:
        print("      Δ 최소 3건: (통계를 낸 건이 없다)")
    rest = [i for i in okk if i not in EXCL10]
    if rest:
        im = max(rest, key=lambda i: (abs(W_VALS[W][i]["delta"]), EQ[i]["date"], EQ[i]["chamber"]))
        av = abs(W_VALS[W][im]["delta"])
        print("      07-28 두 건과 08-03 CH-3B 를 뺀 나머지 %d건 중 |Δ| 최대: %s  Δ %+.3f  |Δ| %.3f  → 1%%p %s"
              % (len(rest), ev_label(im), W_VALS[W][im]["delta"], av, "넘음" if av > 1.0 else "안 넘음"))
    else:
        print("      07-28 두 건과 08-03 CH-3B 를 뺀 나머지: 통계를 낸 건이 없다 → n/a")
print()

print("(10c) 07-20 의 후 창이 하락일 2026-07-29 를 삼키는가")
print("     후 창 = D+1 ~ D+W (당일 제외). '창 상태'는 (10a)와 같은 규칙의 판정이다.")


def afterwin_table(i):
    d = EQ[i]["date"]
    H = (padr("W", 5) + padr("후 창 첫날", 13) + padr("후 창 끝날", 13)
         + padr("2026-07-29", 12) + padr("창 상태", 10))
    print("  -- %s --" % ev_label(i))
    print("  " + H)
    print("  " + "-" * dw(H))
    for W in WS10:
        a1 = d + timedelta(days=1)
        a2 = d + timedelta(days=W)
        inc = "포함" if a1 <= DROP_DAY <= a2 else "미포함"
        st = "통계" if W_VALS[W][i]["ok"] else "창부족"
        print("  " + padr(W, 5) + padr(str(a1), 13) + padr(str(a2), 13)
              + padr(inc, 12) + padr(st, 10))
    print("  " + "-" * dw(H))


i720 = find_ev("CH-3B", date(2026, 7, 20), "CLEAN")
afterwin_table(i720)
mins = [W for W in WS10 if date(2026, 7, 21) <= DROP_DAY <= date(2026, 7, 20) + timedelta(days=W)]
print("  07-20 의 후 창이 07-29 를 처음 삼키는 W: %s"
      % (("W=%d" % min(mins)) if mins else "없음(여섯 W 모두 미포함)"))
print()
afterwin_table(find_ev("CH-3B", date(2026, 7, 28), "PART"))
afterwin_table(find_ev("CH-3B", date(2026, 7, 28), "PM"))
print("  07-28 은 후 창 첫날이 곧 07-29 이므로 여섯 W 모두 하락일을 포함한다.")
print()

print("(10d) 07-20 세정 뒤 하락 전 8일(07-21~07-28)이 기준선 범위 안이었는가 — CH-3B")
print("     기준선 = 07-01~07-24 (24일, [1]절과 같은 구간). 평균과 표본표준편차(ddof=1)로 문턱을 낸다."
      " 수율은 아래쪽(-2sd·-3sd), 파티클 비율(정의 P)은 위쪽(+2sd·+3sd)이 이상 방향이다.")
seg8_days = list(daterange(date(2026, 7, 21), date(2026, 7, 28)))
seg8_y = [mean([x["yield_pct"] for x in BY_CD[("CH-3B", d)]]) for d in seg8_days]
seg8_p = [pratio(BY_CD[("CH-3B", d)]) for d in seg8_days]
by_m, by_s = mean(base_y), sd(base_y, 1)
bp_m, bp_s = mean(base_p), sd(base_p, 1)
y_t2, y_t3 = by_m - 2 * by_s, by_m - 3 * by_s
p_t2, p_t3 = bp_m + 2 * bp_s, bp_m + 3 * bp_s
H10d = (padr("date", 12) + padl("로트수", 7) + padl("일평균수율", 12) + padl("-2sd 아래", 11)
        + padl("-3sd 아래", 11) + padl("파티클비율P", 13) + padl("+2sd 위", 10) + padl("+3sd 위", 10))
print(H10d)
print("-" * dw(H10d))
for d, yv, pv in zip(seg8_days, seg8_y, seg8_p):
    print(padr(str(d), 12) + padl(len(BY_CD[("CH-3B", d)]), 7) + padl("%.3f" % yv, 12)
          + padl("예" if yv < y_t2 else "아니오", 11)
          + padl("예" if yv < y_t3 else "아니오", 11)
          + padl("%.4f" % pv, 13)
          + padl("예" if pv > p_t2 else "아니오", 10)
          + padl("예" if pv > p_t3 else "아니오", 10))
print("-" * dw(H10d))
n8 = sum(len(BY_CD[("CH-3B", d)]) for d in seg8_days)
print("  인쇄한 날 수 %d (기대 8) · 로트 수 합계 %d (기대 16)  %s"
      % (len(seg8_days), n8, "일치" if (len(seg8_days) == 8 and n8 == 16) else "불일치"))
print()
ylo2 = sum(1 for v in seg8_y if v < y_t2)
ylo3 = sum(1 for v in seg8_y if v < y_t3)
phi2 = sum(1 for v in seg8_p if v > p_t2)
phi3 = sum(1 for v in seg8_p if v > p_t3)
print("  수율      : 8일 평균 %.4f %%   기준선 평균 %.4f %%   기준선 sd(ddof=1) %.4f"
      % (mean(seg8_y), by_m, by_s))
print("              문턱 -2sd = %.4f · -3sd = %.4f   →  -2sd 아래인 날 %d개 / -3sd 아래인 날 %d개 (8일 중)"
      % (y_t2, y_t3, ylo2, ylo3))
print("              8일 최소 %.4f · 최대 %.4f · 기준선 평균과의 차 %+.4f %%p"
      % (min(seg8_y), max(seg8_y), mean(seg8_y) - by_m))
print("  파티클비율: 8일 평균 %.4f   기준선 평균 %.4f   기준선 sd(ddof=1) %.4f"
      % (mean(seg8_p), bp_m, bp_s))
print("              문턱 +2sd = %.4f · +3sd = %.4f   →  +2sd 위인 날 %d개 / +3sd 위인 날 %d개 (8일 중)"
      % (p_t2, p_t3, phi2, phi3))
print("              8일 최소 %.4f · 최대 %.4f · 기준선 평균과의 차 %+.4f"
      % (min(seg8_p), max(seg8_p), mean(seg8_p) - bp_m))
y_out = [d for d, v in zip(seg8_days, seg8_y) if v < y_t2]
p_out = [d for d, v in zip(seg8_days, seg8_p) if v > p_t2]
print("              문턱을 벗어난 날: 수율 %s   파티클 비율 %s"
      % (", ".join(str(d) for d in y_out) if y_out else "없음",
         ", ".join(str(d) for d in p_out) if p_out else "없음"))
print("  판정: 07-21~07-28 여덟 날 중 수율이 기준선 -2sd 아래인 날은 %d개, 파티클 비율이 +2sd 위인 날은 %d개다."
      % (ylo2, phi2))
pre27 = [d for d in p_out if d < date(2026, 7, 28)] + [d for d in y_out if d < date(2026, 7, 28)]
print("        07-28(PM+PART 당일)을 뺀 07-21~07-27 이레만 보면 문턱을 벗어난 날은 %d개다 — %s."
      % (len(pre27),
         "07-20 세정 뒤 하락 전 구간은 기준선 범위 안에 있었다"
         if len(pre27) == 0 else "07-20 세정 뒤에도 벗어난 날이 있다"))
print()

print("(10e) 07-06 CH-3B CLEAN 을 같은 잣대로 (W=3)")
i706 = find_ev("CH-3B", date(2026, 7, 6), "CLEAN")
v706 = W_VALS[3][i706]
if v706["ok"]:
    print("  W=3: Δ수율 %+.3f %%p   순위 %d / %d (작은 쪽부터)   전 평균 %.3f → 후 평균 %.3f   n_전 %d · n_후 %d"
          % (v706["delta"], rank10(3, i706), len(W_OK[3]), v706["mb"], v706["ma"], v706["n_b"], v706["n_a"]))
else:
    print("  W=3: 창부족 (n_전 %d · n_후 %d)" % (v706["n_b"], v706["n_a"]))
a1_706 = date(2026, 7, 6) + timedelta(days=1)
a2_706 = date(2026, 7, 6) + timedelta(days=3)
print("  W=3 후 창 날짜 범위: %s ~ %s   (2026-07-29 %s)"
      % (a1_706, a2_706, "포함" if a1_706 <= DROP_DAY <= a2_706 else "미포함"))
print()

print("(10f) (챔버,날) 조합 세기 — 분모를 바로잡는다")
tot_cd = len(CHAMBERS) * len(DAYS)
ev_cd = len(day_tot)
print("  전체 (챔버,날) 조합: %d개  (챔버 %d × 날 %d)" % (tot_cd, len(CHAMBERS), len(DAYS)))
print("  그중 이벤트가 하나라도 있는 조합: %d개  (전체의 %.2f%%)" % (ev_cd, 100.0 * ev_cd / tot_cd))
dur_vals = sorted(day_tot.values(), reverse=True)
print("  이벤트가 있는 조합만 놓고 본 하루 duration 합: 최대 %d분 · 중앙값 %.1f분 · 최소 %d분"
      % (dur_vals[0], statistics.median(dur_vals), dur_vals[-1]))
v728 = day_tot[("CH-3B", date(2026, 7, 28))]
rank728 = sum(1 for v in dur_vals if v > v728) + 1
tie728 = sum(1 for v in dur_vals if v == v728)
print("  2026-07-28 CH-3B 의 하루 duration 합 %d분: 큰 쪽부터 센 순위 %d / %d  (같은 값 %d개)"
      % (v728, rank728, ev_cd, tie728))
print("  PM 과 PART 가 같은 날 함께 있는 조합: %d개 — 분모를 전체 %d개로 잡으면 %.2f%% 이지만,"
      " 이벤트가 있는 조합 %d개로 잡으면 %.2f%% 다."
      % (len(pm_part), tot_cd, 100.0 * len(pm_part) / tot_cd, ev_cd, 100.0 * len(pm_part) / ev_cd))
print("  이벤트가 2건 이상인 조합: %d개 — 이벤트가 있는 조합 %d개의 %.2f%%"
      % (len(multi), ev_cd, 100.0 * len(multi) / ev_cd))
print()

print("(10g) 크기 비교 — 07-28 CH-3B 의 낙폭은 CH-3B 밖 최대 낙폭의 몇 배인가 (W=7, [3]절 값)")
out3b = [(k, v) for k, v in results.items() if v["ok"] and k[0] != "CH-3B"]
kmin, vmin = min(out3b, key=lambda kv: kv[1]["delta"])
print("  CH-3B 밖에서 Δ 가 가장 작은 이벤트: %s %s %s  Δ %+.3f %%p  (통계를 낸 CH-3B 밖 이벤트 %d건 중)"
      % (kmin[1], kmin[0], kmin[2], vmin["delta"], len(out3b)))
d728v = results[("CH-3B", date(2026, 7, 28), "PM")]["delta"]
print("  07-28 CH-3B 의 Δ: %+.3f %%p" % d728v)
print("  나눈 값(반올림 없이 전체 자리수로): %.4f 배   그 역수: %.4f — 즉 CH-3B 밖 최대 낙폭은 07-28 낙폭의 %.4f 배다."
      % (d728v / vmin["delta"], vmin["delta"] / d728v, vmin["delta"] / d728v))
print("  나눈 값(반올림한 표시값 -3.351 / -0.499 로): %.4f 배   그 역수: %.4f"
      % (3.351 / 0.499, 0.499 / 3.351))
print()
print("읽는 법: 07-20 정기 세정의 Δ 는 후 창이 07-29 를 삼키기 전(W=3·5·7)에는 크지 않고,"
      " 삼킨 뒤(W=10·14)에야 커진다 — 커진 값은 세정이 아니라 07-29 하락을 담은 것이다."
      " (10d)에서 07-21~07-27 이레는 수율도 파티클 비율도 기준선 문턱 안이고,"
      " 문턱을 벗어난 것은 07-28(PM+PART 당일) 하루의 파티클 비율뿐이다 — 07-20 뒤 서서히 나빠진 흔적이 없다.")
print()
print("=" * 100)
print("로그 끝. 이 스크립트는 결정적이다 — 난수는 seed %d 로 고정했고 시각·경로 난수를 인쇄하지 않는다." % SEED)
print("=" * 100)
