#!/usr/bin/env python3
# task-22: 08-27 샤워헤드 교체 앞뒤 수율 · 부품 재측정 · 부록 자료 검사
# 출력은 그대로 analyst/task-22-evidence.log 로 간다. 난수는 순열검정에만 쓰고 씨앗을 고정한다.
import csv, io, math, random, statistics as st
from collections import Counter, defaultdict

ROOM = "<작업판>/rooms/수율개선-2026q3"
YIELD_MAIN = ROOM + "/archivist/inbox/2026-09-08-yield-by-lot/44cdd855-be6e-4b66-a014-e7eb3a056769-yield_by_lot.csv"
YIELD_ADD = ROOM + "/archivist/inbox/2026-09-09-yield-by-lot-addendum/fee7dd34-07cb-47a1-ab27-cb68fd3b59b5-yield_by_lot_addendum.csv"
EQ_MAIN = ROOM + "/archivist/inbox/2026-09-08-equipment-history/423efc74-8819-445a-bb81-90ca388034fd-equipment_history.csv"
EQ_ADD = ROOM + "/archivist/inbox/2026-09-09-equipment-history-addendum/0712fc84-e908-4582-992b-63aebebca36d-equipment_history_addendum.csv"
REMEAS = ROOM + "/archivist/inbox/2026-09-09-part-remeasure/521f2858-a080-4f86-b6a2-e5baf2b00d33-part_remeasure.csv"
INSPECT = ROOM + "/archivist/inbox/2026-09-09-part-incoming-inspection/28d181e9-647f-4b69-8fe7-554982ecd8de-part_incoming_inspection.csv"

def head(t):
    print("\n" + "=" * 116)
    print(t)
    print("=" * 116)

def sub(t):
    print("\n" + t)
    print("-" * 116)

def rows(path):
    raw = open(path, "rb").read()
    text = raw.decode("utf-8")
    rdr = csv.reader(io.StringIO(text, newline=""))
    all_rows = [r for r in rdr]
    return raw, all_rows[0], all_rows[1:]

def norm_date(d):
    return d.replace("/", "-")

def welch(a, b):
    # a 뒤 - b 앞 이 아니라 (a, b) 그대로. t 와 자유도만 낸다.
    na, nb = len(a), len(b)
    if na < 2 or nb < 2:
        return float("nan"), float("nan")
    ma, mb = st.fmean(a), st.fmean(b)
    va, vb = st.variance(a), st.variance(b)
    se2 = va / na + vb / nb
    if se2 == 0:
        return float("nan"), float("nan")
    t = (ma - mb) / math.sqrt(se2)
    df = se2 ** 2 / ((va / na) ** 2 / (na - 1) + (vb / nb) ** 2 / (nb - 1))
    return t, df

# ==================================================================================================
head("[1] 부록 109행 자료 검사 — 중복 · 결측 · 키 유일성 (archivist 사이드카와 따로 내가 센다)")

raw_add, hdr_add, add = rows(YIELD_ADD)
raw_main, hdr_main, main = rows(YIELD_MAIN)

sub("1-1 파일 모양")
print(f"  머리글 열: {hdr_add}")
print(f"  데이터 행 수: {len(add)}  (앞 원본 {len(main)}행)")
crlf = raw_add.count(bytes([13, 10]))
nlines = raw_add.decode().rstrip(chr(10)).count(chr(10)) + 1
print(f"  줄끝 CRLF 인 줄 수: {crlf} / 전체 줄 {nlines}")
fw = Counter(len(r) for r in add)
print(f"  행마다의 필드 수 분포: {dict(fw)}")

sub("1-2 중복 — 일곱 칸이 모두 같은 행")
cnt_full = Counter(tuple(r) for r in add)
dups_full = {k: v for k, v in cnt_full.items() if v > 1}
print(f"  완전히 같은 행이 있는 짝: {len(dups_full)}쌍")
for k, v in dups_full.items():
    idxs = [i + 1 for i, r in enumerate(add) if tuple(r) == k]
    print(f"    {v}회: {','.join(k)}   (데이터 행 {idxs})")

sub("1-3 키 유일성 — lot_id")
cnt_lot = Counter(r[0] for r in add)
dup_lot = {k: v for k, v in cnt_lot.items() if v > 1}
print(f"  서로 다른 lot_id: {len(cnt_lot)} / 데이터 행 {len(add)}")
print(f"  두 번 이상 나온 lot_id: {dup_lot if dup_lot else '없음'}")
main_ids = set(r[0] for r in main)
print(f"  앞 원본과 겹치는 lot_id: {len(main_ids & set(cnt_lot))}개")
print(f"  lot_id 범위: {min(cnt_lot)} ~ {max(cnt_lot)}")

sub("1-4 결측 — 빈 칸")
blank = defaultdict(list)
for i, r in enumerate(add):
    for j, v in enumerate(r):
        if v.strip() == "":
            blank[hdr_add[j]].append(i + 1)
print(f"  빈 칸이 있는 열: {dict(blank) if blank else '없음'}")
for col, idxs in blank.items():
    for i in idxs:
        print(f"    데이터 {i}행 전체: {','.join(add[i - 1])}")

sub("1-5 값의 모양이 다른 행")
odd_date = [(i + 1, r[1]) for i, r in enumerate(add) if "/" in r[1]]
odd_cham = [(i + 1, r[3]) for i, r in enumerate(add) if r[3] != r[3].upper()]
print(f"  date 구분자가 '/' 인 행: {odd_date if odd_date else '없음'}")
print(f"  chamber 가 대문자가 아닌 행: {odd_cham if odd_cham else '없음'}")
print(f"  chamber 값(적힌 그대로): {dict(Counter(r[3] for r in add))}")
print(f"  chamber 값(대문자로 맞춰): {dict(Counter(r[3].upper() for r in add))}")
print(f"  date 값(구분자 맞춰) 서로 다른 날: {len(set(norm_date(r[1]) for r in add))} · {sorted(set(norm_date(r[1]) for r in add))}")

sub("1-6 값의 범위와 산수 검사")
ys = [float(r[4]) for r in add]
ds = [int(r[5]) for r in add]
ps = [int(r[6]) for r in add if r[6].strip() != ""]
print(f"  yield_pct  최소 {min(ys):.2f} · 최대 {max(ys):.2f}")
print(f"  defect_count  최소 {min(ds)} · 최대 {max(ds)}")
print(f"  particle_defects  최소 {min(ps)} · 최대 {max(ps)} (값이 있는 행 {len(ps)})")
bad = [(i + 1, r[5], r[6]) for i, r in enumerate(add) if r[6].strip() != "" and int(r[6]) > int(r[5])]
print(f"  particle_defects 가 defect_count 보다 큰 행: {bad if bad else '없음'}")
bad_line = [(i + 1, r[2], r[3]) for i, r in enumerate(add) if r[3].upper()[3] != r[2]]
print(f"  line 숫자와 chamber 이름의 앞자리가 어긋난 행: {bad_line if bad_line else '없음'}")

sub("1-7 챔버·날짜 격자 (대문자로 맞춘 뒤)")
grid = Counter((norm_date(r[1]), r[3].upper()) for r in add)
days = sorted(set(d for d, _ in grid))
chs = sorted(set(c for _, c in grid))
print("  날짜      " + "  ".join(chs))
for d in days:
    print(f"  {d}  " + "     ".join(str(grid.get((d, c), 0)) for c in chs))
print(f"  칸마다 2행이어야 한다. 2가 아닌 칸: {[(d, c, v) for (d, c), v in sorted(grid.items()) if v != 2]}")

sub("1-8 검사 결과 정리 — 내가 고른 처리")
print("  ① 완전히 같은 행 한 쌍(데이터 47·48행 L1719)은 뒤엣것을 뺀다 → 108행. 뺀 값과 넣은 값 둘 다 아래에 낸다.")
print("  ② chamber 'ch-3b' 1행은 대문자로 맞춘다 (CH-3B 로 센다).")
print("  ③ date '2026/08/30' 1행은 '-' 로 맞춘다.")
print("  ④ particle_defects 가 빈 1행(L1704)은 수율 계산에는 넣고 파티클 비율 계산에서만 뺀다.")

# ==================================================================================================
head("[2] 두 파일을 이어 붙인 시계열 (07-01 ~ 09-03)")

def load_all(dedupe=True):
    out = []
    seen = set()
    for path, tag in ((YIELD_MAIN, "main"), (YIELD_ADD, "add")):
        _, _, rs = rows(path)
        for i, r in enumerate(rs):
            key = tuple(r)
            if dedupe and key in seen:
                continue
            seen.add(key)
            out.append({
                "lot": r[0], "date": norm_date(r[1]), "line": r[2],
                "ch": r[3].upper(), "y": float(r[4]), "d": int(r[5]),
                "p": None if r[6].strip() == "" else int(r[6]),
                "src": tag, "row": i + 1,
            })
    return out

DATA = load_all(dedupe=True)
DATA_RAW = load_all(dedupe=False)
print(f"  이어 붙인 행 수: 중복 뺀 것 {len(DATA)} · 중복 넣은 것 {len(DATA_RAW)}")
dates = sorted(set(x['date'] for x in DATA))
print(f"  날짜 {dates[0]} ~ {dates[-1]} · 서로 다른 날 {len(dates)}")
gap = []
import datetime as dt
d0 = dt.date.fromisoformat(dates[0])
d1 = dt.date.fromisoformat(dates[-1])
cur = d0
while cur <= d1:
    if cur.isoformat() not in set(dates):
        gap.append(cur.isoformat())
    cur += dt.timedelta(days=1)
print(f"  수율 자료가 없는 날: {gap if gap else '없음'}")
print(f"  챔버별 행 수: {dict(sorted(Counter(x['ch'] for x in DATA).items()))}")

# 설비 이력
_, eqh, eq_main_rows = rows(EQ_MAIN)
_, _, eq_add_rows = rows(EQ_ADD)
EQ = [dict(zip(eqh, r)) for r in eq_main_rows + eq_add_rows]
for e in EQ:
    e["date"] = norm_date(e["date"])
eq_dates = sorted(set(e["date"] for e in EQ))
print(f"  설비 이력 행 수: {len(EQ)} (앞 {len(eq_main_rows)} + 부록 {len(eq_add_rows)}) · {eq_dates[0]} ~ {eq_dates[-1]}")
eq_gap = []
cur = dt.date.fromisoformat(eq_dates[0])
while cur <= dt.date.fromisoformat(eq_dates[-1]):
    if cur.isoformat() not in set(eq_dates):
        eq_gap.append(cur.isoformat())
    cur += dt.timedelta(days=1)
print(f"  설비 이력이 없는 날 {len(eq_gap)}일: {eq_gap}")
print("  그 가운데 이어진 닷새: " + str([g for g in eq_gap if "2026-08-21" <= g <= "2026-08-25"]))

sub("2-1 CH-3B 에 적힌 사건 전부 (두 파일 합쳐)")
for e in sorted([e for e in EQ if e["chamber"] == "CH-3B"], key=lambda x: x["date"]):
    print(f"  {e['date']} {e['event_type']:7s} {e['duration_min']:>4s}분  {e['detail']}")

sub("2-2 08-26 ~ 09-02 모든 챔버 사건 (부록 10행)")
for e in sorted(eq_add_rows, key=lambda x: (x[0], x[1])):
    print(f"  {norm_date(e[0])} {e[1]} {e[2]:7s} {e[4]:>4s}분  {e[3]}  [{e[5] if e[5] else '담당자 빈칸'}]")

# ==================================================================================================
head("[3] 교체 앞뒤 로트 수율 — 실측 표")

REPLACE = "2026-08-27"
DROP = "2026-07-29"
PERIODS = [
    ("A 하락 전", "2026-07-01", "2026-07-27"),
    ("B 하락 뒤~교체 전", "2026-07-30", "2026-08-26"),
    ("C 교체일", "2026-08-27", "2026-08-27"),
    ("D 교체 뒤", "2026-08-28", "2026-09-03"),
]
print("  구간 정의 (07-28 정기 정비일과 07-29 하락 첫날, 08-27 교체일은 어느 쪽에도 넣지 않는다)")
for n, a, b in PERIODS:
    print(f"    {n:18s} {a} ~ {b}")
print("    * 07-28·07-29 두 날은 A·B 어디에도 넣지 않았다 (07-28 은 정비일, 07-29 는 하락 첫날이라 두 원인이 섞인다).")

def sel(ch, a, b, data=None):
    data = DATA if data is None else data
    return [x for x in data if x["ch"] == ch and a <= x["date"] <= b]

sub("3-1 CH-3B 로트 낱낱 (08-20 ~ 09-03)")
print("  날짜        lot     수율    불량  파티클  파티클/불량   구간")
for x in sorted(sel("CH-3B", "2026-08-20", "2026-09-03"), key=lambda z: (z["date"], z["lot"])):
    seg = next((n for n, a, b in PERIODS if a <= x["date"] <= b), "-")
    pr = f"{x['p'] / x['d']:.4f}" if x["p"] is not None else "   -  "
    print(f"  {x['date']}  {x['lot']}  {x['y']:6.2f}  {x['d']:4d}  {str(x['p']):>5s}   {pr:>8s}   {seg}")

sub("3-2 구간별 챔버 평균 수율 (로트 단위 · 중복 뺀 108행 기준)")
print("  챔버     " + "".join(f"{n.split()[0]}({n.split()[1] if len(n.split()) > 1 else ''})".ljust(22) for n, _, _ in PERIODS))
stats = {}
for ch in chs:
    line = f"  {ch}  "
    for n, a, b in PERIODS:
        v = [x["y"] for x in sel(ch, a, b)]
        stats[(ch, n)] = v
        line += f"n={len(v):<3d} 평균 {st.fmean(v):6.3f}".ljust(22)
    print(line)

sub("3-3 교체 앞뒤 차이 Δ = (D 교체 뒤) - (B 교체 전) · 여섯 챔버 나란히")
print("  챔버     B 평균    D 평균     Δ(%p)     Welch t      df     기준선 A 평균   D-A(%p)")
deltas = {}
for ch in chs:
    B = stats[(ch, "B 하락 뒤~교체 전")]
    D = stats[(ch, "D 교체 뒤")]
    A = stats[(ch, "A 하락 전")]
    t, df = welch(D, B)
    deltas[ch] = st.fmean(D) - st.fmean(B)
    print(f"  {ch}  {st.fmean(B):7.3f}  {st.fmean(D):7.3f}  {deltas[ch]:+8.3f}  {t:9.3f}  {df:7.2f}      {st.fmean(A):7.3f}   {st.fmean(D) - st.fmean(A):+7.3f}")
print(f"  CH-3B 를 뺀 다섯 챔버 Δ 의 최소~최대: {min(v for k, v in deltas.items() if k != 'CH-3B'):+.3f} ~ {max(v for k, v in deltas.items() if k != 'CH-3B'):+.3f}")
print(f"  Δ 가 가장 큰 챔버: {max(deltas, key=deltas.get)} ({max(deltas.values()):+.3f}%p)")

sub("3-4 '돌아왔나' — CH-3B 의 D 를 A(하락 전)와 견준다")
A = stats[("CH-3B", "A 하락 전")]
B = stats[("CH-3B", "B 하락 뒤~교체 전")]
D = stats[("CH-3B", "D 교체 뒤")]
C = stats[("CH-3B", "C 교체일")]
for nm, v in (("A 하락 전", A), ("B 교체 전", B), ("C 교체일", C), ("D 교체 뒤", D)):
    print(f"  {nm:10s} n={len(v):3d}  평균 {st.fmean(v):7.3f}  표준편차 {st.stdev(v) if len(v) > 1 else float('nan'):6.3f}  최소 {min(v):6.2f}  최대 {max(v):6.2f}")
t_da, df_da = welch(D, A)
t_db, df_db = welch(D, B)
print(f"  D - A = {st.fmean(D) - st.fmean(A):+.3f}%p (Welch t {t_da:.3f}, df {df_da:.2f})")
print(f"  D - B = {st.fmean(D) - st.fmean(B):+.3f}%p (Welch t {t_db:.3f}, df {df_db:.2f})")
print(f"  하락폭 A - B = {st.fmean(A) - st.fmean(B):.3f}%p · 회복폭 D - B = {st.fmean(D) - st.fmean(B):.3f}%p · 회복 비율 {(st.fmean(D) - st.fmean(B)) / (st.fmean(A) - st.fmean(B)) * 100:.1f}%")

sub("3-5 같은 계산을 중복 행을 넣은 109행으로 다시 (처리 ① 이 결과를 바꾸는가)")
Bx = [x["y"] for x in sel("CH-3B", "2026-07-30", "2026-08-26", DATA_RAW)]
Dx = [x["y"] for x in sel("CH-3B", "2026-08-28", "2026-09-03", DATA_RAW)]
print(f"  중복 넣음: B n={len(Bx)} 평균 {st.fmean(Bx):.3f} · D n={len(Dx)} 평균 {st.fmean(Dx):.3f} · Δ {st.fmean(Dx) - st.fmean(Bx):+.3f}")
print(f"  중복 뺌  : B n={len(B)} 평균 {st.fmean(B):.3f} · D n={len(D)} 평균 {st.fmean(D):.3f} · Δ {st.fmean(D) - st.fmean(B):+.3f}")
print(f"  L1719 의 날짜·챔버: {[(x['date'], x['ch']) for x in DATA_RAW if x['lot'] == 'L1719']}")
print("  * 중복 행 L1719 는 08-29 CH-3B 라 D 구간 안에 있다. 그래서 처리 ① 이 D 평균을 움직인다 —")
print(f"    넣으면 {st.fmean(Dx):.3f}, 빼면 {st.fmean(D):.3f} 로 {abs(st.fmean(Dx) - st.fmean(D)):.3f}%p 갈린다."
      " 부호와 크기 차례는 어느 쪽이든 같다.")

sub("3-6 교체 뒤 날마다의 CH-3B 평균 (하루 2로트)")
byday = defaultdict(list)
for x in sel("CH-3B", "2026-08-20", "2026-09-03"):
    byday[x["date"]].append(x["y"])
for d in sorted(byday):
    mark = " <- 교체일(PART 100분 + CLEAN 60분)" if d == REPLACE else (" <- 파티클 경고" if d == "2026-09-02" else "")
    print(f"  {d}  n={len(byday[d])}  평균 {st.fmean(byday[d]):7.3f}{mark}")

# ==================================================================================================
head("[4] 파티클 비율 — 교체가 파티클 불량을 되돌렸나")
print("  정의 P = 구간의 파티클 합 ÷ 불량 합 · 정의 M = 로트마다 낸 비율의 평균. 두 값을 함께 낸다.")
print("  챔버     " + "".join(f"{n.split()[0]}".ljust(26) for n, _, _ in PERIODS))
for ch in chs:
    line = f"  {ch}  "
    for n, a, b in PERIODS:
        v = [x for x in sel(ch, a, b) if x["p"] is not None]
        P = sum(x["p"] for x in v) / sum(x["d"] for x in v)
        M = st.fmean([x["p"] / x["d"] for x in v])
        line += f"P {P:.4f} M {M:.4f}".ljust(26)
    print(line)
print("\n  CH-3B 구간별 P 의 변화")
prev = None
for n, a, b in PERIODS:
    v = [x for x in sel("CH-3B", a, b) if x["p"] is not None]
    P = sum(x["p"] for x in v) / sum(x["d"] for x in v)
    print(f"    {n:18s} P {P:.4f}" + (f"   앞 구간 대비 {P - prev:+.4f}" if prev is not None else ""))
    prev = P

# ==================================================================================================
head("[5] 변화점 탐색 — 교체일이 자료에서 저절로 잡히나 (memory 의 방법)")

def changepoint(ch, a, b, seed=20260909, iters=2000):
    ser = defaultdict(list)
    for x in sel(ch, a, b):
        ser[x["date"]].append(x["y"])
    dd = sorted(ser)
    vals = [st.fmean(ser[d]) for d in dd]
    n = len(vals)

    def best(v):
        bt, bi = 0.0, None
        for i in range(3, n - 2):
            t, _ = welch(v[i:], v[:i])
            if not math.isnan(t) and abs(t) > bt:
                bt, bi = abs(t), i
        return bt, bi

    bt, bi = best(vals)
    rnd = random.Random(seed)
    ge = 0
    for _ in range(iters):
        sh = vals[:]
        rnd.shuffle(sh)
        if best(sh)[0] >= bt:
            ge += 1
    p = (ge + 1) / (iters + 1)
    return dd, vals, bt, dd[bi], p

for ch, a, b, tag in (("CH-3B", "2026-08-01", "2026-09-03", "8월 이후만"),
                      ("CH-3B", "2026-07-01", "2026-09-03", "전 기간"),
                      ("CH-3A", "2026-08-01", "2026-09-03", "대조 8월 이후"),
                      ("CH-2B", "2026-08-01", "2026-09-03", "대조 8월 이후")):
    dd, vals, bt, cut, p = changepoint(ch, a, b)
    print(f"  {ch} {tag:12s} 날 {len(dd)}개 · |t| 최대 {bt:.3f} · 잘린 날 {cut} (그날부터 뒤 구간) · 순열 p {p:.4f}")

# ==================================================================================================
head("[6] 뗀 부품과 단 부품 — 입고 값 대 재측정 값")
_, rh, rm = rows(REMEAS)
_, ih, insp = rows(INSPECT)
print("  재측정 원본 2행")
for r in rm:
    d = dict(zip(rh, r))
    inc, re_ = float(d["incoming_value"]), float(d["remeasure_value"])
    smax = float(d["spec_max"])
    print(f"    {d['serial']}  입고 {d['incoming_date']} {inc} {d['unit']} (상한 {smax}, {inc / smax:.2f}배)"
          f" → 재측정 {d['remeasure_date']} {re_} {d['unit']} ({re_ / smax:.2f}배) · 차이 {re_ - inc:+.1f} {d['unit']} ({(re_ - inc) / inc * 100:+.1f}%)")
    print(f"      note: {d['note']}")
print("\n  입고 검사 원본에서 같은 두 낱개를 찾는다 (07-28 이 무엇인지 밝힌다)")
for i, r in enumerate(insp):
    d = dict(zip(ih, r))
    if d["serial"] in ("SH2200-B-0412", "SH2200-B-0413"):
        print(f"    insp 데이터 {i + 1}행  serial {d['serial']} · recv_date {d['recv_date']} · measured {d['measured']} {d['unit']}"
              f" · install_date {d['install_date'] or '(빈칸)'} · chamber {d['chamber'] or '(빈칸)'}")
print("    → 4.8 um 은 recv_date 2026-07-18 의 입고 검사 값이고, 2026-07-28 은 그 낱개의 install_date 다.")
print("    → 재측정 원본의 incoming_date 도 2026-07-18 이라 두 자료가 같은 값을 가리킨다 (어긋난 자리 0곳).")

# ==================================================================================================
head("[7] 남는 경쟁 설명 — 교체 뒤 회복을 '부품 때문'이라고 말할 때 걸리는 것을 센다")
same_day = [e for e in EQ if e["date"] == REPLACE and e["chamber"] == "CH-3B"]
print(f"  ① 교체일 같은 날 CH-3B 에 함께 있던 사건: {len(same_day)}건")
for e in same_day:
    print(f"     {e['date']} {e['event_type']} {e['duration_min']}분 {e['detail']}")
after = [e for e in EQ if e["date"] > REPLACE]
print(f"  ② 교체 뒤(08-28~09-02) 자료에 있는 사건 {len(after)}건 — 그 가운데 CH-3B: {[(e['date'], e['event_type'], e['detail']) for e in after if e['chamber'] == 'CH-3B']}")
print(f"     다른 챔버: {[(e['date'], e['chamber'], e['event_type']) for e in after if e['chamber'] != 'CH-3B']}")
print(f"  ③ 설비 이력이 비어 있는 닷새(08-21~08-25)에 CH-3B 수율 행은 {len(sel('CH-3B', '2026-08-21', '2026-08-25'))}개 있다 — 사건은 셀 수 없다.")
print(f"  ④ 07-28 정기 정비(PM)와 08-27 교체가 둘 다 CH-3B 에 있었다. 두 사건 사이 CH-3B 의 CLEAN 횟수: "
      f"{len([e for e in EQ if e['chamber'] == 'CH-3B' and e['event_type'] == 'CLEAN' and '2026-07-29' <= e['date'] <= '2026-08-26'])}건")
print("  ⑤ 규격 초과 낱개가 달린 다른 챔버(CH-1A · HC40-A-0771 · 1.22배)의 같은 기간 Δ 는 위 3-3 표에 있다.")

sub("7-1 경쟁 설명 ①(같은 날 세정) 을 시험한다 — 세정만으로 CH-3B 가 돌아온 적이 있나")
print("  CH-3B 에 앞서 있던 CLEAN 사건마다 앞 7일 · 뒤 7일 로트 평균을 견준다 (교체 없이 세정만 있던 날).")
print("  날짜        종류·분     앞 7일 평균   뒤 7일 평균     Δ(%p)   n(앞/뒤)")
for e in sorted([x for x in EQ if x["chamber"] == "CH-3B" and x["event_type"] == "CLEAN"], key=lambda z: z["date"]):
    d = dt.date.fromisoformat(e["date"])
    pre = [x["y"] for x in sel("CH-3B", (d - dt.timedelta(days=7)).isoformat(), (d - dt.timedelta(days=1)).isoformat())]
    post = [x["y"] for x in sel("CH-3B", (d + dt.timedelta(days=1)).isoformat(), (d + dt.timedelta(days=7)).isoformat())]
    if not pre or not post:
        continue
    tag = " (같은 날 부품 교체가 함께 있었다)" if e["date"] == REPLACE else ""
    print(f"  {e['date']}  {e['duration_min']:>4s}분     {st.fmean(pre):8.3f}   {st.fmean(post):8.3f}   {st.fmean(post) - st.fmean(pre):+8.3f}   {len(pre)}/{len(post)}{tag}")
print("  * 08-10 은 180분 '특별 세정 (파티클 대응)' 이다 — 자료 안에서 가장 센 세정인데도 위 표의 Δ 가 가장 작은 쪽이다.")

print("\n  견줌: 여섯 챔버 전체에서 부품 교체가 없던 CLEAN 사건들의 같은 Δ 분포")
cd = []
for e in EQ:
    if e["event_type"] != "CLEAN":
        continue
    d = dt.date.fromisoformat(e["date"])
    same_day_part = any(x["chamber"] == e["chamber"] and x["date"] == e["date"] and x["event_type"] == "PART" for x in EQ)
    if same_day_part:
        continue
    pre = [x["y"] for x in sel(e["chamber"], (d - dt.timedelta(days=7)).isoformat(), (d - dt.timedelta(days=1)).isoformat())]
    post = [x["y"] for x in sel(e["chamber"], (d + dt.timedelta(days=1)).isoformat(), (d + dt.timedelta(days=7)).isoformat())]
    if len(pre) < 4 or len(post) < 4:
        continue
    cd.append((st.fmean(post) - st.fmean(pre), e["chamber"], e["date"]))
cd.sort()
print(f"  세정 사건 {len(cd)}건 · Δ 최소 {cd[0][0]:+.3f} ({cd[0][1]} {cd[0][2]}) · 최대 {cd[-1][0]:+.3f} ({cd[-1][1]} {cd[-1][2]})"
      f" · 중앙값 {st.median([c[0] for c in cd]):+.3f}")
print(f"  08-27 교체+세정 날의 Δ 는 위 표에 있다. 세정만 있던 {len(cd)}건 가운데 +2.0%p 를 넘은 것: "
      f"{[(c[1], c[2], round(c[0], 3)) for c in cd if c[0] >= 2.0]}")

sub("7-2 교체 뒤 이레의 흐름 — 더 오를 여지가 있나")
dnums = sorted(set(x["date"] for x in sel("CH-3B", "2026-08-28", "2026-09-03")))
xs = list(range(len(dnums)))
ys_d = [st.fmean([x["y"] for x in sel("CH-3B", d, d)]) for d in dnums]
mx, my = st.fmean(xs), st.fmean(ys_d)
slope = sum((a - mx) * (b - my) for a, b in zip(xs, ys_d)) / sum((a - mx) ** 2 for a in xs)
print(f"  날마다의 평균에 직선을 맞추면 기울기 {slope:+.4f}%p/일 (점 {len(xs)}개). 점이 이레뿐이라 이것만으로는 정하지 않는다.")
print(f"  D 구간 첫 사흘 평균 {st.fmean(ys_d[:3]):.3f} · 마지막 사흘 평균 {st.fmean(ys_d[-3:]):.3f}")
print(f"  A(하락 전) 평균 {st.fmean(A):.3f} 과의 거리: 마지막 사흘로 보면 {st.fmean(ys_d[-3:]) - st.fmean(A):+.3f}%p")

sub("7-3 파티클 비율도 같은 셈으로")
pA = sum(x["p"] for x in sel("CH-3B", "2026-07-01", "2026-07-27") if x["p"] is not None) / sum(x["d"] for x in sel("CH-3B", "2026-07-01", "2026-07-27") if x["p"] is not None)
pB = sum(x["p"] for x in sel("CH-3B", "2026-07-30", "2026-08-26") if x["p"] is not None) / sum(x["d"] for x in sel("CH-3B", "2026-07-30", "2026-08-26") if x["p"] is not None)
pD = sum(x["p"] for x in sel("CH-3B", "2026-08-28", "2026-09-03") if x["p"] is not None) / sum(x["d"] for x in sel("CH-3B", "2026-08-28", "2026-09-03") if x["p"] is not None)
print(f"  A {pA:.4f} · B {pB:.4f} · D {pD:.4f} · 회복 비율 (B-D)/(B-A) = {(pB - pD) / (pB - pA) * 100:.1f}%")
print(f"  수율의 회복 비율 {(st.fmean(D) - st.fmean(B)) / (st.fmean(A) - st.fmean(B)) * 100:.1f}% 와 견준다.")

# ==================================================================================================
head("[8] 이 문서가 쓸 자기 서술 숫자")
print(f"  부록 데이터 행 {len(add)} · 중복 뺀 뒤 {len(add) - sum(v - 1 for v in dups_full.values())}")
print(f"  검사 항목 여섯(모양·중복·키·결측·표기·범위) 가운데 흠이 잡힌 것: 4 (중복 1쌍 · 결측 1칸 · 소문자 챔버 1행 · 날짜 구분자 1행)")
print(f"  이어 붙인 수율 행 {len(DATA)} · 챔버 {len(chs)} · 날 {len(dates)}")
print(f"  설비 이력 {len(EQ)}행 · 빈 날 {len(eq_gap)}일")

# ==================================================================================================
# 아래는 작업 23 교차 검토를 받아 덧붙인 절이다. 앞 절의 출력은 한 줄도 바꾸지 않는다 —
# 결론 문서가 log#N 으로 앞 행을 가리키고 있으므로 새 계산은 반드시 끝에만 붙인다.
# ==================================================================================================
head("[9] 교차 검토(작업 23) 정정용 재계산")

sub("9-1 세정 건수를 본문이 밝힌 규칙 그대로 다시 센다")
print("  규칙 ①(본문이 적은 것): 여섯 챔버의 CLEAN 가운데 같은 날 같은 챔버에 PART 가 없던 것. 창은 앞 7일·뒤 7일.")
clean_all = [e for e in EQ if e["event_type"] == "CLEAN"]
part_days = {(e["chamber"], e["date"]) for e in EQ if e["event_type"] == "PART"}
rule1 = [e for e in clean_all if (e["chamber"], e["date"]) not in part_days]
print(f"  CLEAN 사건 전부: {len(clean_all)}건 · 같은 날 같은 챔버에 PART 가 있던 것: "
      f"{[(e['chamber'], e['date']) for e in clean_all if (e['chamber'], e['date']) in part_days]}")
print(f"  규칙 ① 에 드는 세정: {len(rule1)}건")


def window_delta(e, w=7):
    d = dt.date.fromisoformat(e["date"])
    pre = [x["y"] for x in sel(e["chamber"], (d - dt.timedelta(days=w)).isoformat(), (d - dt.timedelta(days=1)).isoformat())]
    post = [x["y"] for x in sel(e["chamber"], (d + dt.timedelta(days=1)).isoformat(), (d + dt.timedelta(days=w)).isoformat())]
    return pre, post


rows_rule = []
for e in rule1:
    pre, post = window_delta(e)
    rows_rule.append((e, pre, post))
have = [(e, pre, post) for e, pre, post in rows_rule if pre and post]
print(f"  그 가운데 앞·뒤 창에 로트가 하나라도 있어 값이 나는 것: {len(have)}건")
dv = sorted(st.fmean(post) - st.fmean(pre) for _, pre, post in have)
print(f"  규칙 ① 의 Δ: 최소 {dv[0]:+.3f} · 최대 {dv[-1]:+.3f} · 중앙값 {st.median(dv):+.3f} · +2.0%p 를 넘은 것 "
      f"{len([v for v in dv if v > 2.0])}건")
strict = [(e, pre, post) for e, pre, post in have if len(pre) >= 4 and len(post) >= 4]
dvs = sorted(st.fmean(post) - st.fmean(pre) for _, pre, post in strict)
print(f"  내가 처음 쓴 조건(앞·뒤 창에 로트 4개 이상)까지 걸면: {len(strict)}건 · 최소 {dvs[0]:+.3f} · 최대 {dvs[-1]:+.3f}"
      f" · 중앙값 {st.median(dvs):+.3f} · +2.0%p 를 넘은 것 {len([v for v in dvs if v > 2.0])}건")
dropped = [(e['chamber'], e['date'], len(pre), len(post)) for e, pre, post in have if not (len(pre) >= 4 and len(post) >= 4)]
print(f"  두 규칙의 차이는 {len(dropped)}건이고 그 자리는 다음과 같다(챔버·날·앞 로트 수·뒤 로트 수): {dropped}")
print("  → 건수는 규칙에 따라 갈리지만 '+2.0%p 를 넘은 세정 0건'은 두 규칙에서 모두 같다.")

sub("9-2 2절 표의 창 — '앞 이레' 인가 '앞 엿새' 인가")
for a, b, name in (("2026-08-20", "2026-08-26", "08-20~08-26 (이레)"), ("2026-08-21", "2026-08-26", "08-21~08-26 (엿새)")):
    v = [x["y"] for x in sel("CH-3B", a, b)]
    print(f"  {name}: 로트 {len(v)}개 · 평균 {st.fmean(v):.3f}")
print("  6절의 '앞 7일 평균 90.165' 는 08-20 을 넣은 이레 창이다. 2절 표는 08-21 부터 실었으므로 하루 짧다.")

sub("9-3 물리쳐진 설명 둘을 자료로 다시 확인한다")
bser = defaultdict(list)
for x in sel("CH-3B", "2026-07-30", "2026-08-26"):
    bser[x["date"]].append(x["y"])
bd = sorted(bser)
bv = [st.fmean(bser[d]) for d in bd]
bx = list(range(len(bv)))
mbx, mbv = st.fmean(bx), st.fmean(bv)
bslope = sum((a - mbx) * (c - mbv) for a, c in zip(bx, bv)) / sum((a - mbx) ** 2 for a in bx)
half = len(bv) // 2
print(f"  ㉮ 자연 회복: B 구간 {len(bd)}일의 하루 평균 기울기 {bslope:+.4f}%p/일 · 앞 절반 {st.fmean(bv[:half]):.3f} · 뒤 절반 {st.fmean(bv[half:]):.3f}")
print("     교체 전 넉 주 동안 스스로 오르는 흐름이 없었다. 그래서 '시간이 지나 저절로 돌아왔다'는 설명이 서지 않는다.")
seam = [("2026-08-24", "앞 원본"), ("2026-08-25", "앞 원본"), ("2026-08-26", "부록 첫날"), ("2026-08-27", "부록 이튿날")]
print("  ㉯ 파일이 바뀐 탓: 두 파일의 이음새에서 CH-3B 하루 평균")
for d, tag in seam:
    print(f"     {d} ({tag:8s}) {st.fmean([x['y'] for x in sel('CH-3B', d, d)]):7.3f}")
print("     부록이 시작한 08-26 이 아니라 교체 이튿날 08-28 에 값이 뛴다. 파일 경계와 변화점이 이틀 어긋난다.")
pm = next(e for e in EQ if e["chamber"] == "CH-3A" and e["event_type"] == "PM" and e["date"] == "2026-07-28")
pre, post = window_delta(pm)
print(f"  ㉰ 07-28 정기 정비: 같은 날 같은 PM 을 받은 CH-3A 의 앞 7일 {st.fmean(pre):.3f} · 뒤 7일 {st.fmean(post):.3f}"
      f" · Δ {st.fmean(post) - st.fmean(pre):+.3f}%p")

sub("9-4 넷째 경쟁 설명(로트에 흐른 제품·공정 조건)을 자료로 얼마나 좁힐 수 있나")
print(f"  수율 원본의 열: {hdr_add} — 제품·품종·레시피를 적은 칸이 없다. 그래서 이 설명은 세울 수도 물리칠 수도 없다.")
print(f"  다만 같은 3라인의 이웃 CH-3A 의 같은 구간 Δ 는 {deltas['CH-3A']:+.3f}%p 다."
      " 라인에 흐른 것이 통째로 바뀌었다면 이 챔버도 함께 움직였을 자리다.")
line3 = [x for x in DATA if x["line"] == "3"]
print(f"  3라인 행 수 {len(line3)} · 그 챔버 {sorted(set(x['ch'] for x in line3))} — 3라인은 CH-3A 와 CH-3B 둘로만 이루어져 있다.")

# ==================================================================================================
# 아래는 둘째 정정(배분 333)으로 덧붙인 절이다. 앞 절의 출력은 한 줄도 바꾸지 않는다.
# ==================================================================================================
head("[10] 29건과 27건을 가르는 사건을 낱낱이 센다")
print("  규칙 ①(29건) 에서 두 조건을 차례로 걸어 27건까지 좁힌다. 걸러지는 사건을 하나씩 적는다.")
print("  챔버   날짜        앞 창 로트  뒤 창 로트   어느 조건에 걸리나")
gone = []
for e, pre, post in rows_rule:
    why = []
    if not pre or not post:
        why.append("값이 나지 않는다(창 하나가 비었다)")
    elif len(pre) < 4 or len(post) < 4:
        why.append("앞·뒤 창에 로트 4개 이상이 아니다")
    if why:
        gone.append((e, pre, post, why[0]))
        print(f"  {e['chamber']}  {e['date']}      {len(pre):3d}       {len(post):3d}      {why[0]}")
print(f"  규칙 ① {len(rows_rule)}건 - 걸러진 {len(gone)}건 = {len(rows_rule) - len(gone)}건")
print(f"  그러므로 29 와 27 의 차이는 {len(gone)}건이다. 앞서 '한 건'이라 적은 것은 28 과 27 의 차이였다.")
print(f"  세 수의 관계: 규칙 그대로 {len(rule1)}건 → 값이 나는 것 {len(have)}건 → 창이 꽉 찬 것 {len(strict)}건.")
print(f"  걸러진 두 건을 넣어도 '+2.0%p 를 넘은 세정 0건' 은 그대로다 — 값이 나는 한 건의 Δ 는 "
      f"{[round(st.fmean(post) - st.fmean(pre), 3) for e, pre, post, w in gone if pre and post]} 이고 나머지 한 건은 값이 나지 않는다.")
