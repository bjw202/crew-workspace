작업: 8
결론: analyst/task-8-chamber-yield-drop.md 를 냈다. "15곳"은 세 자리에 있었고 셋 다 "18곳"으로 고쳤으며, 정정표는 17행에서 18행이 되어 문장의 수와 같아졌다. 수치·결론은 작업 2 판과 글자 그대로 같다.
근거: diff -u (task-5→task-8) 10줄 삭제·12줄 추가 = 22줄 — 머리말 10, 안내 2, "15"→"18" 6, 고침 5 행 1, 행나눔 3, 그 밖 0. 옛 판은 1줄 삽입·1줄 삭제(valid→void). 계수는 인용 20곳에서 그대로 둔 둘을 뺀 18. 전문 task-8-evidence.log.
내가 정한 것: 끝 조건 ②의 "정정표 행 수와 같다"를 맞추려고, 인용 둘을 담고 있던 "3절 불량 분해" 행을 둘로 나눠 17행을 18행으로 만들었다. "15"는 짚어 준 두 자리 말고 "이 판에서 고친 것" 표 4행에도 있어 셋 다 고쳤다.
못 확인한 것: 바꿔야 할 수치는 없었다. 커밋 직전 git status 에 reporter 폴더 미추적 파일 셋이 보였다 — 손대지 않고 경로를 못 박아 커밋했고 커밋에 든 파일이 analyst/ 다섯뿐임을 확인했다. remote 가 없어 push 는 못 했다.
결과물: analyst/task-8-chamber-yield-drop.md · analyst/task-8-evidence.log · analyst/task-8-notes.md (옛 판 analyst/task-5-chamber-yield-drop.md 는 status: void)
