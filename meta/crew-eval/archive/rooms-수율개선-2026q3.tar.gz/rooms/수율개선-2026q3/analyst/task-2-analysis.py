#!/usr/bin/env python3
"""task-2: 로트별 수율 데이터 분석.
입력  : archivist/inbox/2026-09-08-yield-by-lot/44cdd855-...-yield_by_lot.csv
출력  : analyst/task-2-evidence.log (표준출력을 그대로 저장)
재현  : python3 analyst/task-2-analysis.py > analyst/task-2-evidence.log
계산은 표준 라이브러리만 사용한다(외부 패키지 없음).
"""
import csv, math, random, statistics as st
from collections import defaultdict, OrderedDict

CSV = ("../archivist/inbox/2026-09-08-yield-by-lot/"
       "44cdd855-be6e-4b66-a014-e7eb3a056769-yield_by_lot.csv")
MIN_SEG = 7        # 변화점 앞뒤 최소 일수
N_PERM  = 2000     # 순열검정 반복
SEED    = 20260908

def line(s=""): print(s)

# ---------- 1. 적재 ----------
rows = []
with open(CSV, newline="", encoding="utf-8") as f:
    rd = csv.DictReader(f)
    header = rd.fieldnames
    for r in rd:
        rows.append(dict(
            lot_id=r["lot_id"], date=r["date"], line=int(r["line"]),
            chamber=r["chamber"], yield_pct=float(r["yield_pct"]),
            defect_count=int(r["defect_count"]),
            particle_defects=int(r["particle_defects"])))

line("=" * 78)
line("[1] 적재와 무결성 검사")
line("=" * 78)
line(f"파일        : {CSV}")
line(f"열          : {header}")
line(f"데이터 행 수: {len(rows)}")
blanks = sum(1 for r0 in rows for v in r0.values() if v == "" or v is None)
line(f"빈칸 수     : {blanks}")
dates = sorted({r['date'] for r in rows})
line(f"기간        : {dates[0]} ~ {dates[-1]}  (서로 다른 날짜 {len(dates)}일)")
line(f"lot_id 중복 : {len(rows) - len({r['lot_id'] for r in rows})}건")

# 끝 조건 ① particle_defects <= defect_count 전수 검사
viol = [r for r in rows if r["particle_defects"] > r["defect_count"]]
line("")
line("-- 끝 조건 ① particle_defects <= defect_count 전수 검사 --")
line(f"검사한 행 수 : {len(rows)}")
line(f"위반 행 수   : {len(viol)}")
for r in viol[:20]:
    line(f"  위반: {r['lot_id']} {r['date']} {r['chamber']} "
         f"defect={r['defect_count']} particle={r['particle_defects']}")
if not viol:
    line("  -> 위반 0건. particle_defects 는 defect_count 의 부분집합으로 성립한다.")
line(f"defect_count == 0 인 행 수 : {sum(1 for r in rows if r['defect_count']==0)} "
     "(0이면 파티클 비율 계산에 0나눗셈 없음)")
line(f"yield_pct 범위 : {min(r['yield_pct'] for r in rows)} ~ {max(r['yield_pct'] for r in rows)}")

# 행 수 분포
line("")
line("-- 행 수 분포 --")
byline = defaultdict(int); bych = defaultdict(int); chline = {}
for r in rows:
    byline[r["line"]] += 1; bych[r["chamber"]] += 1
    chline.setdefault(r["chamber"], set()).add(r["line"])
for k in sorted(byline): line(f"line {k}: {byline[k]}행")
for k in sorted(bych):   line(f"{k}: {bych[k]}행 (line {sorted(chline[k])})")

CHAMBERS = sorted(bych)

# ---------- 2. 일별 집계 ----------
def daily(rs, key):
    d = defaultdict(list)
    for r in rs: d[r["date"]].append(r)
    out = OrderedDict()
    for dt in sorted(d):
        out[dt] = key(d[dt])
    return out

mean_yield  = lambda g: st.mean(x["yield_pct"] for x in g)
part_ratio  = lambda g: (sum(x["particle_defects"] for x in g) /
                         sum(x["defect_count"] for x in g))
mean_defect = lambda g: st.mean(x["defect_count"] for x in g)

# ---------- 3. 변화점 탐색 ----------
def best_split(vals):
    """단일 변화점: |Welch t| 가 최대가 되는 분할 인덱스 k (앞=vals[:k], 뒤=vals[k:]).
       누적합·누적제곱합으로 각 분할의 평균·표본분산을 O(1)에 구한다(수식은 Welch t 그대로)."""
    n = len(vals)
    cs = [0.0] * (n + 1); cq = [0.0] * (n + 1)
    for i, v in enumerate(vals):
        cs[i+1] = cs[i] + v
        cq[i+1] = cq[i] + v * v
    best_k, best_t = None, 0.0
    for k in range(MIN_SEG, n - MIN_SEG + 1):
        na, nb = k, n - k
        if na < 2 or nb < 2: continue
        ma = cs[k] / na
        mb = (cs[n] - cs[k]) / nb
        va = max((cq[k] - na * ma * ma) / (na - 1), 0.0)
        vb = max(((cq[n] - cq[k]) - nb * mb * mb) / (nb - 1), 0.0)
        se2 = va / na + vb / nb
        if se2 <= 0: continue
        t = (mb - ma) / math.sqrt(se2)
        if abs(t) > abs(best_t): best_k, best_t = k, t
    return best_k, best_t

def perm_p(vals, obs_t, n=N_PERM, seed=SEED):
    """라벨 섞기 순열검정. 변화점 탐색(최대화)까지 포함해 재계산하므로
       '어디선가 변화가 있었다'는 귀무가설에 대한 다중비교 보정된 p 다."""
    rnd = random.Random(seed)
    v = list(vals); cnt = 0
    for _ in range(n):
        rnd.shuffle(v)
        _, t = best_split(v)
        if abs(t) >= abs(obs_t): cnt += 1
    return (cnt + 1) / (n + 1)

def analyze(series, label):
    ds = list(series.keys()); vals = list(series.values())
    k, t = best_split(vals)
    if k is None:
        return None
    before, after = vals[:k], vals[k:]
    p = perm_p(vals, t)
    return dict(label=label, cp_date=ds[k], k=k, n=len(vals),
                before_n=len(before), after_n=len(after),
                before=st.mean(before), after=st.mean(after),
                diff=st.mean(after) - st.mean(before), t=t, p=p,
                sd_before=st.pstdev(before), sd_after=st.pstdev(after))

def show(res, unit="%p", prec=2):
    line(f"  변화점 날짜   : {res['cp_date']}  (일 인덱스 {res['k']}/{res['n']})")
    line(f"  전 구간       : {res['before_n']}일, 평균 {res['before']:.{prec}f} "
         f"(표준편차 {res['sd_before']:.{prec}f})")
    line(f"  후 구간       : {res['after_n']}일, 평균 {res['after']:.{prec}f} "
         f"(표준편차 {res['sd_after']:.{prec}f})")
    line(f"  차이          : {res['diff']:+.{prec}f} {unit}")
    line(f"  Welch t       : {res['t']:.2f}")
    line(f"  순열검정 p    : {res['p']:.4f}  (반복 {N_PERM}회, seed={SEED})")

# ---------- 4. 챔버별 수율 ----------
line("")
line("=" * 78)
line("[2] 챔버별 수율 변화점 (끝 조건 ②)")
line("=" * 78)
line(f"방법: 챔버별 일평균 수율 56점에서 단일 변화점을 |Welch t| 최대로 찾고,")
line(f"      라벨 순열검정 {N_PERM}회로 p 를 구한다. 앞뒤 최소 {MIN_SEG}일.")
yield_res = {}
for ch in CHAMBERS:
    rs = [r for r in rows if r["chamber"] == ch]
    s = daily(rs, mean_yield)
    res = analyze(s, ch)
    yield_res[ch] = res
    line("")
    line(f"[{ch}] 전체 평균 수율 {st.mean(v for v in s.values()):.2f}% "
         f"(로트 {len(rs)}개, 일수 {len(s)})")
    show(res, "%p")

# ---------- 5. 챔버별 파티클 비율 ----------
line("")
line("=" * 78)
line("[3] 챔버별 파티클 비율 변화점 (끝 조건 ③)")
line("=" * 78)
line("파티클 비율 = 그날 그 챔버의 particle_defects 합 / defect_count 합.")
part_res = {}
for ch in CHAMBERS:
    rs = [r for r in rows if r["chamber"] == ch]
    s = daily(rs, part_ratio)
    res = analyze(s, ch)
    part_res[ch] = res
    tot_p = sum(r["particle_defects"] for r in rs); tot_d = sum(r["defect_count"] for r in rs)
    line("")
    line(f"[{ch}] 전체 파티클 비율 {tot_p/tot_d:.4f} "
         f"(particle 합 {tot_p} / defect 합 {tot_d})")
    show(res, "", 4)

# ---------- 6. 수율 변화점 시점에서의 파티클 비율·불량 수 ----------
line("")
line("=" * 78)
line("[4] 수율 변화점 날짜를 기준으로 나눈 파티클 비율·불량 수 (끝 조건 ③ 같은 표용)")
line("=" * 78)
line("chamber | cp_date | yield_before | yield_after | yield_diff | "
     "part_before | part_after | part_diff | defect_before | defect_after")
summary = []
for ch in CHAMBERS:
    rs = [r for r in rows if r["chamber"] == ch]
    cp = yield_res[ch]["cp_date"]
    b = [r for r in rs if r["date"] <  cp]
    a = [r for r in rs if r["date"] >= cp]
    pb = sum(r["particle_defects"] for r in b) / sum(r["defect_count"] for r in b)
    pa = sum(r["particle_defects"] for r in a) / sum(r["defect_count"] for r in a)
    db = st.mean(r["defect_count"] for r in b); da = st.mean(r["defect_count"] for r in a)
    row = dict(ch=ch, cp=cp,
               yb=st.mean(r["yield_pct"] for r in b), ya=st.mean(r["yield_pct"] for r in a),
               pb=pb, pa=pa, db=db, da=da, nb=len(b), na=len(a))
    row["yd"] = row["ya"] - row["yb"]; row["pd"] = pa - pb
    summary.append(row)
    line(f"{ch} | {cp} | {row['yb']:.2f} | {row['ya']:.2f} | {row['yd']:+.2f} | "
         f"{pb:.4f} | {pa:.4f} | {row['pd']:+.4f} | {db:.1f} | {da:.1f} "
         f"(로트 전 {len(b)} / 후 {len(a)})")

# ---------- 7. 의뢰인 전제 검증: 3라인, 7월 말 ----------
line("")
line("=" * 78)
line("[5] 의뢰인 전제 검증 — '3라인 수율이 7월 말부터 떨어졌다'")
line("=" * 78)
for ln in sorted(byline):
    rs = [r for r in rows if r["line"] == ln]
    s = daily(rs, mean_yield)
    res = analyze(s, f"line{ln}")
    line("")
    line(f"[line {ln}] 전체 평균 수율 {st.mean(v for v in s.values()):.2f}%")
    show(res, "%p")

line("")
line("-- 7월 말(07-25~07-31) 앞뒤 고정 분할: 08-01 기준 라인별 평균 --")
line("line | 07-01~07-31 평균 | 08-01~08-25 평균 | 차이(%p)")
for ln in sorted(byline):
    b = [r["yield_pct"] for r in rows if r["line"] == ln and r["date"] < "2026-08-01"]
    a = [r["yield_pct"] for r in rows if r["line"] == ln and r["date"] >= "2026-08-01"]
    line(f"{ln} | {st.mean(b):.2f} | {st.mean(a):.2f} | {st.mean(a)-st.mean(b):+.2f} "
         f"(로트 {len(b)}/{len(a)})")

line("")
line("-- 각 챔버의 주별 평균 수율 (변화 모양 확인용) --")
def week(d):
    from datetime import date
    y, m, dd = map(int, d.split("-"))
    return date(y, m, dd).isocalendar()[1]
weeks = sorted({week(d) for d in dates})
line("chamber | " + " | ".join(f"W{w}" for w in weeks))
for ch in CHAMBERS:
    cells = []
    for w in weeks:
        v = [r["yield_pct"] for r in rows if r["chamber"] == ch and week(r["date"]) == w]
        cells.append(f"{st.mean(v):.2f}" if v else "-")
    line(f"{ch} | " + " | ".join(cells))

line("")
line("-- 각 챔버의 주별 파티클 비율 --")
line("chamber | " + " | ".join(f"W{w}" for w in weeks))
for ch in CHAMBERS:
    cells = []
    for w in weeks:
        g = [r for r in rows if r["chamber"] == ch and week(r["date"]) == w]
        cells.append(f"{sum(x['particle_defects'] for x in g)/sum(x['defect_count'] for x in g):.4f}"
                     if g else "-")
    line(f"{ch} | " + " | ".join(cells))

# ---------- 8. 파티클 외 불량 ----------
line("")
line("=" * 78)
line("[6] 파티클 불량과 그 밖의 불량을 나눠서 (불량 유형 변화)")
line("=" * 78)
line("chamber | cp_date(수율) | 전 파티클/로트 | 후 파티클/로트 | 전 비파티클/로트 | 후 비파티클/로트")
for row in summary:
    ch, cp = row["ch"], row["cp"]
    rs = [r for r in rows if r["chamber"] == ch]
    b = [r for r in rs if r["date"] <  cp]; a = [r for r in rs if r["date"] >= cp]
    pb = st.mean(r["particle_defects"] for r in b); pa = st.mean(r["particle_defects"] for r in a)
    nb = st.mean(r["defect_count"]-r["particle_defects"] for r in b)
    na = st.mean(r["defect_count"]-r["particle_defects"] for r in a)
    line(f"{ch} | {cp} | {pb:.1f} | {pa:.1f} | {nb:.1f} | {na:.1f}")

# ---------- 9. 수율과 파티클 비율의 관계 ----------
line("")
line("=" * 78)
line("[7] 수율과 파티클 비율의 상관 (로트 단위, 챔버별)")
line("=" * 78)
def pearson(x, y):
    n = len(x); mx, my = st.mean(x), st.mean(y)
    num = sum((a-mx)*(b-my) for a, b in zip(x, y))
    den = math.sqrt(sum((a-mx)**2 for a in x) * sum((b-my)**2 for b in y))
    return num/den if den else float("nan")
line("chamber | r(yield, particle_ratio) | r(yield, defect_count) | n")
for ch in CHAMBERS:
    rs = [r for r in rows if r["chamber"] == ch]
    y  = [r["yield_pct"] for r in rs]
    pr = [r["particle_defects"]/r["defect_count"] for r in rs]
    dc = [r["defect_count"] for r in rs]
    line(f"{ch} | {pearson(y,pr):+.3f} | {pearson(y,dc):+.3f} | {len(rs)}")

line("")
line("=" * 78)
line("[8] 계산 끝. 위 수치는 모두 이 스크립트의 출력이다.")
line(f"    재현: cd rooms/수율개선-2026q3/analyst && python3 task-2-analysis.py")
line("=" * 78)

# ---------- 10. CH-3B 변화 모양 자세히 ----------
line("")
line("=" * 78)
line("[9] CH-3B 변화 모양 — 계단인가 경사인가 (일별 상세 2026-07-24 ~ 2026-08-08)")
line("=" * 78)
rs3b = [r for r in rows if r["chamber"] == "CH-3B"]
dy = daily(rs3b, mean_yield); dp = daily(rs3b, part_ratio); dd = daily(rs3b, mean_defect)
line("date | 일평균 수율 | 파티클 비율 | 일평균 불량수 | 로트수")
for dt in sorted(dy):
    if "2026-07-24" <= dt <= "2026-08-08":
        n = sum(1 for r in rs3b if r["date"] == dt)
        line(f"{dt} | {dy[dt]:.2f} | {dp[dt]:.4f} | {dd[dt]:.1f} | {n}")

line("")
line("-- 기준선 대비 첫 이탈일 --")
base_y = [dy[d] for d in sorted(dy) if d < "2026-07-25"]
base_p = [dp[d] for d in sorted(dp) if d < "2026-07-25"]
my_, sy_ = st.mean(base_y), st.pstdev(base_y)
mp_, sp_ = st.mean(base_p), st.pstdev(base_p)
line(f"기준선(07-01~07-24, {len(base_y)}일): 수율 {my_:.2f}%(sd {sy_:.2f}) · "
     f"파티클 비율 {mp_:.4f}(sd {sp_:.4f})")
def first_cross(series, thr, below=True):
    for d in sorted(series):
        if d < "2026-07-25": continue
        if (series[d] < thr) if below else (series[d] > thr):
            return d, series[d]
    return None, None
for k_ in (2, 3):
    d1, v1 = first_cross(dy, my_ - k_*sy_, True)
    d2, v2 = first_cross(dp, mp_ + k_*sp_, False)
    line(f"수율이 기준선-{k_}sd({my_-k_*sy_:.2f}%) 아래로 처음 내려간 날 : {d1} ({v1})")
    line(f"파티클 비율이 기준선+{k_}sd({mp_+k_*sp_:.4f}) 위로 처음 올라간 날 : {d2} ({v2})")
line("이후 되돌아온 날이 있는가 — 07-29 이후 수율이 기준선-2sd 위로 회복한 날:")
back = [d for d in sorted(dy) if d >= "2026-07-29" and dy[d] > my_ - 2*sy_]
line(f"  {back if back else '없음 (한 번 내려간 뒤 회복한 날 0일)'}")

line("")
line("-- 변화 이후 추가 변화(2차 변화점) 검사: CH-3B 08-05~08-25 구간 --")
sub = OrderedDict((d, dy[d]) for d in sorted(dy) if d >= "2026-08-05")
if len(sub) >= 2*MIN_SEG:
    r2 = analyze(sub, "CH-3B-post")
    show(r2, "%p")
else:
    line(f"  구간 길이 {len(sub)}일 < {2*MIN_SEG}일 이라 변화점 탐색 생략")
line("-- 08-05~08-25 구간의 날짜 대 수율 기울기(최소제곱) --")
sub_v = list(sub.values()); xs = list(range(len(sub_v)))
mx_, mv_ = st.mean(xs), st.mean(sub_v)
slope = (sum((a-mx_)*(b-mv_) for a, b in zip(xs, sub_v)) / sum((a-mx_)**2 for a in xs))
line(f"  기울기 {slope:+.4f} %p/일 ({len(sub_v)}일)")

line("")
line("-- CH-3B: 파티클 불량과 비파티클 불량의 일별 개수(로트당 평균), 전환 구간 --")
line("date | 파티클/로트 | 비파티클/로트")
for dt in sorted(dy):
    if "2026-07-24" <= dt <= "2026-08-08":
        g = [r for r in rs3b if r["date"] == dt]
        line(f"{dt} | {st.mean(x['particle_defects'] for x in g):.1f} | "
             f"{st.mean(x['defect_count']-x['particle_defects'] for x in g):.1f}")

line("")
line("-- 대조: 같은 3라인 CH-3A 의 같은 구간 (설비 단위인지 라인 단위인지 가르기) --")
rs3a = [r for r in rows if r["chamber"] == "CH-3A"]
ay = daily(rs3a, mean_yield); ap = daily(rs3a, part_ratio)
line("date | CH-3A 수율 | CH-3A 파티클 비율")
for dt in sorted(ay):
    if "2026-07-24" <= dt <= "2026-08-08":
        line(f"{dt} | {ay[dt]:.2f} | {ap[dt]:.4f}")
b3a = [r["yield_pct"] for r in rs3a if r["date"] <  "2026-07-29"]
a3a = [r["yield_pct"] for r in rs3a if r["date"] >= "2026-07-29"]
line(f"CH-3A 07-29 기준 전후 평균: {st.mean(b3a):.2f}% -> {st.mean(a3a):.2f}% "
     f"({st.mean(a3a)-st.mean(b3a):+.2f} %p, 로트 {len(b3a)}/{len(a3a)})")
pb3a = sum(r["particle_defects"] for r in rs3a if r["date"] <  "2026-07-29") / \
       sum(r["defect_count"]     for r in rs3a if r["date"] <  "2026-07-29")
pa3a = sum(r["particle_defects"] for r in rs3a if r["date"] >= "2026-07-29") / \
       sum(r["defect_count"]     for r in rs3a if r["date"] >= "2026-07-29")
line(f"CH-3A 07-29 기준 전후 파티클 비율: {pb3a:.4f} -> {pa3a:.4f} ({pa3a-pb3a:+.4f})")

line("")
line("=" * 78)
line("[10] 되돌려 세기 — CH-3B 손실을 라인·전체 수율로 환산")
line("=" * 78)
loss = 93.69 - 90.07
for scope, rs_ in (("line 3", [r for r in rows if r["line"] == 3]),
                   ("전체",   rows)):
    share = sum(1 for r in rs_ if r["chamber"] == "CH-3B") / len(rs_)
    b_ = st.mean(r["yield_pct"] for r in rs_ if r["date"] <  "2026-07-29")
    a_ = st.mean(r["yield_pct"] for r in rs_ if r["date"] >= "2026-07-29")
    line(f"{scope}: CH-3B 로트 비중 {share:.3f} · 실측 평균 {b_:.2f}% -> {a_:.2f}% "
         f"({a_-b_:+.2f} %p) · CH-3B 하락폭 x 비중 = {-loss*share:+.2f} %p (설명되는 몫)")

line("")
line("=" * 78)
line("[11] 계산 끝(2차). 위 수치는 모두 이 스크립트의 출력이다.")
line("=" * 78)
