task: 22
dispatch: 333
stage: reported
next: 정정 확인 대기 (이 한 자리만 확인한다)
notes: analyst/task-22-notes.md
report: analyst/task-22-report.md
