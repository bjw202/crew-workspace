# -*- coding: utf-8 -*-
"""task-11 인용 전수 대조.
본문의 log11# · eq# · "task-8 판 행" 인용이 실제로 그 행을 가리키는지 확인한다.
행 번호는 1부터 센다. 리스트는 0부터이므로 src[n-1] 로 읽는다.
재현: cd rooms/수율개선-2026q3/analyst && python3 task-11-citation-check.py > task-11-citation-check.log
"""
import re, os

base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
doc = os.path.join(base, "analyst/task-11-equipment-history-vs-yield.md")
log = os.path.join(base, "analyst/task-11-evidence.log")
eqf = os.path.join(base, "archivist/inbox/2026-09-08-equipment-history/"
                         "423efc74-8819-445a-bb81-90ca388034fd-equipment_history.csv")
t8 = os.path.join(base, "analyst/task-8-chamber-yield-drop.md")


def lines(p):
    txt = open(p, encoding="utf-8", newline="").read().replace("\r\n", "\n")
    if txt.endswith("\n"):
        txt = txt[:-1]
    return txt.split("\n")


D, L, E, T = lines(doc), lines(log), lines(eqf), lines(t8)
print("본문 %d행 · 근거 로그 %d행 · 설비 이력 %d행 · task-8 판 %d행" % (len(D), len(L), len(E), len(T)))
print("행 번호는 1부터 센다. 아래 각 줄은 그 인용이 실제로 가리키는 줄의 앞부분이다.")
print("=" * 104)


def spans(tag):
    """tag#N · tag#N-M · tag#N·M·K-L 을 모두 잡는다.
    가운뎃점으로 이어 붙인 번호도 같은 태그의 인용이므로 하나씩 떼어 낸다."""
    out = []
    pat = re.compile(re.escape(tag) + r"#(?:행 )?(\d+(?:[-~]\d+)?(?:·\d+(?:[-~]\d+)?)*)")
    for i, ln in enumerate(D, 1):
        for m in pat.finditer(ln):
            for part in m.group(1).split("·"):
                if "-" in part or "~" in part:
                    a, b = re.split(r"[-~]", part)
                    a, b = int(a), int(b)
                else:
                    a = b = int(part)
                out.append((i, tag + "#" + part, a, b))
    return out


def check(tag, src, srcname):
    got = spans(tag)
    print()
    print("[%s] 인용 %d곳 — 대상 %s (%d행)" % (tag, len(got), srcname, len(src)))
    print("-" * 104)
    bad = 0
    for docline, raw, a, b in got:
        if a < 1 or b > len(src) or a > b:
            bad += 1
            print("  본문#%-4d %-18s  ** 범위 벗어남 (대상은 1~%d행) **" % (docline, raw, len(src)))
            continue
        print("  본문#%-4d %-18s  %d행: %s" % (docline, raw, a, src[a - 1].strip()[:60]))
        if b != a:
            print("  %-30s  %d행: %s" % ("", b, src[b - 1].strip()[:60]))
    print("  범위를 벗어난 인용: %d곳" % bad)
    return len(got), bad


n1, b1 = check("log11", L, "analyst/task-11-evidence.log")
n2, b2 = check("eq", E, "설비 이력 원본 CSV")

print()
print("[task-8 판 행] 인용 — 대상 analyst/task-8-chamber-yield-drop.md (%d행)" % len(T))
print("-" * 104)
b3 = 0
n3 = 0
for i, ln in enumerate(D, 1):
    for m in re.finditer(r"(?:task-8 )?판 행 (\d+)(?:[-~](\d+))?", ln):
        n3 += 1
        a = int(m.group(1))
        b = int(m.group(2)) if m.group(2) else a
        if a < 1 or b > len(T):
            b3 += 1
            print("  본문#%-4d %-18s  ** 범위 벗어남 **" % (i, m.group(0)))
            continue
        print("  본문#%-4d %-18s  %d행: %s" % (i, m.group(0), a, T[a - 1].strip()[:60]))
        if b != a:
            print("  %-30s  %d행: %s" % ("", b, T[b - 1].strip()[:60]))
print("  범위를 벗어난 인용: %d곳" % b3)

print()
print("=" * 104)
print("인용 합계: log11 %d · eq %d · task-8 %d = %d곳, 범위 벗어남 %d곳"
      % (n1, n2, n3, n1 + n2 + n3, b1 + b2 + b3))

print()
print("[자기 서술 숫자 대조] — 본문이 스스로 센 수를 원본에서 다시 센다")
print("-" * 104)
eq3b = [l for l in E[1:] if ",CH-3B," in l]
print("  CH-3B 이벤트: 원본 %d행 · 근거 로그가 인쇄한 합계 9 · 본문 표 9행  -> %s"
      % (len(eq3b), "일치" if len(eq3b) == 9 else "불일치"))
types = {}
for l in E[1:]:
    f = l.split(",")
    types[f[2]] = types.get(f[2], 0) + 1
want = {"CLEAN": 25, "CAL": 6, "PM": 6, "ALARM": 5, "PART": 4, "RECIPE": 2}
print("  event_type 별 원본 행 수: %s (합 %d)"
      % (" · ".join("%s %d" % (k, types[k]) for k in sorted(types)), sum(types.values())))
print("  본문 종류별 표의 건수(창부족 4건은 CLEAN 에서 뺐다): ALARM 5 · CAL 6 · CLEAN 21+4=25 · PART 4 · PM 6 · RECIPE 2 -> %s"
      % ("일치" if types == want else "불일치"))
sh = [l for l in E[1:] if "SH-2200" in l]
print("  SH-2200 이 든 원본 행: %d건 -> %s"
      % (len(sh), " | ".join(x.split(",")[0] + " " + x.split(",")[1] for x in sh)))
slash = [l for l in E[1:] if "/" in l.split(",")[0]]
print("  날짜에 슬래시가 든 원본 행: %d건 -> %s" % (len(slash), slash[0].split(",")[0] if slash else "없음"))
blank = [l for l in E[1:] if l.split(",")[5] == ""]
print("  worker 가 빈 원본 행: %d건" % len(blank))
