---
room: 수율개선-2026q3
task: 6
kind: report
title: 작업 6 재보고 — 반려 사유 둘(t 값 풀이·인과 단정)을 고쳐 다시 냄
created: 2026-09-08
updated: 2026-09-08
aliases: 작업6재보고, task-6-report-2, 반려반영보고, reporter재보고, 2차보고
tags: 보고, 재보고, 작업6, reporter, 반려반영, 수율, CH-3B, 파티클
sources: reporter/task-6-yield-drop-report.md, reporter/task-6-report.md, analyst/task-8-chamber-yield-drop.md#행 1-204, analyst/task-2-evidence.log#행 77-78, analyst/task-5-evidence.log#행 1-109, archivist/index.md#행 23
status: valid
supersedes: reporter/task-6-report.md
---

작업: 6
결론: 반려 사유 둘을 같은 파일에서 고쳐 다시 낸다 — 47행의 Welch t 풀이를 사실에 맞게 바꾸고, 83행의 인과 단정을 상관이 받쳐 주는 데까지 낮췄다. 수치·구조·나머지 문장은 손대지 않았다.
근거: 고침 1은 t 가 견주는 대상이 하루하루 흔들림이 아니라 28일씩 묶은 평균의 흔들림임을 밝히고, 하루치 표준편차 전 0.62%p·후 0.58%p 를 analyst/task-2-evidence.log#행 77-78 에서 인용해 두 눈금의 차이를 드러냈다(그 로그는 archivist/index.md#행 23 에 status valid 이고 최신 판도 sources 로 쓴다 — sources 에 더했다). 고침 2는 "수율 자체는 불량 개수가 결정한다"를 "수율과 불량 개수는 거의 그대로 맞물려 움직인다"로 바꿔 상관계수 -0.91~-0.98 안에 넣었다. 두 자리에 무엇을 왜 고쳤는지 〔고침 1〕·〔고침 2〕 한 줄씩 붙였다.
내가 정한 것: 새 판을 만들지 않고 같은 파일 reporter/task-6-yield-drop-report.md 를 고쳤다(아직 통과하지 않은 산출물이라는 지시에 따랐다). 보고 원문은 불변이므로 앞 보고 reporter/task-6-report.md 는 고치지 않고 status 만 void 로 바꾸고, 이 파일을 task-6-report-2.md 로 새로 냈다. 인용 수를 세는 법은 "머리말 아래 본문에서 분석#·근거#·검토# 표기와 전체 경로 인용을 정규식으로 뽑아 센다"로 정했고, 그 법으로 등장 59곳·고유 47곳이다(고침 반영 뒤).
못 확인한 것: 앞 보고에서 "인용 39곳"이라 한 것은 틀렸다 — task-8 이전 때 행 번호를 확인한 목록의 길이였지 보고서의 인용 수가 아니었다. 07-29 에 무엇이 있었는지는 여전히 이 데이터로 알 수 없어 원인 문장 셋은 추정으로 둔다. 방 저장소에 원격이 없어 커밋은 로컬에만 있다.
결과물: reporter/task-6-yield-drop-report.md (고침 1·2 반영)
