# -*- coding: utf-8 -*-
"""
task-16 분석 스크립트
재현: cd /Users/byunjungwon/Dev/my-project-04/crew-workspace/rooms/수율개선-2026q3/analyst
      python3 task-16-analysis.py > task-16-evidence.log
표준 라이브러리만 쓴다 (csv, math, statistics, unicodedata, datetime). 난수를 쓰지 않는다.
원본 CSV 세 개는 읽기 전용("r")으로만 연다. 이 스크립트는 어떤 파일도 열어 쓰지 않는다.
"""

import csv
import math
import statistics
import unicodedata
from datetime import date, timedelta

# ---------------------------------------------------------------- 경로
BASE = "/Users/byunjungwon/Dev/my-project-04/crew-workspace/rooms/수율개선-2026q3"
INS_PATH = (BASE + "/archivist/inbox/2026-09-09-part-incoming-inspection/"
            "28d181e9-647f-4b69-8fe7-554982ecd8de-part_incoming_inspection.csv")
YL_PATH = (BASE + "/archivist/inbox/2026-09-08-yield-by-lot/"
           "44cdd855-be6e-4b66-a014-e7eb3a056769-yield_by_lot.csv")
EQ_PATH = (BASE + "/archivist/inbox/2026-09-08-equipment-history/"
           "423efc74-8819-445a-bb81-90ca388034fd-equipment_history.csv")

DATA_START = date(2026, 7, 1)
DATA_END = date(2026, 8, 25)
CHAMBERS = ["CH-1A", "CH-1B", "CH-2A", "CH-2B", "CH-3A", "CH-3B"]
WS = [3, 5, 7, 10, 14]
MIN_LOTS = 4          # 한쪽 창에 이보다 적으면 창부족


# ---------------------------------------------------------------- 출력 도우미
def dw(s):
    """동아시아 전각 문자를 2칸으로 세는 표시 폭."""
    n = 0
    for ch in str(s):
        n += 2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1
    return n


def padr(s, n):
    s = str(s)
    return s + " " * max(0, n - dw(s))


def padl(s, n):
    s = str(s)
    return " " * max(0, n - dw(s)) + s


def sec(num, title):
    print("")
    print("=" * 118)
    print("[%d] %s" % (num, title))
    print("=" * 118)


def prow(cells, widths, aligns):
    out = []
    for c, w, a in zip(cells, widths, aligns):
        out.append(padl(c, w) if a == "r" else padr(c, w))
    print(" ".join(out).rstrip())


def rule(widths):
    print(" ".join("-" * w for w in widths))


def f2(x):
    return "n/a" if x is None else "%.2f" % x


def f3(x):
    return "n/a" if x is None else "%.3f" % x


def f4(x):
    return "n/a" if x is None else "%.4f" % x


def md(d):
    return "-" if d is None else d.strftime("%m-%d")


# ---------------------------------------------------------------- 통계
def mean(xs):
    return sum(xs) / len(xs) if xs else None


def welch(a, b):
    """(t, df). t = (mean(b) - mean(a)) / se, 분산 ddof=1, 자유도 Welch-Satterthwaite."""
    na, nb = len(a), len(b)
    if na < 2 or nb < 2:
        return None, None
    va = statistics.variance(a)
    vb = statistics.variance(b)
    se2 = va / na + vb / nb
    if se2 <= 0:
        return None, None
    t = (mean(b) - mean(a)) / math.sqrt(se2)
    den = (va / na) ** 2 / (na - 1) + (vb / nb) ** 2 / (nb - 1)
    df = (se2 ** 2) / den if den > 0 else None
    return t, df


def daterange(d1, d2):
    d = d1
    while d <= d2:
        yield d
        d += timedelta(days=1)


# ---------------------------------------------------------------- 날짜 파서
def pdate(s):
    """`-` 든 `/` 든 둘 다 받아 datetime.date 로 바꾼다. 빈칸이면 None."""
    s = (s or "").replace("\r", "").strip()
    if not s:
        return None
    return date.fromisoformat(s.replace("/", "-"))


# ---------------------------------------------------------------- 적재
INS_COLS = ["recv_date", "part_no", "serial", "supplier", "spec_item",
            "spec_max", "measured", "unit", "install_date", "chamber"]


def load_inspect():
    rows = []
    with open(INS_PATH, "r", encoding="utf-8", newline="") as fh:
        rd = csv.reader(fh)
        hdr = [c.replace("\r", "").strip() for c in next(rd)]
        i = 0
        for raw in rd:
            if not raw or all(c.replace("\r", "").strip() == "" for c in raw):
                continue
            i += 1
            f = [c.replace("\r", "").strip() for c in raw]
            r = dict(zip(INS_COLS, f))
            r["row"] = i
            r["raw"] = tuple(f)
            r["recv_d"] = pdate(r["recv_date"])
            r["install_d"] = pdate(r["install_date"])
            r["spec_max_f"] = float(r["spec_max"])
            r["measured_f"] = float(r["measured"])
            r["measured_um"] = (r["measured_f"] * 1000.0
                                if r["unit"] == "mm" else r["measured_f"])
            rows.append(r)
    return hdr, rows


def load_yield():
    rows = []
    with open(YL_PATH, "r", encoding="utf-8", newline="") as fh:
        rd = csv.DictReader(fh)
        for i, r in enumerate(rd, start=1):
            rows.append({
                "row": i,
                "lot_id": r["lot_id"].replace("\r", "").strip(),
                "date": pdate(r["date"]),
                "line": r["line"].replace("\r", "").strip(),
                "chamber": r["chamber"].replace("\r", "").strip(),
                "yield_pct": float(r["yield_pct"]),
                "defect_count": int(r["defect_count"]),
                "particle_defects": int(r["particle_defects"]),
            })
    return rows


def load_equip():
    """줄끝이 CRLF 이므로 모든 칸에서 CR 을 벗겨낸다."""
    rows = []
    with open(EQ_PATH, "r", encoding="utf-8", newline="") as fh:
        rd = csv.reader(fh)
        next(rd)
        i = 0
        for raw in rd:
            if not raw or all(c.replace("\r", "").strip() == "" for c in raw):
                continue
            i += 1
            f = [c.replace("\r", "").strip() for c in raw]
            rows.append({
                "row": i,
                "date": pdate(f[0]),
                "chamber": f[1],
                "event_type": f[2],
                "detail": f[3],
                "duration_min": f[4],
                "worker": f[5],
            })
    return rows


INS_HDR, INS = load_inspect()
YL = load_yield()
EQ = load_equip()

BY_CD = {}
for r in YL:
    BY_CD.setdefault((r["chamber"], r["date"]), []).append(r)


def lots(chamber, d1, d2):
    out = []
    if d1 > d2:
        return out
    for d in daterange(d1, d2):
        out.extend(BY_CD.get((chamber, d), []))
    return out


def lots_all(d1, d2):
    out = []
    for r in YL:
        if d1 <= r["date"] <= d2:
            out.append(r)
    return out


def pratio_P(ls):
    """정의 P = 구간의 particle_defects 합 / 구간의 defect_count 합."""
    dc = sum(x["defect_count"] for x in ls)
    if dc == 0:
        return None
    return sum(x["particle_defects"] for x in ls) / dc


def pratio_D(ls):
    """정의 D = 날마다 (그날의 particle 합 / defect 합) 을 내고 그 값들의 평균."""
    byday = {}
    for x in ls:
        byday.setdefault(x["date"], []).append(x)
    vals = []
    for d in sorted(byday):
        v = pratio_P(byday[d])
        if v is not None:
            vals.append(v)
    return mean(vals) if vals else None


# ---------------------------------------------------------------- 머리말
print("task-16 근거 로그 — 부품 입고검사(INSPECT) · 로트 수율(YIELD) · 설비 이력(EQUIP) 되읽기 분석")
print("생성 스크립트: %s/analyst/task-16-analysis.py" % BASE)
print("입력 1 INSPECT: %s" % INS_PATH)
print("입력 2 YIELD  : %s" % YL_PATH)
print("입력 3 EQUIP  : %s" % EQ_PATH)
print("적재 결과: INSPECT 데이터 %d행 · YIELD 데이터 %d행 · EQUIP 데이터 %d행"
      % (len(INS), len(YL), len(EQ)))
print("공통 규약: 모든 표준편차와 Welch t 는 표본(ddof=1). 자유도는 Welch-Satterthwaite.")
print("공통 규약: 사건 (chamber, D) 의 창 W 는 전 창 D-W~D-1, 후 창 D+1~D+W 이고 당일 D 는 양쪽에서 뺀다.")
print("공통 규약: 창 평균은 로트 단위 yield_pct 의 평균이다(날짜 평균이 아니다). Δ = 후 평균 - 전 평균 (%p).")
print("공통 규약: 파티클 비율은 정의 P(합/합)와 정의 D(날마다 비율의 평균)를 언제나 나란히 낸다.")
print("데이터 기간: %s ~ %s" % (DATA_START.isoformat(), DATA_END.isoformat()))

# ================================================================ [1]
sec(1, "INSPECT 되읽기 검산")

serials = [r["serial"] for r in INS]
print("데이터 행 수                : %d" % len(INS))
print("서로 다른 serial 수         : %d" % len(set(serials)))

dups = []
for i in range(len(INS)):
    for j in range(i + 1, len(INS)):
        if INS[i]["raw"] == INS[j]["raw"]:
            dups.append((INS[i]["row"], INS[j]["row"]))
print("열 열 개가 모두 같은 행 쌍  : %d쌍" % len(dups))
if dups:
    for a, b in dups:
        rr = [x for x in INS if x["row"] == a][0]
        print("  - %d행 과 %d행 : %s" % (a, b, ",".join(rr["raw"])))
else:
    print("  - 해당 없음")

both = [r for r in INS if r["install_date"] and r["chamber"]]
one = [r for r in INS if bool(r["install_date"]) != bool(r["chamber"])]
none = [r for r in INS if not r["install_date"] and not r["chamber"]]
print("")
print("install_date 와 chamber 가 함께 찬 행 수 : %d" % len(both))
print("install_date 와 chamber 중 한쪽만 찬 행 수 : %d" % len(one))
print("install_date 와 chamber 가 둘 다 빈 행 수 : %d" % len(none))
print("합 검산: %d + %d + %d = %d (데이터 행 수 %d)"
      % (len(both), len(one), len(none), len(both) + len(one) + len(none), len(INS)))

print("")
print("함께 찬 행들의 표")
W1 = [8, 10, 9, 15, 15, 10, 8, 12, 8]
A1 = "rlllrrlll"
prow(["데이터행", "recv_date", "part_no", "serial", "spec_item",
      "measured", "unit", "install_date", "chamber"], W1, A1)
rule(W1)
for r in both:
    prow([r["row"], r["recv_date"], r["part_no"], r["serial"], r["spec_item"],
          r["measured"], r["unit"], r["install_date"], r["chamber"]], W1, A1)
inst_keys = sorted(set((r["part_no"], r["serial"]) for r in both))
print("함께 찬 행 %d행이 가리키는 서로 다른 부품 낱개 수 : %d개 (기준: part_no + serial)"
      % (len(both), len(inst_keys)))
for k in inst_keys:
    print("  - %s / %s" % (k[0], k[1]))

supplier_blank = [r["row"] for r in INS if r["supplier"] == ""]
slash_recv = [r["row"] for r in INS if "/" in r["recv_date"]]
print("")
print("부수 검산: supplier 가 빈 행 = %s / recv_date 가 `/` 형식인 행 = %s"
      % (supplier_blank or "없음", slash_recv or "없음"))
print("읽는 법: 행 쌍이 완전히 같다는 것은 같은 낱개가 두 줄로 적혔다는 뜻이므로, 행 수(34)와 부품 낱개 수는 다르다. "
      "설치 기록은 install_date 와 chamber 가 함께 차 있을 때만 유효하다.")

# ================================================================ [2]
sec(2, "규격 대조 — 34행 전부")

W2 = [8, 8, 15, 12, 15, 10, 8, 9, 10, 12, 8]
A2 = "rllllrlrrll"
H2 = ["데이터행", "part_no", "serial", "supplier", "spec_item",
      "measured", "unit", "spec_max", "초과배수", "install_date", "chamber"]


def show(v):
    return v if v else "-"


def over_table(mode):
    """mode 'a' = 적힌 값 그대로, mode 'b' = mm 만 x1000 하여 um 로 맞춘 뒤."""
    out = []
    for r in INS:
        m = r["measured_f"] if mode == "a" else r["measured_um"]
        if m > r["spec_max_f"]:
            out.append((r, m))
    return out


for mode, label in (("a", "(2a) 적힌 값 그대로 measured 를 spec_max 와 견줌 (단위 무시)"),
                    ("b", "(2b) unit 이 mm 인 행만 measured x 1000 하여 um 로 맞춘 뒤 견줌")):
    print("")
    print(label)
    ov = over_table(mode)
    print("규격 초과(measured > spec_max) 행 수 : %d / 34" % len(ov))
    prow(H2 if mode == "a" else
         H2[:5] + ["measured", "unit", "spec_max", "초과배수", "install_date", "chamber"],
         W2, A2)
    rule(W2)
    for r, m in ov:
        mshow = r["measured"] if mode == "a" else ("%g" % m)
        prow([r["row"], r["part_no"], r["serial"], show(r["supplier"]), r["spec_item"],
              mshow, r["unit"], r["spec_max"], f4(m / r["spec_max_f"]),
              show(r["install_date"]), show(r["chamber"])], W2, A2)
    if mode == "b":
        print("(2b) 의 measured 칸은 um 로 맞춘 값이다. unit 칸은 원본 단위를 그대로 적었다.")
    with_ch = [1 for r, _ in ov if r["chamber"]]
    print("규격 초과 행 중 챔버에 달린 행 = %d / 달리지 않은 행 = %d"
          % (len(with_ch), len(ov) - len(with_ch)))

print("")
print("두 셈법에서 판정이 달라지는 행")
diff = []
for r in INS:
    ja = r["measured_f"] > r["spec_max_f"]
    jb = r["measured_um"] > r["spec_max_f"]
    if ja != jb:
        diff.append((r, ja, jb))
if diff:
    for r, ja, jb in diff:
        print("  - %d행 %s %s : measured %s %s (um 환산 %g) vs spec_max %s → (2a) %s / (2b) %s"
              % (r["row"], r["part_no"], r["serial"], r["measured"], r["unit"],
                 r["measured_um"], r["spec_max"],
                 "초과" if ja else "적합", "초과" if jb else "적합"))
else:
    print("  - 해당 없음")
print("읽는 법: (2a)와 (2b)의 차이는 단위를 맞추었는지 하나뿐이다. mm 로 적힌 행은 um 상한과 그대로 견주면 "
      "1000배 작은 값이 되어 언제나 적합으로 읽힌다. 초과배수는 measured/spec_max 이고 1보다 크면 초과다.")

# ================================================================ [3]
sec(3, "INSPECT 의 설치 기록 <-> EQUIP 의 PART 사건 짝짓기")

parts = [e for e in EQ if e["event_type"] == "PART"]
W3 = [8, 12, 8, 40, 12]
A3 = "rlllr"
prow(["EQ행", "date", "chamber", "detail", "duration_min"], W3, A3)
rule(W3)
for e in parts:
    prow([e["row"], e["date"].isoformat(), e["chamber"], e["detail"], e["duration_min"]], W3, A3)
print("EQUIP 의 event_type == 'PART' 행 수 : %d" % len(parts))

installs = []
seen = set()
for r in both:
    k = (r["part_no"], r["serial"], r["install_d"], r["chamber"])
    if k in seen:
        continue
    seen.add(k)
    installs.append(r)
print("INSPECT 의 설치된 서로 다른 부품 낱개 수 : %d" % len(installs))

pairs = []
matched_eq = set()
unmatched_ins = []
for r in installs:
    hit = [e for e in parts
           if e["date"] == r["install_d"] and e["chamber"] == r["chamber"]]
    if hit:
        for e in hit:
            pairs.append((r, e))
            matched_eq.add(e["row"])
    else:
        unmatched_ins.append(r)
unmatched_eq = [e for e in parts if e["row"] not in matched_eq]

print("")
print("짝지은 쌍 수                        : %d" % len(pairs))
print("EQUIP PART 사건 중 짝을 못 찾은 수  : %d" % len(unmatched_eq))
print("INSPECT 설치 기록 중 짝 못 찾은 수  : %d" % len(unmatched_ins))
for e in unmatched_eq:
    print("  - 짝 없는 EQUIP PART: %s %s %s" % (e["date"].isoformat(), e["chamber"], e["detail"]))
for r in unmatched_ins:
    print("  - 짝 없는 INSPECT 설치: %s %s %s %s"
          % (r["install_date"], r["chamber"], r["part_no"], r["serial"]))

print("")
print("짝지은 쌍마다 detail 안에 part_no 가 들어 있는지")
W3b = [12, 8, 10, 18, 8, 40]
A3b = "lllllr".replace("r", "l")
prow(["install_date", "chamber", "part_no", "serial", "포함", "EQUIP detail"], W3b, A3b)
rule(W3b)
misses = []
for r, e in pairs:
    ok = r["part_no"] in e["detail"]
    if not ok:
        misses.append((r, e))
    prow([r["install_date"], r["chamber"], r["part_no"], r["serial"],
          "참" if ok else "거짓", e["detail"]], W3b, A3b)
print("detail 에 part_no 가 들어 있지 않은 쌍 : %d" % len(misses))
for r, e in misses:
    print('  - %s %s %s / EQUIP detail 원문 = "%s"'
          % (r["install_date"], r["chamber"], r["part_no"], e["detail"]))
print("읽는 법: 짝짓기 열쇠는 (install_date, chamber) 두 칸뿐이고 part_no 는 짝짓기에 쓰지 않았다. "
      "'포함 거짓'은 두 기록이 같은 부품을 다른 이름으로 적었을 가능성을 가리키는 표시이지, 짝이 틀렸다는 판정이 아니다.")

# ================================================================ [4]
sec(4, "설치 사건마다 창을 바꿔 가며 Δ수율")

EVENTS = [
    ("E1", date(2026, 7, 15), "CH-1A", "PART HC-40"),
    ("E2", date(2026, 7, 28), "CH-3B", "PART SH-2200"),
    ("E3", date(2026, 8, 6), "CH-2B", "PART SH-2200"),
    ("E4", date(2026, 8, 18), "CH-1B", "PART OR-15"),
    ("E5", date(2026, 7, 28), "CH-3A", "PM 정기 정비 (대조군)"),
    ("E6", date(2026, 7, 21), "CH-2B", "PM 정기 정비 (대조군)"),
]


def win(chamber, d, W):
    b_want1, b_want2 = d - timedelta(days=W), d - timedelta(days=1)
    a_want1, a_want2 = d + timedelta(days=1), d + timedelta(days=W)
    b1, b2 = max(b_want1, DATA_START), min(b_want2, DATA_END)
    a1, a2 = max(a_want1, DATA_START), min(a_want2, DATA_END)
    cut = []
    if b_want1 < DATA_START or b_want2 > DATA_END:
        cut.append("전창잘림")
    if a_want2 > DATA_END or a_want1 < DATA_START:
        cut.append("후창잘림")
    b = lots(chamber, b1, b2)
    a = lots(chamber, a1, a2)
    res = {
        "n_b": len(b), "n_a": len(a),
        "rb": "%s~%s" % (md(b1), md(b2)) if b1 <= b2 else "없음",
        "ra": "%s~%s" % (md(a1), md(a2)) if a1 <= a2 else "없음",
        "cut": ",".join(cut) if cut else "-",
        "ok": len(b) >= MIN_LOTS and len(a) >= MIN_LOTS,
        "mb": None, "ma": None, "delta": None, "t": None, "df": None,
        "pb": None, "pa": None, "dp": None,
        "pbD": None, "paD": None,
    }
    if not res["ok"]:
        return res
    yb = [x["yield_pct"] for x in b]
    ya = [x["yield_pct"] for x in a]
    t, df = welch(yb, ya)
    pb, pa = pratio_P(b), pratio_P(a)
    res.update({"mb": mean(yb), "ma": mean(ya), "delta": mean(ya) - mean(yb),
                "t": t, "df": df, "pb": pb, "pa": pa,
                "dp": (pa - pb) if (pa is not None and pb is not None) else None,
                "pbD": pratio_D(b), "paD": pratio_D(a)})
    return res


print("사건 목록")
for tag, d, ch, kind in EVENTS:
    print("  %s = %s %s %s" % (tag, d.isoformat(), ch, kind))
print("창 규칙: 전 창 = D-W~D-1, 후 창 = D+1~D+W, 당일 D 는 양쪽에서 뺀다. "
      "데이터 기간(%s~%s) 밖은 잘라 쓴다. 한쪽 창 로트가 %d개 미만이면 창부족으로 적고 통계를 내지 않는다."
      % (DATA_START.isoformat(), DATA_END.isoformat(), MIN_LOTS))
print("")

W4 = [4, 10, 8, 3, 6, 6, 8, 8, 8, 9, 8, 8, 8, 13, 13, 10]
A4 = "rlllrrrrrrrrrllc".replace("c", "l")
H4 = ["사건", "날짜", "챔버", "W", "전로트", "후로트", "전평균", "후평균", "Δ",
      "Welch t", "정의P전", "정의P후", "ΔP", "전창범위", "후창범위", "잘림"]
prow(H4, W4, A4)
rule(W4)
for tag, d, ch, kind in EVENTS:
    for Wv in WS:
        r = win(ch, d, Wv)
        if r["ok"]:
            cells = [tag, d.isoformat(), ch, Wv, r["n_b"], r["n_a"],
                     f2(r["mb"]), f2(r["ma"]), f2(r["delta"]), f3(r["t"]),
                     f4(r["pb"]), f4(r["pa"]), f4(r["dp"]), r["rb"], r["ra"], r["cut"]]
        else:
            cells = [tag, d.isoformat(), ch, Wv, r["n_b"], r["n_a"],
                     "창부족", "창부족", "창부족", "창부족", "창부족", "창부족", "창부족",
                     r["rb"], r["ra"], r["cut"]]
        prow(cells, W4, A4)
    print("")

print("정의 D 로 낸 같은 창의 파티클 비율 (정의 P 와 나란히 두기 위한 표)")
W4d = [4, 3, 10, 10, 10, 10, 10, 10]
A4d = "rrrrrrrr"
prow(["사건", "W", "정의P전", "정의P후", "ΔP(정의P)", "정의D전", "정의D후", "ΔD(정의D)"], W4d, A4d)
rule(W4d)
for tag, d, ch, kind in EVENTS:
    for Wv in WS:
        r = win(ch, d, Wv)
        if r["ok"]:
            dd = (r["paD"] - r["pbD"]) if (r["paD"] is not None and r["pbD"] is not None) else None
            prow([tag, Wv, f4(r["pb"]), f4(r["pa"]), f4(r["dp"]),
                  f4(r["pbD"]), f4(r["paD"]), f4(dd)], W4d, A4d)
        else:
            prow([tag, Wv, "창부족", "창부족", "창부족", "창부족", "창부족", "창부족"], W4d, A4d)

print("")
print("W=7 만 모아 Δ 오름차순")
W4b = [4, 10, 8, 6, 6, 8, 8, 8, 9, 10, 22]
A4b = "rllrrrrrrrl"
prow(["순위", "날짜", "챔버", "전로트", "후로트", "전평균", "후평균", "Δ", "Welch t", "ΔP(정의P)", "사건"],
     W4b, A4b)
rule(W4b)
rows7 = []
for tag, d, ch, kind in EVENTS:
    r = win(ch, d, 7)
    rows7.append((tag, d, ch, kind, r))
ok7 = [x for x in rows7 if x[4]["ok"]]
ng7 = [x for x in rows7 if not x[4]["ok"]]
ok7.sort(key=lambda x: x[4]["delta"])
rank = 0
for tag, d, ch, kind, r in ok7:
    rank += 1
    prow([rank, d.isoformat(), ch, r["n_b"], r["n_a"], f2(r["mb"]), f2(r["ma"]),
          f2(r["delta"]), f3(r["t"]), f4(r["dp"]), "%s %s" % (tag, kind)], W4b, A4b)
for tag, d, ch, kind, r in ng7:
    prow(["-", d.isoformat(), ch, r["n_b"], r["n_a"], "창부족", "창부족", "창부족",
          "창부족", "창부족", "%s %s" % (tag, kind)], W4b, A4b)
print("W=7 에서 통계를 낸 사건 %d개 / 창부족 %d개" % (len(ok7), len(ng7)))
print("읽는 법: Δ 가 음수면 사건 뒤 창의 로트 평균 수율이 앞 창보다 낮았다는 뜻이다. Welch t 는 그 차이가 "
      "창 안의 흩어짐에 견주어 얼마나 큰지를 재는 수치이고, 부호는 Δ 와 같다. 대조군 두 사건(E5·E6)은 "
      "부품 교체가 없는 정비이므로, 같은 창 규칙에서 대조군이 어떻게 움직이는지와 견주어 읽는다.")

# ================================================================ [5]
sec(5, "규격 초과 부품이 달린 두 사건만 나란히")

E_A = ("E1", date(2026, 7, 15), "CH-1A", "HC-40", "resistance_dev", 6.1, 5.0, "pct")
E_B = ("E2", date(2026, 7, 28), "CH-3B", "SH-2200", "hole_dia_sd", 4.8, 3.0, "um")
for tag, d, ch, pn, si, mv, sm, un in (E_A, E_B):
    print("%s = %s %s %s : %s %g %s / 상한 %.1f · 초과배수 %s"
          % (tag, d.isoformat(), ch, pn, si, mv, un, sm, f4(mv / sm)))
print("")
W5 = [3, 8, 8, 9, 8, 8, 9, 8, 8, 10]
A5 = "rrrrrrrrrl"
prow(["W", "E1 전평균", "E1 후평균", "E1 Δ", "E1 t", "E2 전평균", "E2 후평균", "E2 Δ", "E2 t", "부호"],
     W5, A5)
rule(W5)
same_sign = 0
sign_ws = []
for Wv in WS:
    ra = win(E_A[2], E_A[1], Wv)
    rb = win(E_B[2], E_B[1], Wv)
    if ra["ok"] and rb["ok"]:
        sa = 1 if ra["delta"] > 0 else (-1 if ra["delta"] < 0 else 0)
        sb = 1 if rb["delta"] > 0 else (-1 if rb["delta"] < 0 else 0)
        if sa == sb and sa != 0:
            same_sign += 1
            sign_ws.append(Wv)
            mark = "같음"
        elif sa == sb:
            mark = "둘 다 0"
        else:
            mark = "다름"
        prow([Wv, f2(ra["mb"]), f2(ra["ma"]), f2(ra["delta"]), f3(ra["t"]),
              f2(rb["mb"]), f2(rb["ma"]), f2(rb["delta"]), f3(rb["t"]), mark], W5, A5)
    else:
        prow([Wv,
              "창부족" if not ra["ok"] else f2(ra["mb"]),
              "창부족" if not ra["ok"] else f2(ra["ma"]),
              "창부족" if not ra["ok"] else f2(ra["delta"]),
              "창부족" if not ra["ok"] else f3(ra["t"]),
              "창부족" if not rb["ok"] else f2(rb["mb"]),
              "창부족" if not rb["ok"] else f2(rb["ma"]),
              "창부족" if not rb["ok"] else f2(rb["delta"]),
              "창부족" if not rb["ok"] else f3(rb["t"]),
              "판정 못 함"], W5, A5)
print("두 사건의 Δ 부호가 같은 W 의 개수 : %d / %d (W = %s)"
      % (same_sign, len(WS), ",".join(str(x) for x in sign_ws) if sign_ws else "없음"))
print("읽는 법: 부호가 같다는 것은 두 사건 뒤에 수율이 같은 방향으로 움직였다는 뜻일 뿐이고, 움직임의 크기나 "
      "원인이 같다는 뜻은 아니다. 창 길이를 바꿔도 부호가 유지되는지가 그 방향이 창 고르기에 얼마나 기대는지를 보여 준다.")

# ================================================================ [6]
sec(6, "07-29 뒤 파티클이 CH-3B 에만 오른 것인가")

P1 = (date(2026, 7, 1), date(2026, 7, 28))
P2 = (date(2026, 7, 29), date(2026, 8, 25))
print("앞 구간 = %s~%s · 뒤 구간 = %s~%s"
      % (P1[0].isoformat(), P1[1].isoformat(), P2[0].isoformat(), P2[1].isoformat()))
print("")
W6 = [8, 6, 6, 9, 9, 10, 9, 9, 10, 9, 9, 9]
A6 = "lrrrrrrrrrrr"
prow(["챔버", "앞로트", "뒤로트", "P앞", "P뒤", "ΔP(정의P)", "D앞", "D뒤", "ΔD(정의D)",
      "수율앞", "수율뒤", "Δ수율"], W6, A6)
rule(W6)
sec6 = {}
for ch in CHAMBERS:
    l1 = lots(ch, P1[0], P1[1])
    l2 = lots(ch, P2[0], P2[1])
    p1, p2 = pratio_P(l1), pratio_P(l2)
    d1, d2 = pratio_D(l1), pratio_D(l2)
    y1 = mean([x["yield_pct"] for x in l1])
    y2 = mean([x["yield_pct"] for x in l2])
    dp = p2 - p1
    dd = d2 - d1
    dy = y2 - y1
    sec6[ch] = {"dp": dp, "dd": dd, "dy": dy}
    prow([ch, len(l1), len(l2), f4(p1), f4(p2), f4(dp), f4(d1), f4(d2), f4(dd),
          f2(y1), f2(y2), f2(dy)], W6, A6)

print("")
order = sorted(CHAMBERS, key=lambda c: sec6[c]["dp"], reverse=True)
print("ΔP(정의 P) 내림차순 (값이 큰 것이 1위 = 파티클 비율이 가장 많이 오른 챔버)")
for i, ch in enumerate(order, start=1):
    print("  %d위 %s  ΔP = %s" % (i, ch, f4(sec6[ch]["dp"])))
print("CH-3B 의 순위 : %d위 / %d개 챔버" % (order.index("CH-3B") + 1, len(CHAMBERS)))
pos = [c for c in CHAMBERS if sec6[c]["dp"] > 0]
neg = [c for c in CHAMBERS if sec6[c]["dp"] < 0]
print("ΔP 가 양수인 챔버 %d개 = %s / 음수인 챔버 %d개 = %s"
      % (len(pos), ",".join(pos) if pos else "없음", len(neg), ",".join(neg) if neg else "없음"))
print("읽는 법: 'CH-3B 에만 올랐는가'는 ΔP 가 양수인 챔버가 CH-3B 하나뿐인지로 갈린다. 위 개수 줄이 그 답이다. "
      "정의 P 와 정의 D 의 값이 서로 다를 수 있으므로 어느 정의로 말하는지 늘 밝혀야 한다.")

# ================================================================ [7]
sec(7, "이월 정정 ① 의 재계산 — 열 이름을 가리기 위한 것")

RA = (date(2026, 7, 21), date(2026, 7, 28))
RB = (date(2026, 7, 1), date(2026, 7, 24))
la = lots("CH-3B", RA[0], RA[1])
lb = lots("CH-3B", RB[0], RB[1])
print("구간 A = %s~%s (CH-3B 로트만) · 로트 %d개" % (RA[0].isoformat(), RA[1].isoformat(), len(la)))
print("구간 B(기준선) = %s~%s (CH-3B 로트만) · 로트 %d개" % (RB[0].isoformat(), RB[1].isoformat(), len(lb)))
print("")
W7 = [12, 8, 12, 12, 12]
A7 = "lrrrr"
prow(["구간", "로트수", "정의 P", "정의 D", "평균 수율"], W7, A7)
rule(W7)
aP, aD = pratio_P(la), pratio_D(la)
bP, bD = pratio_P(lb), pratio_D(lb)
aY, bY = mean([x["yield_pct"] for x in la]), mean([x["yield_pct"] for x in lb])
prow(["A 07-21~07-28", len(la), f4(aP), f4(aD), f2(aY)], W7, A7)
prow(["B 07-01~07-24", len(lb), f4(bP), f4(bD), f2(bY)], W7, A7)
print("")
TARGET_A, TARGET_B = 0.1977, 0.1841
cands = [("정의 P", aP, bP), ("정의 D", aD, bD)]
hit = [nm for nm, va, vb in cands
       if round(va, 4) == TARGET_A and round(vb, 4) == TARGET_B]
print("대조 대상: 구간 A = %.4f · 구간 B = %.4f" % (TARGET_A, TARGET_B))
for nm, va, vb in cands:
    print("  %s : A = %s (%s) · B = %s (%s)"
          % (nm, f4(va), "일치" if round(va, 4) == TARGET_A else "불일치",
             f4(vb), "일치" if round(vb, 4) == TARGET_B else "불일치"))
if len(hit) == 1:
    print("못 박아 적는다: 0.1977(구간 A)·0.1841(구간 B)과 같은 값을 내는 것은 %s 이다." % hit[0])
elif len(hit) == 0:
    print("못 박아 적는다: 두 정의 어느 쪽도 0.1977·0.1841 을 내지 못했다 — 해당 없음.")
else:
    print("못 박아 적는다: 두 정의가 모두 같은 값을 냈다 (%s)." % ", ".join(hit))
print("읽는 법: 두 구간은 07-21~07-24 나흘이 겹치므로 서로 독립이 아니다. 이 절은 값의 크고 작음을 다투는 자리가 "
      "아니라, 앞선 문서에 적힌 숫자가 어느 정의의 열에서 나온 것인지를 가리는 자리다.")

# ================================================================ [8]
sec(8, "규격 초과가 아닌 채로 달린 부품 둘")

E8 = [
    (date(2026, 8, 6), "CH-2B", "SH-2200", "SH2200-A-1187", "hole_dia_sd", 2.1, 3.0, "um"),
    (date(2026, 8, 18), "CH-1B", "OR-15", "OR15-B-3301", "hardness_dev", 2.4, 3.0, "shoreA"),
]
for d, ch, pn, sn, si, mv, sm, un in E8:
    r = win(ch, d, 7)
    if r["ok"]:
        print("%s %s %s (%s %g %s / 상한 %.1f · 상한 대비 배수 %s) : W=7 전로트 %d · 후로트 %d · "
              "전평균 %s · 후평균 %s · Δ %s · Welch t %s · 창범위 %s / %s · 잘림 %s"
              % (d.isoformat(), ch, pn, si, mv, un, sm, f4(mv / sm),
                 r["n_b"], r["n_a"], f2(r["mb"]), f2(r["ma"]), f2(r["delta"]), f3(r["t"]),
                 r["rb"], r["ra"], r["cut"]))
    else:
        print("%s %s %s : W=7 창부족 (전로트 %d · 후로트 %d · 창범위 %s / %s)"
              % (d.isoformat(), ch, pn, r["n_b"], r["n_a"], r["rb"], r["ra"]))

print("")
print("SH-2200 행 전부의 measured 를 um 로 맞춘 값")
sh = [r for r in INS if r["part_no"] == "SH-2200"]
W8 = [8, 15, 10, 8, 12, 9, 9, 8]
A8 = "rlrlrrll"
prow(["데이터행", "serial", "measured", "unit", "um환산값", "spec_max", "판정", "chamber"], W8, A8)
rule(W8)
n_over = 0
for r in sh:
    ov = r["measured_um"] > r["spec_max_f"]
    if ov:
        n_over += 1
    prow([r["row"], r["serial"], r["measured"], r["unit"], "%g" % r["measured_um"],
          r["spec_max"], "초과" if ov else "적합", show(r["chamber"])], W8, A8)
print("SH-2200 행 수 = %d · 그중 um 환산 뒤 규격 초과인 행 수 = %d" % (len(sh), n_over))
print("읽는 법: 이 두 부품은 입고검사에서 상한을 넘지 않았다. 그러므로 이 절의 Δ 는 '규격 안의 부품을 갈았을 때 "
      "같은 창 규칙이 무엇을 내는가'의 비교값으로 읽는다. um 환산표는 단위가 섞인 행이 규격 대조 결과를 "
      "바꾸는 자리를 한눈에 두기 위한 것이다.")

# ================================================================ [9]
sec(9, "EQUIP 안에서 파티클과 닿는 사건이 언제 어느 챔버에서 일어났는가")

ETC = {}
for e in EQ:
    ETC[e["event_type"]] = ETC.get(e["event_type"], 0) + 1
W9a = [12, 8]
A9a = "lr"
prow(["event_type", "행 수"], W9a, A9a)
rule(W9a)
for k in sorted(ETC):
    prow([k, ETC[k]], W9a, A9a)
rule(W9a)
prow(["합계", sum(ETC.values())], W9a, A9a)
print("검산: %s = %d · EQUIP 데이터 행 수 = %d · 두 값이 %s"
      % (" + ".join("%d" % ETC[k] for k in sorted(ETC)), sum(ETC.values()), len(EQ),
         "같다" if sum(ETC.values()) == len(EQ) else "다르다"))

W9 = [6, 12, 8, 11, 40, 12]
A9 = "rllllr"
H9 = ["EQ행", "date", "chamber", "event_type", "detail", "duration_min"]


def eq_table(rows):
    prow(H9, W9, A9)
    rule(W9)
    for e in rows:
        prow([e["row"], e["date"].isoformat(), e["chamber"], e["event_type"],
              e["detail"], e["duration_min"]], W9, A9)


def has_particle(s):
    return ("파티클" in s) or ("particle" in s.lower())


print("")
print("detail 에 '파티클' 또는 'particle'(대소문자 무시)이 든 행 전부")
pt = [e for e in EQ if has_particle(e["detail"])]
eq_table(pt)
print("그 행 수 : %d (EQUIP 데이터 %d행 가운데)" % (len(pt), len(EQ)))
pt_ch = {}
for e in pt:
    pt_ch[e["chamber"]] = pt_ch.get(e["chamber"], 0) + 1
print("챔버별 개수 : %s" % " · ".join("%s %d건" % (c, pt_ch[c]) for c in sorted(pt_ch)))
pt_et = {}
for e in pt:
    pt_et[e["event_type"]] = pt_et.get(e["event_type"], 0) + 1
print("event_type 별 개수 : %s" % " · ".join("%s %d건" % (k, pt_et[k]) for k in sorted(pt_et)))

print("")
print("event_type == 'ALARM' 인 행 전부")
al = [e for e in EQ if e["event_type"] == "ALARM"]
eq_table(al)
al_pt = [e for e in al if has_particle(e["detail"])]
print("ALARM 행 수 = %d · 그중 detail 에 파티클이 든 행 = %d건" % (len(al), len(al_pt)))

print("")
print("event_type == 'CLEAN' 인 행을 duration_min 내림차순으로 세운 위 5줄")
cl = [e for e in EQ if e["event_type"] == "CLEAN"]
cl_sorted = sorted(cl, key=lambda e: (-int(e["duration_min"]), e["row"]))
eq_table(cl_sorted[:5])
print("CLEAN 행 수 = %d · 표에 인쇄한 줄 = %d" % (len(cl), min(5, len(cl_sorted))))
mx = max(int(e["duration_min"]) for e in cl)
cl_mx = [e for e in cl if int(e["duration_min"]) == mx]
print("duration_min 이 가장 큰 CLEAN : %d분 · %d건" % (mx, len(cl_mx)))
for e in cl_mx:
    print("  - EQ %d행 : %s %s (%s · %s분)"
          % (e["row"], e["date"].isoformat(), e["chamber"], e["detail"], e["duration_min"]))

print("")
print("CH-3B 의 모든 사건을 날짜순으로")
c3b = sorted([e for e in EQ if e["chamber"] == "CH-3B"], key=lambda e: (e["date"], e["row"]))
eq_table(c3b)
print("CH-3B 사건 행 수 : %d" % len(c3b))

print("")
print("date 가 2026-07-28 인 모든 사건 (챔버 무관)")
d728 = sorted([e for e in EQ if e["date"] == date(2026, 7, 28)], key=lambda e: (e["chamber"], e["row"]))
eq_table(d728)
print("2026-07-28 사건 행 수 : %d" % len(d728))
print("읽는 법: 이 절은 EQUIP 의 detail 글자와 event_type 만으로 세었다. 'detail 에 파티클이라는 낱말이 들어 있다'는 "
      "적는 사람이 그 낱말을 골랐다는 뜻이지, 그 사건이 파티클과 관계가 있고 다른 사건은 없다는 뜻이 아니다. "
      "위 개수는 세어 본 값이고, 무엇을 뜻하는지는 이 로그가 정하지 않는다.")

# ================================================================ [10]
sec(10, "공급사 갈래 — 규격 초과가 공급사에 쏠려 있는가")


def over2b(r):
    return r["measured_um"] > r["spec_max_f"]


def sup_key(r):
    return r["supplier"] if r["supplier"] else "(빈칸)"


def dedupe(rows):
    """part_no + serial 로 중복을 없앤다. 먼저 나온 행을 남긴다."""
    out, seen = [], set()
    for r in rows:
        k = (r["part_no"], r["serial"])
        if k in seen:
            continue
        seen.add(k)
        out.append(r)
    return out


W10 = [14, 12, 12, 12]
A10 = "lrrr"


def sup_breakdown(rows, c1, c2):
    keys = sorted(set(sup_key(r) for r in rows))
    prow(["supplier", c1, c2, "초과 비율"], W10, A10)
    rule(W10)
    tot, tov = 0, 0
    per = {}
    for k in keys:
        sub = [r for r in rows if sup_key(r) == k]
        ov = [r for r in sub if over2b(r)]
        tot += len(sub)
        tov += len(ov)
        per[k] = (len(sub), len(ov))
        prow([k, len(sub), len(ov), f4(len(ov) / len(sub))], W10, A10)
    rule(W10)
    prow(["합계", tot, tov, f4(tov / tot) if tot else "n/a"], W10, A10)
    return tot, tov, per


print("판정 기준: (2b) — unit 이 mm 인 행만 measured x 1000 하여 um 로 맞춘 뒤 spec_max 와 견준다.")
print("supplier 가 빈 행은 '(빈칸)' 이라는 갈래로 따로 한 줄에 적는다.")
print("")
print("(10a) 34행 전부 · 행 기준")
tot_a, tov_a, per_a = sup_breakdown(INS, "전체 행수", "초과 행수")
print("검산: 행 기준 합 = %d (기대값 34 · %s)" % (tot_a, "같다" if tot_a == 34 else "다르다"))

INS_U = dedupe(INS)
BYKEY = {}
for r in INS:
    BYKEY.setdefault((r["part_no"], r["serial"]), []).append(r)
conflict = [k for k in sorted(BYKEY) if len(set(sup_key(x) for x in BYKEY[k])) > 1]
print("")
print("(10b) 34행을 part_no + serial 로 중복 제거한 뒤 · 낱개 기준")
print("중복 제거로 빠진 행 수 = %d · 한 낱개 안에서 supplier 가 엇갈리는 낱개 수 = %d"
      % (len(INS) - len(INS_U), len(conflict)))
tot_b, tov_b, per_b = sup_breakdown(INS_U, "전체 낱개수", "초과 낱개수")
print("검산: 낱개 기준 합 = %d (기대값 33 · %s)" % (tot_b, "같다" if tot_b == 33 else "다르다"))

print("")
print("행 기준과 낱개 기준의 수가 갈리는 자리")
gap = []
for k in sorted(set(list(per_a.keys()) + list(per_b.keys()))):
    a = per_a.get(k, (0, 0))
    b = per_b.get(k, (0, 0))
    if a != b:
        gap.append((k, a, b))
if gap:
    for k, a, b in gap:
        print("  - %s : 행 기준 전체 %d·초과 %d → 낱개 기준 전체 %d·초과 %d (전체 %+d · 초과 %+d)"
              % (k, a[0], a[1], b[0], b[1], b[0] - a[0], b[1] - a[1]))
else:
    print("  - 해당 없음")

SH10 = [r for r in INS if r["part_no"] == "SH-2200"]
SH10_U = dedupe(SH10)
print("")
print("(10c) SH-2200 %d행만 · 행 기준" % len(SH10))
tot_c, tov_c, per_c = sup_breakdown(SH10, "전체 행수", "초과 행수")
print("")
print("(10d) SH-2200 을 part_no + serial 로 중복 제거한 뒤 · 낱개 기준")
tot_d, tov_d, per_d = sup_breakdown(SH10_U, "전체 낱개수", "초과 낱개수")
print("검산: SH-2200 행 기준 합 = %d · 낱개 기준 합 = %d · 중복 제거로 빠진 행 수 = %d"
      % (tot_c, tot_d, tot_c - tot_d))
print("읽는 법: '초과 비율'은 그 공급사의 행(또는 낱개) 가운데 (2b)에서 상한을 넘은 것의 몫이다. 갈래마다 분모가 "
      "몇 안 되므로 비율의 크고 작음은 한두 행에 크게 흔들린다. 분모를 함께 읽어야 한다. supplier 가 빈 행은 "
      "공급사를 모르는 것이지 공급사가 없는 것이 아니다.")

# ================================================================ [11]
sec(11, "입고에서 설치까지 걸린 날 수")

W11 = [18, 10, 14, 14, 12, 10, 14]
A11 = "lllllrl"
prow(["serial", "part_no", "recv_date 원본", "recv_date 정규화", "install_date",
      "사이 날 수", "(2b) 규격 초과"], W11, A11)
rule(W11)
gaps = []
for r in installs:
    g = (r["install_d"] - r["recv_d"]).days
    gaps.append(g)
    prow([r["serial"], r["part_no"], r["recv_date"], r["recv_d"].isoformat(),
          r["install_d"].isoformat(), g, "초과" if over2b(r) else "적합"], W11, A11)
print("낱개 수 = %d" % len(installs))
print("")
print("사이 날 수의 최소 = %d · 최대 = %d · 중앙값 = %s"
      % (min(gaps), max(gaps), ("%g" % statistics.median(gaps))))
print("값 목록(위 표 차례대로) : %s" % ", ".join(str(g) for g in gaps))
raw_slash = [r["serial"] for r in installs if "/" in r["recv_date"]]
print("recv_date 원본이 `/` 형식이라 정규화한 낱개 : %s"
      % (", ".join(raw_slash) if raw_slash else "없음"))
print("읽는 법: 사이 날 수는 install_date - recv_date 이고 두 날이 같으면 0 이다. 값이 넷뿐이므로 중앙값은 "
      "가운데 두 값의 평균이다. 이 수는 입고와 설치 사이의 달력 날짜 차이일 뿐, 그동안 부품이 어디에 있었는지는 "
      "이 데이터로 알 수 없다.")

# ================================================================ [12]
sec(12, "07-29 뒤 늘어난 불량이 어떤 종류인가 — 파티클 불량과 그 밖의 불량을 갈라 본다")

print("정의: 파티클불량 = particle_defects · 그밖불량 = defect_count - particle_defects.")


def other_def(x):
    return x["defect_count"] - x["particle_defects"]


neg_p = [x for x in YL if x["particle_defects"] < 0]
neg_o = [x for x in YL if other_def(x) < 0]
print("particle_defects 가 음수인 행 = %d · 그밖불량이 음수인 행 = %d (YIELD 데이터 %d행 가운데)"
      % (len(neg_p), len(neg_o), len(YL)))
for x in neg_p + neg_o:
    print("  - 음수 행: %s %s %s defect_count=%d particle_defects=%d"
          % (x["lot_id"], x["date"].isoformat(), x["chamber"],
             x["defect_count"], x["particle_defects"]))
if not neg_p and not neg_o:
    print("  - 음수인 행 없음 (두 값 모두 0건)")

print("")
print("앞 구간 = %s~%s · 뒤 구간 = %s~%s · 모든 평균은 로트당 평균이다."
      % (P1[0].isoformat(), P1[1].isoformat(), P2[0].isoformat(), P2[1].isoformat()))
W12 = [8, 6, 6, 9, 9, 8, 9, 9, 8, 9, 9, 8, 12]
A12 = "lrrrrrrrrrrrr"
prow(["챔버", "앞로트", "뒤로트",
      "전체앞", "전체뒤", "Δ전체",
      "파티클앞", "파티클뒤", "Δ파티클",
      "그밖앞", "그밖뒤", "Δ그밖",
      "Δ파티클/Δ전체"], W12, A12)
rule(W12)
share_na = []
for ch in CHAMBERS:
    l1 = lots(ch, P1[0], P1[1])
    l2 = lots(ch, P2[0], P2[1])
    d1 = mean([x["defect_count"] for x in l1])
    d2 = mean([x["defect_count"] for x in l2])
    p1_ = mean([x["particle_defects"] for x in l1])
    p2_ = mean([x["particle_defects"] for x in l2])
    o1 = mean([other_def(x) for x in l1])
    o2 = mean([other_def(x) for x in l2])
    dd, dp, do = d2 - d1, p2_ - p1_, o2 - o1
    if dd > 0:
        sh = f4(dp / dd)
    else:
        sh = "해당 없음"
        share_na.append(ch)
    prow([ch, len(l1), len(l2), f2(d1), f2(d2), f2(dd),
          f2(p1_), f2(p2_), f2(dp), f2(o1), f2(o2), f2(do), sh], W12, A12)
print("Δ전체(Δdefect_count)가 0 이하여서 몫을 내지 않은 챔버 = %d개 (%s)"
      % (len(share_na), ",".join(share_na) if share_na else "없음"))

print("")
print("CH-3B 만 따로 — 앞뒤 두 구간의 로트 단위 값에 Welch t (분산 ddof=1, 자유도 Welch-Satterthwaite)")
b1 = lots("CH-3B", P1[0], P1[1])
b2 = lots("CH-3B", P2[0], P2[1])
W12b = [12, 8, 8, 10, 10, 10, 10, 10]
A12b = "lrrrrrrr"
prow(["값", "앞로트", "뒤로트", "앞평균", "뒤평균", "차이", "Welch t", "자유도"], W12b, A12b)
rule(W12b)
for name, fn in (("그밖불량", other_def),
                 ("파티클불량", lambda x: float(x["particle_defects"]))):
    a = [float(fn(x)) for x in b1]
    b = [float(fn(x)) for x in b2]
    t, df = welch(a, b)
    prow([name, len(a), len(b), f2(mean(a)), f2(mean(b)), f2(mean(b) - mean(a)),
          f3(t), f2(df)], W12b, A12b)

print("")
print("CH-3B 의 2026-07-25~08-02 아홉 날을 하루씩")
W12c = [12, 8, 10, 14, 16, 12]
A12c = "lrrrrr"
prow(["date", "로트수", "일평균 수율", "defect_count 합", "particle_defects 합", "그밖불량 합"],
     W12c, A12c)
rule(W12c)
D1, D2 = date(2026, 7, 25), date(2026, 8, 2)
n_days = 0
for d in daterange(D1, D2):
    ls = BY_CD.get(("CH-3B", d), [])
    n_days += 1
    if not ls:
        prow([d.isoformat(), 0, "해당 없음", "해당 없음", "해당 없음", "해당 없음"], W12c, A12c)
        continue
    prow([d.isoformat(), len(ls), f2(mean([x["yield_pct"] for x in ls])),
          sum(x["defect_count"] for x in ls),
          sum(x["particle_defects"] for x in ls),
          sum(other_def(x) for x in ls)], W12c, A12c)
print("인쇄한 날 수 = %d (07-25~08-02)" % n_days)
print("읽는 법: Δ 는 모두 뒤 구간 평균에서 앞 구간 평균을 뺀 값이고 단위는 로트당 개수다. "
      "'Δ파티클/Δ전체'는 늘어난 전체 불량 가운데 파티클 불량이 차지한 몫이며, 분모가 0 이하이면 몫이 뜻을 잃으므로 "
      "해당 없음으로 두었다. Welch t 두 줄은 같은 챔버·같은 두 구간에서 두 값이 각각 얼마나 움직였는지를 "
      "나란히 놓은 것이고, 어느 쪽이 원인인지를 정하지는 않는다.")

# ================================================================ 꼬리말
print("")
print("=" * 118)
print("이 로그를 만든 명령: cd %s/analyst && python3 task-16-analysis.py > task-16-evidence.log" % BASE)
print("이 스크립트는 결정적이다: 난수를 쓰지 않고 정렬 열쇠를 모두 못 박았으므로, 같은 입력 CSV 세 개에 "
      "언제 돌려도 이 로그와 같은 글자가 나온다.")
print("=" * 118)
