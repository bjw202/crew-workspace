#!/usr/bin/env python3
# task-22 인용 전수 대조 — 본문이 가리킨 행이 정말 그 자리인지, 본문 수치가 근거에 있는지 기계로 센다.
import re, sys
from collections import Counter

ROOM = "/Users/byunjungwon/Dev/my-project-04/crew-workspace/rooms/수율개선-2026q3"
DOC = ROOM + "/analyst/task-22-showerhead-replacement-effect.md"
LOG = ROOM + "/analyst/task-22-evidence.log"
INSPECT = ROOM + "/archivist/inbox/2026-09-09-part-incoming-inspection/28d181e9-647f-4b69-8fe7-554982ecd8de-part_incoming_inspection.csv"
ADDEND = ROOM + "/archivist/inbox/2026-09-09-yield-by-lot-addendum/fee7dd34-07cb-47a1-ab27-cb68fd3b59b5-yield_by_lot_addendum.csv"
T11 = ROOM + "/analyst/task-11-equipment-history-vs-yield.md"

doc = open(DOC, encoding="utf-8").read().split("\n")
log = open(LOG, encoding="utf-8").read().split("\n")
insp = open(INSPECT, encoding="utf-8").read().replace("\r", "").rstrip("\n").split("\n")[1:]
add = open(ADDEND, encoding="utf-8").read().replace("\r", "").rstrip("\n").split("\n")[1:]
t11 = open(T11, encoding="utf-8").read().split("\n")

TARGETS = {"log": (log, LOG), "insp": (insp, INSPECT), "add": (add, ADDEND), "대조": (t11, T11)}

print("=" * 116)
print(f"본문 {len(doc)}행 · log {len(log)}행 · insp 데이터 {len(insp)}행 · add 데이터 {len(add)}행 · 대조(task-11) {len(t11)}행")
print("=" * 116)

bad = 0
pat = re.compile(r"(log|insp|add|대조)#(\d+)(?:[-~·](\d+))?")
for tag in TARGETS:
    lines, path = TARGETS[tag]
    hits = []
    for i, l in enumerate(doc):
        for m in pat.finditer(l):
            if m.group(1) != tag:
                continue
            hits.append((i + 1, m.group(0), int(m.group(2)), int(m.group(3)) if m.group(3) else None))
    print(f"\n[{tag}] 인용 {len(hits)}곳 — 대상 {path.split('/')[-1]} ({len(lines)}행)")
    print("-" * 116)
    for src, txt, a, b in hits:
        end = b if b else a
        if a < 1 or end > len(lines):
            print(f"  !! 본문#{src}  {txt}  범위를 벗어남 (대상은 {len(lines)}행)")
            bad += 1
            continue
        first = lines[a - 1].strip()
        print(f"  본문#{src:<4d} {txt:<14s} {a}행: {first[:96]}")
    out = [h for h in hits if h[2] < 1 or (h[3] or h[2]) > len(lines)]
    print(f"  범위를 벗어난 인용: {len(out)}곳")

print("\n" + "=" * 116)
print("[수치 대조] 본문에 쓴 수치가 근거 로그 안에 그대로 있는가")
print("=" * 116)
body = "\n".join(doc)
nums = re.findall(r"(?<![\w.\-])\d+\.\d{3,4}(?![\d])", body)
logtext = "\n".join(log)
miss = [n for n in sorted(set(nums)) if n not in logtext]
print(f"  본문의 소수 셋째~넷째 자리 수치 {len(set(nums))}개 가운데 로그에 없는 것: {len(miss)}개")
for n in miss:
    where = [i + 1 for i, l in enumerate(doc) if n in l]
    print(f"    !! {n}  (본문#{where})")

print("\n[자기 서술 숫자 되세기] — 본문이 스스로 센 수를 원본에서 다시 센다")
print("-" * 116)
rows_add = [r.split(",") for r in add]
dup = Counter(tuple(r) for r in rows_add)
print(f"  부록 데이터 행: {len(add)} (본문 '109행') · 완전히 같은 행 짝: {sum(1 for v in dup.values() if v > 1)}쌍 (본문 '한 쌍')")
print(f"  서로 다른 lot_id: {len(set(r[0] for r in rows_add))} (본문 '108개')")
print(f"  빈 칸 수: {sum(1 for r in rows_add for c in r if c.strip() == '')} (본문 '한 곳')")
cl = [l for l in log if "세정 사건" in l]
print(f"  세정 사건 건수 줄: {cl[0].strip() if cl else '없음'} (본문이 함께 적은 좁힌 수 '27건')")
gap = [l for l in log if "설비 이력이 없는 날" in l]
print(f"  설비 이력 빈 날: {gap[0].strip()[:60] if gap else '없음'} (본문 '24일')")
comp = len(re.findall(r"^\| [①②③④] \|", body, re.M))
print(f"  9절 '남는 설명' 표의 행 수: {comp} (본문 '넷')")
kill = len(re.findall(r"^\| [^|]*(?:PM 240분|저절로 돌아왔다|파일이 바뀌어)[^|]*\|", body, re.M))
print(f"  9절 '물리쳐진 설명' 표의 행 수: {kill} (본문 '셋')")
rule = [l for l in log if "규칙 ① 에 드는 세정" in l]
print(f"  세정 건수(본문이 밝힌 규칙 그대로): {rule[0].strip() if rule else '없음'} (본문 '29건')")
print(f"  본문에서 [추정] 이 붙은 자리: {body.count('[추정]')}곳")

print("\n[전칭 문장 되세기] — '0건 · 하나뿐 · 넘은 것이 없다' 는 반례를 센다")
print("-" * 116)
over = [l for l in log if "+2.0%p 를 넘은 것" in l]
print(f"  {over[0].strip() if over else '없음'}")
five = [l for l in log if "다섯 챔버 Δ 의 최소~최대" in l]
print(f"  {five[0].strip() if five else '없음'} (본문 '-0.305 ~ +0.139')")
print(f"  본문이 쓴 '17배가 넘는다': 2.432 / 0.139 = {2.432 / 0.139:.2f}")
print(f"  본문이 쓴 파티클 '1.65배': 0.3084 / 0.1870 = {0.3084 / 0.1870:.2f}")
print(f"  본문이 쓴 회복 비율 67.7%: 2.432 / 3.594 = {2.432 / 3.594 * 100:.1f}%")
print(f"  본문이 쓴 파티클 회복 66.5%: 반올림한 P 로 다시 내면 (0.5488-0.3084)/(0.5488-0.1870) = "
      f"{(0.5488 - 0.3084) / (0.5488 - 0.1870) * 100:.1f}% — 로그 286행의 66.5% 는 반올림 전 합으로 낸 값이라 0.1%p 갈린다")
print(f"  본문이 쓴 '+6.2%': (5.1-4.8)/4.8 = {(5.1 - 4.8) / 4.8 * 100:.1f}%")
print(f"  본문이 쓴 '1.70배': 5.1/3.0 = {5.1 / 3.0:.2f} · '1.60배': 4.8/3.0 = {4.8 / 3.0:.2f}")

print("\n" + "=" * 116)
print(f"범위를 벗어난 인용 합계: {bad}곳 · 로그에 없는 수치: {len(miss)}개")
print("=" * 116)
