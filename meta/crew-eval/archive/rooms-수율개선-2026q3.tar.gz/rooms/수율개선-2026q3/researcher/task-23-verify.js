// 작업 23 — analyst 작업 22 교차 검토. 원본 CSV 에서 처음부터 새로 구현한다.
// analyst/task-22-analysis.py 는 읽지도 돌리지도 않았다.
// 출력: researcher/task-23-evidence.log
const fs = require('fs');
const P = '/Users/byunjungwon/Dev/my-project-04/crew-workspace/rooms/수율개선-2026q3/';
const IN = P + 'archivist/inbox/';
const F = {
  yield: IN + '2026-09-08-yield-by-lot/44cdd855-be6e-4b66-a014-e7eb3a056769-yield_by_lot.csv',
  yadd: IN + '2026-09-09-yield-by-lot-addendum/fee7dd34-07cb-47a1-ab27-cb68fd3b59b5-yield_by_lot_addendum.csv',
  eq: IN + '2026-09-08-equipment-history/423efc74-8819-445a-bb81-90ca388034fd-equipment_history.csv',
  eadd: IN + '2026-09-09-equipment-history-addendum/0712fc84-e908-4582-992b-63aebebca36d-equipment_history_addendum.csv',
  insp: IN + '2026-09-09-part-incoming-inspection/28d181e9-647f-4b69-8fe7-554982ecd8de-part_incoming_inspection.csv',
  re: IN + '2026-09-09-part-remeasure/521f2858-a080-4f86-b6a2-e5baf2b00d33-part_remeasure.csv',
};
const out = [];
const say = s => out.push(s);
const hr = t => { say(''); say('='.repeat(116)); say(t); say('='.repeat(116)); };
const sub = t => { say(''); say(t); say('-'.repeat(116)); };
const f = (x, d = 3) => (x === null || x === undefined || Number.isNaN(x)) ? 'NA' : x.toFixed(d);

function readCsv(path) {
  const raw = fs.readFileSync(path, 'utf8');
  const lines = raw.split('\n').map(l => l.replace(/\r$/, ''));
  while (lines.length && lines[lines.length - 1] === '') lines.pop();
  const head = lines[0].split(',');
  const rows = lines.slice(1).map((l, i) => {
    const c = l.split(',');
    const o = { _n: i + 1, _raw: l };
    head.forEach((h, j) => o[h] = c[j] === undefined ? '' : c[j]);
    o._fields = c.length;
    return o;
  });
  return { head, rows, raw, nLines: lines.length };
}

// ---------- [0] 파일 모양 ----------
hr('[0] 원본 여섯의 모양 — 내가 따로 센다');
for (const k of Object.keys(F)) {
  const d = readCsv(F[k]);
  const cr = (d.raw.match(/\r/g) || []).length;
  say(`  ${k.padEnd(6)} 데이터 ${String(d.rows.length).padStart(3)}행 · 열 ${d.head.length} · CR ${String(cr).padStart(3)}개 (${cr >= d.nLines - 1 ? 'CRLF' : 'LF'})`);
}

const Y0 = readCsv(F.yield), YA = readCsv(F.yadd);
const EQ = readCsv(F.eq), EA = readCsv(F.eadd);
const INSP = readCsv(F.insp), RE = readCsv(F.re);

// ---------- [1] 부록 109행 자료 검사 ----------
hr('[1] 부록 109행 자료 검사 — analyst 의 "흠 넷"을 내가 다시 센다');
say(`  머리글: ${YA.head.join(',')}`);
say(`  데이터 행 수: ${YA.rows.length} (앞 원본 ${Y0.rows.length}행)`);
const fieldDist = {};
YA.rows.forEach(r => fieldDist[r._fields] = (fieldDist[r._fields] || 0) + 1);
say(`  필드 수 분포: ${JSON.stringify(fieldDist)}`);

sub('1-1 완전히 같은 행');
const seenRaw = {};
YA.rows.forEach(r => (seenRaw[r._raw] = seenRaw[r._raw] || []).push(r._n));
const dupRaw = Object.entries(seenRaw).filter(([, v]) => v.length > 1);
say(`  완전히 같은 행이 있는 짝: ${dupRaw.length}쌍`);
dupRaw.forEach(([k, v]) => say(`    ${v.length}회: ${k}   (데이터 행 ${JSON.stringify(v)})`));

sub('1-2 lot_id 유일성 · 앞 원본과의 겹침');
const idc = {};
YA.rows.forEach(r => idc[r.lot_id] = (idc[r.lot_id] || 0) + 1);
const dupId = Object.entries(idc).filter(([, v]) => v > 1);
say(`  서로 다른 lot_id ${Object.keys(idc).length} / 데이터 행 ${YA.rows.length} · 두 번 나온 것 ${JSON.stringify(Object.fromEntries(dupId))}`);
const id0 = new Set(Y0.rows.map(r => r.lot_id));
const overlap = Object.keys(idc).filter(x => id0.has(x));
say(`  앞 원본과 겹치는 lot_id: ${overlap.length}개 ${JSON.stringify(overlap)}`);
const dupId0 = Object.entries(Y0.rows.reduce((a, r) => (a[r.lot_id] = (a[r.lot_id] || 0) + 1, a), {})).filter(([, v]) => v > 1);
say(`  [추가] 앞 원본 672행 안의 lot_id 중복: ${dupId0.length}건 ${JSON.stringify(dupId0)}`);
const dupRaw0 = Object.entries(Y0.rows.reduce((a, r) => ((a[r._raw] = a[r._raw] || []).push(r._n), a), {})).filter(([, v]) => v.length > 1);
say(`  [추가] 앞 원본 672행 안의 완전 중복 행: ${dupRaw0.length}쌍`);

sub('1-3 빈 칸 · 표기 · 범위');
const blanks = {};
YA.head.forEach(h => { const w = YA.rows.filter(r => r[h] === '').map(r => r._n); if (w.length) blanks[h] = w; });
say(`  빈 칸이 있는 열: ${JSON.stringify(blanks)}`);
Object.values(blanks).flat().forEach(n => say(`    데이터 ${n}행: ${YA.rows[n - 1]._raw}`));
const slash = YA.rows.filter(r => r.date.includes('/')).map(r => [r._n, r.date, r.chamber]);
const lower = YA.rows.filter(r => r.chamber !== r.chamber.toUpperCase()).map(r => [r._n, r.chamber, r.date]);
say(`  date 구분자가 '/' 인 행: ${JSON.stringify(slash)}`);
say(`  chamber 가 대문자가 아닌 행: ${JSON.stringify(lower)}`);
const ys = YA.rows.map(r => +r.yield_pct), ds = YA.rows.map(r => +r.defect_count);
const pv = YA.rows.filter(r => r.particle_defects !== '').map(r => +r.particle_defects);
say(`  yield ${Math.min(...ys)}~${Math.max(...ys)} · defect ${Math.min(...ds)}~${Math.max(...ds)} · particle ${Math.min(...pv)}~${Math.max(...pv)} (값 있는 행 ${pv.length})`);
say(`  particle > defect 인 행: ${YA.rows.filter(r => r.particle_defects !== '' && +r.particle_defects > +r.defect_count).length}개`);
say(`  line 숫자와 chamber 앞자리가 어긋난 행: ${YA.rows.filter(r => r.chamber.toUpperCase()[3] !== r.line).length}개`);
const negY = YA.rows.filter(r => !(+r.yield_pct > 0 && +r.yield_pct <= 100)).length;
say(`  [추가] yield 가 0~100 밖인 행: ${negY}개 · 숫자로 못 읽는 칸: ${YA.rows.filter(r => Number.isNaN(+r.yield_pct) || Number.isNaN(+r.defect_count)).length}개`);

// ---------- 정규화 ----------
function norm(r) {
  return {
    lot: r.lot_id, date: r.date.replace(/\//g, '-'), line: r.line,
    ch: r.chamber.toUpperCase(), y: +r.yield_pct,
    d: +r.defect_count, p: r.particle_defects === '' ? null : +r.particle_defects,
    src: r._src, n: r._n, raw: r._raw,
  };
}
Y0.rows.forEach(r => r._src = 'orig'); YA.rows.forEach(r => r._src = 'add');

// 흠 넷의 처리를 손잡이로 둔다
// dup: 'drop'(뒤엣것 뺌) | 'keep'(넣음) | 'both'(두 행 다 뺌)
// low: 'fix'(대문자로) | 'drop'(그 행 뺌)
// slash: 'fix'(하이픈으로) | 'drop'
// blank: 'keepYield'(수율엔 넣고 비율에서만 뺌) | 'drop'(행 통째 뺌)
function build(opt) {
  const o = Object.assign({ dup: 'drop', low: 'fix', slash: 'fix', blank: 'keepYield' }, opt);
  let rows = [...Y0.rows, ...YA.rows];
  // 완전 중복 처리 (부록 안)
  if (o.dup === 'drop') { const s = new Set(); rows = rows.filter(r => { if (r._src !== 'add') return true; if (s.has(r._raw)) return false; s.add(r._raw); return true; }); }
  if (o.dup === 'both') { const bad = new Set(dupRaw.map(([k]) => k)); rows = rows.filter(r => !(r._src === 'add' && bad.has(r._raw))); }
  if (o.low === 'drop') rows = rows.filter(r => r.chamber === r.chamber.toUpperCase());
  if (o.slash === 'drop') rows = rows.filter(r => !r.date.includes('/'));
  if (o.blank === 'drop') rows = rows.filter(r => r.particle_defects !== '');
  return rows.map(norm);
}
const D0 = build({});

hr('[2] 이어 붙인 시계열 — 기본 처리(중복 뺌·표기 맞춤·빈 칸은 수율에 넣음)');
say(`  이어 붙인 행 수: ${D0.length} (중복 넣으면 ${build({ dup: 'keep' }).length})`);
const days = [...new Set(D0.map(r => r.date))].sort();
say(`  날짜 ${days[0]} ~ ${days[days.length - 1]} · 서로 다른 날 ${days.length}`);
const chc = {}; D0.forEach(r => chc[r.ch] = (chc[r.ch] || 0) + 1);
say(`  챔버별 행 수: ${JSON.stringify(chc)}`);
// 날짜 격자
function dateRange(a, b) { const r = []; const d = new Date(a + 'T00:00:00Z'), e = new Date(b + 'T00:00:00Z'); for (; d <= e; d.setUTCDate(d.getUTCDate() + 1)) r.push(d.toISOString().slice(0, 10)); return r; }
const allDays = dateRange(days[0], days[days.length - 1]);
say(`  달력상 날 수 ${allDays.length} · 수율 자료가 없는 날: ${JSON.stringify(allDays.filter(d => !days.includes(d)))}`);
const grid = {}; D0.forEach(r => { const k = r.date + '|' + r.ch; grid[k] = (grid[k] || 0) + 1; });
const notTwo = Object.entries(grid).filter(([, v]) => v !== 2);
say(`  (날,챔버) 칸이 2행이 아닌 자리: ${notTwo.length}곳 ${JSON.stringify(notTwo)}`);

// 설비 이력
const EV = [...EQ.rows, ...EA.rows].map(r => ({ date: r.date.replace(/\//g, '-'), ch: r.chamber.toUpperCase(), type: r.event_type, detail: r.detail, min: +r.duration_min, worker: r.worker, src: r._src }));
EQ.rows.forEach(r => r._src = 'orig'); EA.rows.forEach(r => r._src = 'add');
const evDays = [...new Set(EV.map(r => r.date))].sort();
say(`  설비 이력 행 수: ${EV.length} (앞 ${EQ.rows.length} + 부록 ${EA.rows.length}) · ${evDays[0]} ~ ${evDays[evDays.length - 1]}`);
const evAll = dateRange(evDays[0], evDays[evDays.length - 1]);
const empty = evAll.filter(d => !evDays.includes(d));
say(`  설비 이력 범위의 달력 날 ${evAll.length}일 · 이력이 없는 날 ${empty.length}일`);
say(`    ${JSON.stringify(empty)}`);
// 이어진 빈 날 묶음
const runs = []; let cur = [];
evAll.forEach(d => { if (!evDays.includes(d)) cur.push(d); else { if (cur.length) runs.push(cur); cur = []; } });
if (cur.length) runs.push(cur);
say(`  이어진 빈 날 묶음(2일 이상): ${JSON.stringify(runs.filter(r => r.length > 1).map(r => r[0] + '~' + r[r.length - 1] + '(' + r.length + '일)'))}`);
say(`  [추가] 수율 마지막 날 09-03 까지로 넓히면 빈 날은 ${dateRange(evDays[0], '2026-09-03').filter(d => !evDays.includes(d)).length}일이다`);

sub('2-1 CH-3B 에 적힌 사건 전부');
EV.filter(e => e.ch === 'CH-3B').sort((a, b) => a.date.localeCompare(b.date)).forEach(e => say(`  ${e.date} ${e.type.padEnd(7)} ${String(e.min).padStart(4)}분  ${e.detail}${e.worker ? '  [' + e.worker + ']' : '  [담당자 빈칸]'}`));

// ---------- [3] 구간 평균 ----------
const SEG = { A: ['2026-07-01', '2026-07-27'], B: ['2026-07-30', '2026-08-26'], C: ['2026-08-27', '2026-08-27'], D: ['2026-08-28', '2026-09-03'] };
const segOf = d => { for (const k of Object.keys(SEG)) if (d >= SEG[k][0] && d <= SEG[k][1]) return k; return null; };
const mean = a => a.reduce((x, y) => x + y, 0) / a.length;
const sd = a => { if (a.length < 2) return 0; const m = mean(a); return Math.sqrt(a.reduce((s, x) => s + (x - m) ** 2, 0) / (a.length - 1)); };
function welch(a, b) {
  const va = sd(a) ** 2 / a.length, vb = sd(b) ** 2 / b.length;
  const t = (mean(a) - mean(b)) / Math.sqrt(va + vb);
  const df = (va + vb) ** 2 / (va ** 2 / (a.length - 1) + vb ** 2 / (b.length - 1));
  return { t, df };
}
const CHS = ['CH-1A', 'CH-1B', 'CH-2A', 'CH-2B', 'CH-3A', 'CH-3B'];
function segYields(rows, ch, s) { return rows.filter(r => r.ch === ch && segOf(r.date) === s).map(r => r.y); }

hr('[3] 구간 평균과 교체 앞뒤 차이 — 다시 센 값 (analyst 값과 나란히)');
say('  구간 A 2026-07-01~07-27 · B 07-30~08-26 · C 08-27 · D 08-28~09-03 (07-28·07-29 는 어디에도 넣지 않음)');
sub('3-1 여섯 챔버 · 구간별 로트 수와 평균');
say('  챔버     A n/평균            B n/평균            C n/평균            D n/평균');
for (const c of CHS) {
  const s = ['A', 'B', 'C', 'D'].map(k => segYields(D0, c, k));
  say(`  ${c}  ` + s.map(a => `n=${String(a.length).padStart(2)} ${f(mean(a))}`.padEnd(20)).join(''));
}
sub('3-2 Δ = D − B · 그리고 D − A');
say('  챔버     B평균     D평균     Δ(%p)     Welch t      df      A평균     D−A(%p)');
const deltas = {};
for (const c of CHS) {
  const A = segYields(D0, c, 'A'), B = segYields(D0, c, 'B'), D = segYields(D0, c, 'D');
  const w = welch(D, B), w2 = welch(D, A);
  deltas[c] = mean(D) - mean(B);
  say(`  ${c}  ${f(mean(B))}  ${f(mean(D))}  ${(mean(D) - mean(B) >= 0 ? '+' : '') + f(mean(D) - mean(B))}    ${f(w.t)}   ${f(w.df, 2)}   ${f(mean(A))}   ${(mean(D) - mean(A) >= 0 ? '+' : '') + f(mean(D) - mean(A))}   (D−A t ${f(w2.t)} df ${f(w2.df, 2)})`);
}
const others = CHS.filter(c => c !== 'CH-3B').map(c => deltas[c]);
say(`  CH-3B 뺀 다섯의 Δ 범위: ${f(Math.min(...others))} ~ ${f(Math.max(...others))} · CH-3B 는 그 최대의 ${f(deltas['CH-3B'] / Math.max(...others), 1)}배`);
say(`  Δ 가 가장 큰 챔버: ${CHS.reduce((a, b) => deltas[a] > deltas[b] ? a : b)}`);

sub('3-3 CH-3B 네 구간 요약과 회복 비율');
for (const k of ['A', 'B', 'C', 'D']) {
  const a = segYields(D0, 'CH-3B', k);
  say(`  ${k}  n=${String(a.length).padStart(2)}  평균 ${f(a.length ? mean(a) : NaN)}  표준편차 ${f(sd(a))}  최소 ${f(Math.min(...a), 2)}  최대 ${f(Math.max(...a), 2)}`);
}
{
  const A = segYields(D0, 'CH-3B', 'A'), B = segYields(D0, 'CH-3B', 'B'), D = segYields(D0, 'CH-3B', 'D');
  const drop = mean(A) - mean(B), rec = mean(D) - mean(B);
  say(`  하락폭 A−B = ${f(drop)} · 회복폭 D−B = ${f(rec)} · 회복 비율 ${f(100 * rec / drop, 1)}%`);
  say(`  D−A = ${f(mean(D) - mean(A))} (Welch t ${f(welch(D, A).t)}, df ${f(welch(D, A).df, 2)})`);
  say(`  [소수 넷째 자리까지] A ${f(mean(A), 4)} · B ${f(mean(B), 4)} · D ${f(mean(D), 4)} · Δ(D−B) ${f(rec, 4)} · D−A ${f(mean(D) - mean(A), 4)} · 회복 비율 ${f(100 * rec / drop, 4)}%`);
  say(`  [합으로도 적는다] A 합 ${A.reduce((x, y) => x + y, 0).toFixed(2)}/54 · B 합 ${B.reduce((x, y) => x + y, 0).toFixed(2)}/56 · D 합 ${D.reduce((x, y) => x + y, 0).toFixed(2)}/14`);
  say(`  * analyst 는 세 자리로 90.097 을, 나는 90.098 로 적는다. 참값은 90.0975 라 반올림 방향만 다르다.`);
}

sub('3-4 CH-3B 날마다의 평균 (08-20 ~ 09-03)');
dateRange('2026-08-20', '2026-09-03').forEach(d => {
  const a = D0.filter(r => r.ch === 'CH-3B' && r.date === d).map(r => r.y);
  say(`  ${d}  n=${a.length}  평균 ${f(mean(a))}${d === '2026-08-27' ? '  <- 교체일' : ''}`);
});

// ---------- [4] 흠 넷을 다르게 처리 ----------
hr('[4] 흠 넷의 처리를 손잡이로 돌린다 — 결론이 처리의 산물인가');
say('  손잡이: dup(중복) drop|keep|both · low(소문자 챔버) fix|drop · slash(날짜 구분자) fix|drop · blank(빈 파티클) keepYield|drop');
say('  먼저 흠 있는 행이 어느 챔버·구간에 있는지 밝힌다.');
[...dupRaw.map(([k, v]) => ['중복', v.join('·'), k]), ...slash.map(s => ['날짜 구분자', s[0], YA.rows[s[0] - 1]._raw]), ...lower.map(s => ['소문자 챔버', s[0], YA.rows[s[0] - 1]._raw]), ...Object.values(blanks).flat().map(n => ['빈 파티클', n, YA.rows[n - 1]._raw])].forEach(([t, n, raw]) => {
  const r = norm(YA.rows[(String(n).split('·')[0] | 0) - 1]);
  say(`    ${t.padEnd(8)} 부록 ${String(n).padEnd(6)} ${raw}   → ${r.ch} · 구간 ${segOf(r.date)}`);
});
sub('4-1 24가지 조합(dup 3 × low 2 × slash 2 × blank 2)에서 CH-3B 의 Δ 와 D−A · 그리고 Δ 최대 챔버');
say('  dup   low   slash blank      행수   B평균    D평균    Δ(%p)   D−A(%p)  회복%   Δ최대챔버  다섯최대Δ');
const combos = [];
for (const dup of ['drop', 'keep', 'both']) for (const low of ['fix', 'drop']) for (const slash of ['fix', 'drop']) for (const blank of ['keepYield', 'drop']) {
  const R = build({ dup, low, slash, blank });
  const A = segYields(R, 'CH-3B', 'A'), B = segYields(R, 'CH-3B', 'B'), Dd = segYields(R, 'CH-3B', 'D');
  const dl = {}; CHS.forEach(c => dl[c] = mean(segYields(R, c, 'D')) - mean(segYields(R, c, 'B')));
  const top = CHS.reduce((a, b) => dl[a] > dl[b] ? a : b);
  const oth = Math.max(...CHS.filter(c => c !== 'CH-3B').map(c => dl[c]));
  combos.push({ dup, low, slash, blank, d: dl['CH-3B'], da: mean(Dd) - mean(A) });
  say(`  ${dup.padEnd(6)}${low.padEnd(6)}${slash.padEnd(6)}${blank.padEnd(11)}${String(R.length).padStart(4)}  ${f(mean(B))}  ${f(mean(Dd))}  +${f(dl['CH-3B'])}  ${f(mean(Dd) - mean(A))}  ${f(100 * (mean(Dd) - mean(B)) / (mean(A) - mean(B)), 1)}  ${top.padEnd(10)} +${f(oth)}`);
}
say(`  24조합의 CH-3B Δ 범위: +${f(Math.min(...combos.map(c => c.d)))} ~ +${f(Math.max(...combos.map(c => c.d)))} · D−A 범위: ${f(Math.min(...combos.map(c => c.da)))} ~ ${f(Math.max(...combos.map(c => c.da)))}`);

sub('4-2 구간 경계도 돌린다 (07-28·07-29·08-27 을 다르게 넣어 본다)');
const boundaries = [
  ['analyst 안 (07-28·07-29·08-27 뺌)', ['2026-07-01', '2026-07-27'], ['2026-07-30', '2026-08-26'], ['2026-08-28', '2026-09-03']],
  ['07-28·07-29 를 A 에 넣음', ['2026-07-01', '2026-07-29'], ['2026-07-30', '2026-08-26'], ['2026-08-28', '2026-09-03']],
  ['07-28·07-29 를 B 에 넣음', ['2026-07-01', '2026-07-27'], ['2026-07-28', '2026-08-26'], ['2026-08-28', '2026-09-03']],
  ['08-27 을 B 에 넣음', ['2026-07-01', '2026-07-27'], ['2026-07-30', '2026-08-27'], ['2026-08-28', '2026-09-03']],
  ['08-27 을 D 에 넣음', ['2026-07-01', '2026-07-27'], ['2026-07-30', '2026-08-26'], ['2026-08-27', '2026-09-03']],
  ['B 를 마지막 14일로만', ['2026-07-01', '2026-07-27'], ['2026-08-13', '2026-08-26'], ['2026-08-28', '2026-09-03']],
  ['B·D 를 각 7일로', ['2026-07-01', '2026-07-27'], ['2026-08-20', '2026-08-26'], ['2026-08-28', '2026-09-03']],
];
say('  경계안                              B평균    D평균    Δ(%p)   A평균    D−A(%p)  다섯최대Δ');
boundaries.forEach(([name, a, b, d]) => {
  const g = (ch, r) => D0.filter(x => x.ch === ch && x.date >= r[0] && x.date <= r[1]).map(x => x.y);
  const dl = {}; CHS.forEach(c => dl[c] = mean(g(c, d)) - mean(g(c, b)));
  const oth = Math.max(...CHS.filter(c => c !== 'CH-3B').map(c => dl[c]));
  say(`  ${name.padEnd(34)}${f(mean(g('CH-3B', b)))}  ${f(mean(g('CH-3B', d)))}  +${f(dl['CH-3B'])}  ${f(mean(g('CH-3B', a)))}  ${f(mean(g('CH-3B', d)) - mean(g('CH-3B', a)))}  +${f(oth)}`);
});

// ---------- [5] 파티클 비율 ----------
hr('[5] 파티클 비율 — 정의 P(합÷합) 와 정의 M(로트 평균)');
say('  챔버     A P/M              B P/M              C P/M              D P/M');
for (const c of CHS) {
  const line = ['A', 'B', 'C', 'D'].map(k => {
    const rs = D0.filter(r => r.ch === c && segOf(r.date) === k && r.p !== null);
    const Pv = rs.reduce((s, r) => s + r.p, 0) / rs.reduce((s, r) => s + r.d, 0);
    const Mv = mean(rs.map(r => r.p / r.d));
    return `P ${f(Pv, 4)} M ${f(Mv, 4)}`.padEnd(19);
  }).join('');
  say(`  ${c}  ${line}`);
}
{
  const g = k => { const rs = D0.filter(r => r.ch === 'CH-3B' && segOf(r.date) === k && r.p !== null); return rs.reduce((s, r) => s + r.p, 0) / rs.reduce((s, r) => s + r.d, 0); };
  const A = g('A'), B = g('B'), Dv = g('D');
  say(`  CH-3B  A ${f(A, 4)} · B ${f(B, 4)} · D ${f(Dv, 4)} · D−B ${f(Dv - B, 4)}`);
  say(`  파티클 회복 비율 (B−D)/(B−A) = ${f(100 * (B - Dv) / (B - A), 2)}%  ← analyst 는 66.5% 로 적었다`);
  say(`  반올림한 값으로만 계산하면 (0.5488−0.3084)/(0.5488−0.1870) = ${f(100 * (0.5488 - 0.3084) / (0.5488 - 0.1870), 2)}%`);
  say(`  D 는 A 의 ${f(Dv / A, 3)}배`);
}
sub('5-1 analyst 의 파티클 표(log22#212-218)와 값 하나씩 맞춘다');
{
  const lg = fs.readFileSync(P + 'analyst/task-22-evidence.log', 'utf8').split('\n');
  let ok = 0, bad = 0;
  CHS.forEach((c, i) => {
    const nums = (lg[212 + i] || '').match(/[PM] (\d\.\d{4})/g).map(s => +s.slice(2));
    ['A', 'B', 'C', 'D'].forEach((k, j) => {
      const rs = D0.filter(r => r.ch === c && segOf(r.date) === k && r.p !== null);
      const mine = [rs.reduce((s, r) => s + r.p, 0) / rs.reduce((s, r) => s + r.d, 0), mean(rs.map(r => r.p / r.d))];
      mine.forEach((v, q) => {
        const a = nums[j * 2 + q];
        if (Math.abs(a - v) > 5e-5) { say(`  어긋남 ${c} ${k} ${q ? 'M' : 'P'}: analyst ${a} 내 계산 ${v.toFixed(4)}`); bad++; } else ok++;
      });
    });
  });
  say(`  맞은 값 ${ok}개 · 어긋난 값 ${bad}개 (칸 24개 × 정의 둘)`);
}

// ---------- [6] 세정 사건 ----------
hr('[6] 경쟁 설명 ① — 세정만 있던 사건의 앞뒤 7일 차이');
function around(ch, date) {
  const prev = dateRange(new Date(new Date(date + 'T00:00:00Z').getTime() - 7 * 864e5).toISOString().slice(0, 10), new Date(new Date(date + 'T00:00:00Z').getTime() - 864e5).toISOString().slice(0, 10));
  const next = dateRange(new Date(new Date(date + 'T00:00:00Z').getTime() + 864e5).toISOString().slice(0, 10), new Date(new Date(date + 'T00:00:00Z').getTime() + 7 * 864e5).toISOString().slice(0, 10));
  const a = D0.filter(r => r.ch === ch && prev.includes(r.date)).map(r => r.y);
  const b = D0.filter(r => r.ch === ch && next.includes(r.date)).map(r => r.y);
  return { a, b, delta: mean(b) - mean(a) };
}
const partDays = new Set(EV.filter(e => e.type === 'PART').map(e => e.date + '|' + e.ch));
const cleans = EV.filter(e => e.type === 'CLEAN');
say(`  PART 사건 전부 ${EV.filter(e => e.type === 'PART').length}건: ${EV.filter(e => e.type === 'PART').map(e => e.date + ' ' + e.ch).join(' · ')}`);
say(`  CLEAN 사건 전체: ${cleans.length}건 · 그 가운데 같은 날 같은 챔버에 PART 가 있던 것: ${cleans.filter(e => partDays.has(e.date + '|' + e.ch)).length}건`);
say(`    겹친 자리: ${cleans.filter(e => partDays.has(e.date + '|' + e.ch)).map(e => e.date + ' ' + e.ch).join(' · ')}`);
const soloCleans = cleans.filter(e => !partDays.has(e.date + '|' + e.ch));
say(`  → 세정만 있던 사건: ${soloCleans.length}건`);
sub('6-1 CH-3B 의 세정 사건');
cleans.filter(e => e.ch === 'CH-3B').sort((x, y) => x.date.localeCompare(y.date)).forEach(e => {
  const r = around(e.ch, e.date);
  say(`  ${e.date}  ${String(e.min).padStart(3)}분  앞 ${f(mean(r.a))} 뒤 ${f(mean(r.b))}  Δ ${(r.delta >= 0 ? '+' : '') + f(r.delta)}  n ${r.a.length}/${r.b.length}${partDays.has(e.date + '|' + e.ch) ? '  (같은 날 PART 있음)' : ''}`);
});
sub('6-2 세정만 있던 사건 전부의 Δ (정렬)');
const soloD = soloCleans.map(e => ({ ...e, ...around(e.ch, e.date) })).sort((a, b) => b.delta - a.delta);
soloD.forEach(e => say(`  ${e.date} ${e.ch} ${String(e.min).padStart(3)}분  Δ ${(e.delta >= 0 ? '+' : '') + f(e.delta)}  n ${e.a.length}/${e.b.length}`));
function stat(v) {
  v = v.slice().sort((a, b) => a - b);
  const med = v.length % 2 ? v[(v.length - 1) / 2] : (v[v.length / 2 - 1] + v[v.length / 2]) / 2;
  return { n: v.length, min: v[0], max: v[v.length - 1], med, over2: v.filter(x => x > 2.0).length };
}
{
  const r827 = around('CH-3B', '2026-08-27');
  const all = soloD.filter(e => !Number.isNaN(e.delta));
  say(`  [세는 규칙에 따라 건수가 갈린다 — 본문은 규칙을 적지 않았다]`);
  const rules = [
    ['① 세정만 (창이 비어도 셈)', soloD],
    ['② 앞·뒤 창에 로트가 하나라도 있는 것', all],
    ['③ 앞 창에 로트가 3개 이상인 것', all.filter(e => e.a.length >= 3)],
    ['④ 앞·뒤 창이 둘 다 꽉 찬 것(14/14)', all.filter(e => e.a.length === 14 && e.b.length === 14)],
  ];
  rules.forEach(([name, arr]) => {
    const s = stat(arr.filter(e => !Number.isNaN(e.delta)).map(e => e.delta));
    say(`  ${name.padEnd(30)} n=${String(arr.length).padStart(2)} (값이 나는 것 ${s.n}) · 최소 ${f(s.min)} · 최대 ${f(s.max)} · 중앙값 ${f(s.med)} · +2.0%p 초과 ${s.over2}건 · 08-27 이상 ${arr.filter(e => e.delta >= r827.delta).length}건`);
  });
  say(`  → analyst 의 "27건 · 최소 -1.471 · 최대 +0.645 · 중앙값 -0.044" 는 규칙 ③ 과 같다.`);
  say(`  → 어느 규칙으로 세도 +2.0%p 를 넘은 세정은 0건이고 08-27 이상인 세정도 0건이다.`);
  const v = stat(all.map(e => e.delta));
  say(`  08-27(교체+세정) Δ = +${f(r827.delta)} — 세정만 사건의 최대(+${f(v.max)})의 ${f(r827.delta / v.max, 1)}배`);
}
sub('6-3 잣대를 바꿔 본다 — 앞뒤 창을 3·5·7·10·14일로');
[3, 5, 7, 10, 14].forEach(w => {
  function ar(ch, date) {
    const t = new Date(date + 'T00:00:00Z').getTime();
    const pv = dateRange(new Date(t - w * 864e5).toISOString().slice(0, 10), new Date(t - 864e5).toISOString().slice(0, 10));
    const nx = dateRange(new Date(t + 864e5).toISOString().slice(0, 10), new Date(t + w * 864e5).toISOString().slice(0, 10));
    const a = D0.filter(r => r.ch === ch && pv.includes(r.date)).map(r => r.y);
    const b = D0.filter(r => r.ch === ch && nx.includes(r.date)).map(r => r.y);
    return (a.length && b.length) ? mean(b) - mean(a) : null;
  }
  const v = soloCleans.map(e => ar(e.ch, e.date)).filter(x => x !== null).sort((a, b) => a - b);
  const x827 = ar('CH-3B', '2026-08-27');
  say(`  창 ${String(w).padStart(2)}일: 세정만 ${v.length}건 Δ ${f(v[0])} ~ ${f(v[v.length - 1])} · 08-27 은 +${f(x827)} · 08-27 이상인 세정 ${v.filter(x => x >= x827).length}건`);
});

// ---------- [7] 변화점 · 내 seed 로 순열검정 ----------
hr('[7] 변화점 탐색 — 내 seed(20260923) 로 따로 돌린다');
function rng(seed) { let s = seed >>> 0; return () => { s ^= s << 13; s >>>= 0; s ^= s >> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; }; }
function changepoint(ch, from, to, unit) {
  let rs = D0.filter(r => r.ch === ch && r.date >= from && r.date <= to);
  const ds = [...new Set(rs.map(r => r.date))].sort();
  if (unit === 'day') rs = ds.map(d => ({ date: d, y: mean(D0.filter(r => r.ch === ch && r.date === d).map(r => r.y)) }));
  const vals = rs.map(r => r.y), dts = rs.map(r => r.date);
  function best(v) {
    let bt = 0, bd = null;
    for (let i = 2; i <= ds.length - 2; i++) {
      const cut = ds[i];
      const a = [], b = [];
      for (let j = 0; j < v.length; j++) (dts[j] < cut ? a : b).push(v[j]);
      if (a.length < 2 || b.length < 2) continue;
      const t = Math.abs(welch(b, a).t);
      if (t > bt) { bt = t; bd = cut; }
    }
    return { t: bt, d: bd };
  }
  const obs = best(vals);
  const R = rng(20260923); const B = 2000; let ge = 0;
  for (let k = 0; k < B; k++) {
    const v = vals.slice();
    for (let i = v.length - 1; i > 0; i--) { const j = Math.floor(R() * (i + 1)); [v[i], v[j]] = [v[j], v[i]]; }
    if (best(v).t >= obs.t) ge++;
  }
  return { ...obs, p: (ge + 1) / (B + 1), nDays: ds.length, nLots: vals.length };
}
say('  본문·근거 로그는 검정의 단위(로트냐 하루 평균이냐)를 적지 않았다. 두 단위를 다 돌려 어느 쪽이 analyst 값인지 가른다.');
['day', 'lot'].forEach(u => {
  sub(`7-${u === 'day' ? 1 : 2} 단위 = ${u === 'day' ? '하루 평균' : '로트'}`);
  say('  대상     기간                     점수   잡힌 날      |t|      순열 p (내 seed · 2000회)');
  [['CH-3B', '2026-08-01', '2026-09-03'], ['CH-3B', '2026-07-01', '2026-09-03'], ['CH-3A', '2026-08-01', '2026-09-03'], ['CH-2B', '2026-08-01', '2026-09-03'], ['CH-1A', '2026-08-01', '2026-09-03'], ['CH-1B', '2026-08-01', '2026-09-03'], ['CH-2A', '2026-08-01', '2026-09-03']].forEach(([c, a, b]) => {
    const r = changepoint(c, a, b, u);
    say(`  ${c}  ${a}~${b}  ${String(u === 'day' ? r.nDays : r.nLots).padStart(4)}   ${r.d}  ${f(r.t)}   ${f(r.p, 4)}`);
  });
});
say('  → analyst 의 |t| 11.117 · 14.345 · 2.100 · 2.590 은 "하루 평균" 단위에서 그대로 나온다. 로트 단위로는 9.501 · 16.342 다.');
say('  → 어느 단위로 해도 CH-3B 8월 이후에서 잡히는 날은 2026-08-28 이고 p 는 0.005 아래다.');
say('  * seed 가 다르므로 p 는 analyst 값과 소수 자리에서 다를 수 있다. 잡힌 날과 |t| 는 난수와 무관하다.');

// ---------- [8] 부품 ----------
hr('[8] 뗀 부품과 단 부품 — 입고 검사 대 재측정');
RE.rows.forEach(r => say(`  재측정 ${r._n}행: ${r.serial} · 상한 ${r.spec_max}${r.unit} · 입고 ${r.incoming_date} ${r.incoming_value} · 재측정 ${r.remeasure_date} ${r.remeasure_value} · 차이 ${(+r.remeasure_value - +r.incoming_value).toFixed(1)} (${f(100 * (+r.remeasure_value - +r.incoming_value) / +r.incoming_value, 1)}%) · 배수 ${f(+r.incoming_value / +r.spec_max, 2)}→${f(+r.remeasure_value / +r.spec_max, 2)} · ${r.note}`));
sub('8-1 입고 검사 원본에서 같은 두 낱개');
INSP.rows.filter(r => /SH2200-B-041[23]/.test(r.serial)).forEach(r => say(`  insp ${String(r._n).padStart(2)}행: ${r.serial} · recv ${r.recv_date} · measured ${r.measured}${r.unit} (상한 ${r.spec_max}) · install ${r.install_date || '(빈칸)'} · chamber ${r.chamber || '(빈칸)'}`));
say(`  → 4.8 um 이 붙어 있는 날짜 칸: recv_date 2026-07-18. 2026-07-28 은 install_date 다.`);
say(`  입고 검사 원본 안의 완전 중복 행: ${Object.entries(INSP.rows.reduce((a, r) => ((a[r._raw] = a[r._raw] || []).push(r._n), a), {})).filter(([, v]) => v.length > 1).length}쌍`);
sub('8-2 규격을 넘긴 낱개 전부 (반례 세기)');
INSP.rows.filter(r => +r.measured > +r.spec_max).forEach(r => say(`  insp ${String(r._n).padStart(2)}행: ${r.serial} ${r.part_no} · ${r.measured}/${r.spec_max}${r.unit} = ${f(+r.measured / +r.spec_max, 2)}배 · install ${r.install_date || '(빈칸)'} · chamber ${r.chamber || '(빈칸)'}`));

// ---------- [9] 경쟁 설명을 세는 자리 ----------
hr('[9] 남는 경쟁 설명을 세는 데 필요한 사실');
say(`  08-27 CH-3B 에 적힌 사건: ${EV.filter(e => e.date === '2026-08-27' && e.ch === 'CH-3B').map(e => e.type + ' ' + e.min + '분').join(' · ')}`);
say(`  08-28~09-03 사이 CH-3B 사건: ${JSON.stringify(EV.filter(e => e.date >= '2026-08-28' && e.date <= '2026-09-03' && e.ch === 'CH-3B').map(e => e.date + ' ' + e.type))}`);
say(`  08-28~09-03 사이 다른 챔버 사건: ${JSON.stringify(EV.filter(e => e.date >= '2026-08-28' && e.date <= '2026-09-03' && e.ch !== 'CH-3B').map(e => e.date + ' ' + e.ch + ' ' + e.type))}`);
say(`  RECIPE 사건 전부: ${JSON.stringify(EV.filter(e => e.type === 'RECIPE').map(e => e.date + ' ' + e.ch + ' ' + e.detail))}`);
say(`  event_type 종류와 건수: ${JSON.stringify(EV.reduce((a, e) => (a[e.type] = (a[e.type] || 0) + 1, a), {}))}`);
sub('9-1 B 구간이 평평한가 — 자연 회복(평균 회귀)이라는 설명을 시험한다');
{
  const rs = D0.filter(r => r.ch === 'CH-3B' && segOf(r.date) === 'B');
  const ds = [...new Set(rs.map(r => r.date))].sort();
  const xs = ds.map((d, i) => i), ysB = ds.map(d => mean(rs.filter(r => r.date === d).map(r => r.y)));
  const mx = mean(xs), my = mean(ysB);
  const slope = xs.reduce((s, x, i) => s + (x - mx) * (ysB[i] - my), 0) / xs.reduce((s, x) => s + (x - mx) ** 2, 0);
  say(`  B 구간(07-30~08-26) 하루 평균에 맞춘 직선의 기울기: ${f(slope, 4)} %p/일 (점 ${ds.length}개)`);
  say(`  B 앞 절반 평균 ${f(mean(ysB.slice(0, Math.floor(ds.length / 2))))} · 뒤 절반 평균 ${f(mean(ysB.slice(Math.ceil(ds.length / 2))))}`);
  const rd = D0.filter(r => r.ch === 'CH-3B' && segOf(r.date) === 'D');
  const dds = [...new Set(rd.map(r => r.date))].sort();
  const yd = dds.map(d => mean(rd.filter(r => r.date === d).map(r => r.y)));
  const mx2 = mean(dds.map((d, i) => i)), my2 = mean(yd);
  const sl2 = dds.map((d, i) => i).reduce((s, x, i) => s + (x - mx2) * (yd[i] - my2), 0) / dds.map((d, i) => i).reduce((s, x) => s + (x - mx2) ** 2, 0);
  say(`  D 구간 하루 평균 기울기: ${f(sl2, 4)} %p/일 (점 ${dds.length}개) · 첫 사흘 ${f(mean(yd.slice(0, 3)))} · 마지막 사흘 ${f(mean(yd.slice(-3)))}`);
  say(`  A 평균과 마지막 사흘의 거리: ${f(mean(yd.slice(-3)) - mean(segYields(D0, 'CH-3B', 'A')))}`);
}
sub('9-2 파일 경계가 만든 것인가 — 부록은 08-26 부터 시작한다');
say(`  부록 첫날 08-26 · 08-27 의 CH-3B 하루 평균: ${f(mean(D0.filter(r => r.ch === 'CH-3B' && r.date === '2026-08-26').map(r => r.y)))} · ${f(mean(D0.filter(r => r.ch === 'CH-3B' && r.date === '2026-08-27').map(r => r.y)))}`);
say(`  부록 첫 이틀의 여섯 챔버 평균: ${CHS.map(c => c + ' ' + f(mean(D0.filter(r => r.ch === c && r.date >= '2026-08-26' && r.date <= '2026-08-27').map(r => r.y)), 2)).join(' · ')}`);
sub('9-3 07-28 PART 도 같은 작업이었다 — ③ 의 반례');
dateRange('2026-07-25', '2026-08-02').forEach(d => {
  const a = D0.filter(r => r.ch === 'CH-3B' && r.date === d).map(r => r.y);
  if (a.length) say(`  ${d}  CH-3B 하루 평균 ${f(mean(a))}`);
});
say(`  07-28 CH-3B 사건: ${EV.filter(e => e.date === '2026-07-28' && e.ch === 'CH-3B').map(e => e.type + ' ' + e.min + '분').join(' · ')}`);
say(`  07-28 에 PM 을 받은 챔버 전부: ${JSON.stringify(EV.filter(e => e.date === '2026-07-28' && e.type === 'PM').map(e => e.ch))}`);
{
  const g = (ch, a, b) => D0.filter(r => r.ch === ch && r.date >= a && r.date <= b).map(r => r.y);
  CHS.forEach(c => say(`  ${c} 07-21~07-27 평균 ${f(mean(g(c, '2026-07-21', '2026-07-27')))} → 07-29~08-04 평균 ${f(mean(g(c, '2026-07-29', '2026-08-04')))} · Δ ${f(mean(g(c, '2026-07-29', '2026-08-04')) - mean(g(c, '2026-07-21', '2026-07-27')))}`));
}

// ---------- [10] 본문 자기 서술 숫자 ----------
hr('[10] 본문이 스스로 선언한 것을 산수로 맞춰 본다');
{
  const md = fs.readFileSync(P + 'analyst/task-22-showerhead-replacement-effect.md', 'utf8').split('\n');
  say(`  본문 줄 수: ${md.length - (md[md.length - 1] === '' ? 1 : 0)}`);
  say(`  본문 2절 표(65~80행)가 든 날짜: ${md.slice(64, 80).map(l => (l.match(/\| ?\*?\*?(\d{2}-\d{2})/) || [])[1]).filter(Boolean).join(' ')}`);
  say(`  → 교체일 앞에 있는 날: ${md.slice(64, 80).map(l => (l.match(/\| ?\*?\*?(\d{2}-\d{2})/) || [])[1]).filter(x => x && x < '08-27').length}일 · 뒤: ${md.slice(64, 80).map(l => (l.match(/\| ?\*?\*?(\d{2}-\d{2})/) || [])[1]).filter(x => x && x > '08-27').length}일`);
  say(`  본문 63행의 선언: ${md[62].trim()}`);
  say(`  * 6절의 '앞 7일 평균 90.165' 는 08-20~08-26 열나흘 로트로 낸 값이다 — 08-20 이 2절 표에 없다.`);
  const cite = fs.readFileSync(P + 'analyst/task-22-citation-check.log', 'utf8');
  say(`  인용 검사 로그 줄 수: ${cite.split('\n').length}`);
}
sub('10-1 본문 2절 표를 원본과 한 칸씩 맞춘다 (analyst 의 검사기를 쓰지 않고 내가 센다)');
{
  const md = fs.readFileSync(P + 'analyst/task-22-showerhead-replacement-effect.md', 'utf8').split('\n');
  let ok = 0, bad = 0;
  for (let i = 67; i <= 80; i++) {
    const m = md[i - 1].match(/^\| \*?\*?(\d{2}-\d{2})[^|]*\|\s*([\d.]+) · ([\d.]+)\s*\|\s*\*?\*?([\d.]+)\*?\*?\s*\|\s*([\d.]+) · ([\d.]+)\s*\|/);
    if (!m) { say(`  파싱 못함 본문#${i}`); continue; }
    const rs = D0.filter(r => r.ch === 'CH-3B' && r.date === '2026-' + m[1]);
    const chk = [[+m[2], rs[0].y], [+m[3], rs[1].y], [+m[4], (rs[0].y + rs[1].y) / 2], [+m[5], rs[0].p / rs[0].d], [+m[6], rs[1].p / rs[1].d]];
    chk.forEach(([a, b], j) => { if (Math.abs(a - b) > 1e-4) { say(`  어긋남 본문#${i} 칸${j + 1}: 본문 ${a} 내 계산 ${b.toFixed(4)}`); bad++; } else ok++; });
  }
  say(`  맞은 칸 ${ok} · 어긋난 칸 ${bad}`);
}
sub('10-2 task-11 로 간 인용 둘을 열어 본다');
{
  const t11 = fs.readFileSync(P + 'analyst/task-11-equipment-history-vs-yield.md', 'utf8').split('\n');
  say(`  대조#115 : ${t11[114].trim()}`);
  say(`  대조#126 : ${t11[125].trim()}`);
  say(`  대조#139 : ${t11[138].trim().slice(0, 90)}…`);
  say(`  → 본문 182행이 PM 설명에 붙인 대조#115-126 은 3a 절(PM 대조군)을 가리킨다. 맞는 자리다.`);
  say(`  → 본문 180행이 ③ 에 붙인 대조#139 는 3b 절(CH-2B 에서 같은 부품을 갈았으나 안 움직임)의 결론이다. 맞는 자리다.`);
}
fs.writeFileSync(P + 'researcher/task-23-evidence.log', out.join('\n') + '\n');
console.log(out.join('\n'));
