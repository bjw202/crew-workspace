// 인용 되세기 — analyst/task-16-citation-check.py 를 읽지도 돌리지도 않고 따로 센다.
const fs = require('fs');
const ROOM = '/Users/byunjungwon/Dev/my-project-04/crew-workspace/rooms/수율개선-2026q3/';
const body = fs.readFileSync(ROOM + 'analyst/task-16-part-inspection-vs-yield.md', 'utf8').replace(/\r/g, '').split('\n');
const TARGET = {
  insp: ROOM + 'archivist/inbox/2026-09-09-part-incoming-inspection/28d181e9-647f-4b69-8fe7-554982ecd8de-part_incoming_inspection.csv',
  eq:   ROOM + 'archivist/inbox/2026-09-08-equipment-history/423efc74-8819-445a-bb81-90ca388034fd-equipment_history.csv',
  yield:ROOM + 'archivist/inbox/2026-09-08-yield-by-lot/44cdd855-be6e-4b66-a014-e7eb3a056769-yield_by_lot.csv',
  log16:ROOM + 'analyst/task-16-evidence.log',
  log11:ROOM + 'analyst/task-11-evidence.log',
  '대조':ROOM + 'analyst/task-11-equipment-history-vs-yield.md' };
const nLines = {}; for (const k in TARGET) nLines[k] = fs.readFileSync(TARGET[k], 'utf8').replace(/\r/g, '').replace(/\n$/, '').split('\n').length;

// prefix#N 뒤에 ·N 또는 ·N-M 이 이어지면 그것도 같은 대상의 인용으로 센다 (본문이 그렇게 쓴다).
const RE = /(insp|eq|yield|log16|log11|대조)#((?:\d+(?:-\d+)?)(?:·\d+(?:-\d+)?)*)/g;
const cites = [], out = [];
body.forEach((line, i) => { let m; RE.lastIndex = 0;
  while ((m = RE.exec(line)) !== null) m[2].split('·').forEach(tok => cites.push({ bodyLine: i + 1, tgt: m[1], tok })); });
const cnt = {}, bad = [];
cites.forEach(c => { cnt[c.tgt] = (cnt[c.tgt] || 0) + 1;
  const ns = c.tok.split('-').map(Number);
  ns.forEach(n => { if (n < 1 || n > nLines[c.tgt]) bad.push(`본문#${c.bodyLine} ${c.tgt}#${c.tok} (대상 ${nLines[c.tgt]}행)`); });
  if (ns.length === 2 && ns[0] > ns[1]) bad.push(`본문#${c.bodyLine} ${c.tgt}#${c.tok} 범위가 뒤집힘`); });
out.push('대상 파일 행 수: ' + Object.keys(nLines).map(k => `${k} ${nLines[k]}행`).join(' · '));
out.push('');
out.push('내가 센 인용 (대상별)');
['insp','eq','yield','log16','log11','대조'].forEach(k => out.push(`  ${k.padEnd(6)} ${String(cnt[k]||0).padStart(3)}곳   (analyst 검사기: insp 24 · eq 12 · yield 2 · log16 33 · log11 1 · 대조 16)`));
out.push(`  합계   ${cites.length}곳   (본문/보고 '인용 88곳')`);
out.push(`  범위를 벗어난 인용 : ${bad.length}곳 ${bad.join(' / ')}`);
out.push('');
out.push('본문 줄별 인용 목록 (내 셈)');
cites.forEach(c => out.push(`  본문#${String(c.bodyLine).padStart(3)}  ${c.tgt}#${c.tok}`));
fs.writeFileSync(ROOM + 'researcher/task-17-cite.log', out.join('\n') + '\n');
console.log(out.slice(0, 12).join('\n'));
